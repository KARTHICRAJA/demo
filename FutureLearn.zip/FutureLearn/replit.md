# Endur HyperIQ - AI-Powered ETRM Knowledge Hub

## Overview

Endur HyperIQ is an AI-powered knowledge management system designed to address institutional knowledge loss in Energy Trading and Risk Management (ETRM) environments, specifically for the Openlink Endur platform. The application features multiple specialized AI agents that provide intelligent document retrieval, adaptive learning paths, operational troubleshooting, and structured chat interfaces with visual outputs.

The system transforms static documentation (design docs, SOPs, configuration guides, process flows) into an interactive knowledge graph with semantic search, enabling rapid onboarding, productivity enhancement, and preservation of critical business knowledge.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack**: React with TypeScript, using Vite as the build tool and bundler.

**UI Framework**: Shadcn/ui components built on Radix UI primitives with Tailwind CSS for styling. The design system follows a "New York" style with neutral color palette and CSS variables for theming.

**Routing**: Wouter for client-side routing with dedicated pages for Welcome, AI Agents, Chat, Documents, Process visualization, Monitoring, and role-specific views (Business Analyst, Architect, Operations Engineer).

**State Management**: TanStack Query (React Query) for server state management with custom query client configuration. Local state managed via React hooks.

**Design Philosophy**: Enterprise data application aesthetic inspired by Carbon Design System, combined with modern AI tool UX patterns from Linear and ChatGPT. Emphasizes information density with breathing room, hierarchical clarity, and scannable metrics.

**Key Components**:
- Activity Feed with real-time updates
- Agent Cards for managing AI agents
- Chat Interface with citation support
- Knowledge Graph Navigator for visual exploration
- Structured Chat Interface with Mermaid diagram rendering
- Metrics Cards for KPI visualization
- Value Monitoring for ROI tracking

### Backend Architecture

**Runtime**: Node.js with Express server framework.

**Type Safety**: Full TypeScript implementation across server and shared schema definitions.

**API Design**: RESTful endpoints prefixed with `/api`. Routes are registered centrally in `server/routes.ts`.

**Storage Interface**: Abstracted storage layer (`IStorage`) with in-memory implementation (`MemStorage`) for development. Designed to be swappable with database-backed implementations.

**Development Setup**: Vite middleware integration for hot module replacement in development mode. Production builds use esbuild for server bundling.

### Data Storage Solutions

**Database**: PostgreSQL configured via Drizzle ORM with Neon serverless driver for connection pooling.

**Schema Management**: Drizzle Kit for migrations (output to `./migrations` directory). Schema definitions in `shared/schema.ts` using Drizzle's table builders.

**Current Schema**: Basic user management with UUID primary keys generated via `gen_random_uuid()`.

**Validation**: Zod schemas derived from Drizzle schemas for runtime validation.

**Rationale**: Drizzle chosen for type-safe queries, zero-cost abstractions, and excellent TypeScript integration. Neon serverless provides scalable PostgreSQL with WebSocket support.

### Authentication and Authorization

**Current State**: Basic user schema exists with username/password fields. No authentication middleware implemented yet.

**Session Management**: `connect-pg-simple` dependency present for PostgreSQL-backed session storage.

**Future Implementation**: Session-based authentication intended with PostgreSQL session store. User roles and permissions structure not yet defined.

### RAG System Architecture (Planned/Documented)

**Knowledge Ingestion Pipeline**:
- Multi-format document parsing (HTML, PDF, API docs, schema definitions)
- Hierarchical chunking strategy preserving parent-child relationships (512-1024 tokens)
- Multi-dimensional metadata tagging (user role, module, lifecycle phase, doc type, dependencies)
- Vector embeddings for semantic search
- Knowledge graph construction linking concepts (APM → Services → Connex)

**Retrieval Strategy**:
- Hybrid RAG combining vector similarity search with graph traversal
- Context filtering via visual navigation before query submission
- Structured output formatting with concept summaries, comparative tables, and visual aids

**AI Agent Types** (3 built-in + custom):
1. Knowledge Navigator - Semantic search and graph traversal
2. Adaptive Learning Companion - Personalized learning paths
3. Operational Copilot - Troubleshooting and root cause analysis
4. Custom agents - User-configurable with critique/validation features

**Output Formatting**:
- Enforced structured responses (executive summary, markdown tables, visual diagrams)
- Mermaid.js integration for live flowchart/sequence diagram rendering
- Citation tracking with source references

## External Dependencies

### UI and Component Libraries
- **@radix-ui/***: Headless UI primitives for accessible components (accordion, dialog, dropdown, tooltip, etc.)
- **shadcn/ui**: Component library built on Radix UI
- **lucide-react**: Icon system
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **cmdk**: Command palette interface

### Data Visualization
- **recharts**: Chart library for metrics visualization
- **mermaid**: Diagram rendering in chat interface
- **embla-carousel-react**: Carousel component

### Forms and Validation
- **react-hook-form**: Form state management
- **@hookform/resolvers**: Validation resolvers
- **zod**: Schema validation
- **drizzle-zod**: Drizzle to Zod schema conversion

### Database and ORM
- **drizzle-orm**: TypeScript ORM for PostgreSQL
- **@neondatabase/serverless**: Neon serverless PostgreSQL driver
- **ws**: WebSocket library for Neon connections
- **connect-pg-simple**: PostgreSQL session store

### State Management and Data Fetching
- **@tanstack/react-query**: Server state management and caching
- **wouter**: Lightweight client-side router

### Development Tools
- **vite**: Build tool and dev server
- **@vitejs/plugin-react**: React plugin for Vite
- **@replit/vite-plugin-***: Replit-specific dev tools (runtime error modal, cartographer, dev banner)
- **typescript**: Type system
- **tsx**: TypeScript execution for development
- **esbuild**: Production bundler for server code

### Utilities
- **date-fns**: Date manipulation
- **clsx** and **tailwind-merge**: Conditional className utilities
- **nanoid**: ID generation

### Font Loading
- **Google Fonts**: Inter (primary UI font), JetBrains Mono (monospace)
- **Geist Mono**, **Fira Code**, **DM Sans**, **Architects Daughter**: Additional font options loaded via HTML

### Design Assets
Custom generated images stored in `attached_assets/generated_images/` for agent icons, hero visualizations, and knowledge graph backgrounds.