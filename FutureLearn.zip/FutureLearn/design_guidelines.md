# Endur HyperIQ Design Guidelines

## Design Approach

**Selected Approach**: Design System + Modern AI Tool Hybrid

Drawing from Carbon Design System (enterprise data applications) and modern AI platforms like Linear, ChatGPT, and Vercel for the conversational and agentic interfaces. This approach balances enterprise-grade functionality with futuristic, intuitive user experience.

**Core Principles**:
- Information density with breathing room
- Hierarchical clarity for complex agent workflows
- Immediate visual feedback for AI operations
- Scannable metrics and KPIs
- Progressive disclosure for advanced features

---

## Typography System

**Font Families**:
- Primary: Inter (via Google Fonts) - UI elements, body text, metrics
- Monospace: JetBrains Mono - code snippets, agent IDs, technical data

**Type Scale**:
- Hero/Page Titles: text-4xl font-bold (36px)
- Section Headers: text-2xl font-semibold (24px)
- Card Titles: text-lg font-medium (18px)
- Body Text: text-base (16px)
- Metadata/Labels: text-sm font-medium (14px)
- Captions/Timestamps: text-xs (12px)

---

## Layout System

**Spacing Primitives**: Use Tailwind units of 2, 4, 6, 8, 12, 16 for consistency
- Tight spacing: p-2, gap-2 (component internals)
- Standard spacing: p-4, gap-4 (card padding, list items)
- Section spacing: p-8, gap-8 (major sections)
- Page margins: px-16, py-12 (desktop containers)

**Grid Structure**:
- Dashboard: 12-column grid with 4-column sidebar
- Metrics Cards: 3-column grid (lg:grid-cols-3)
- Agent List: 2-column grid (lg:grid-cols-2)
- Mobile: Always single column (grid-cols-1)

**Container Widths**:
- Full dashboard: max-w-[1920px]
- Content sections: max-w-7xl
- Conversational interface: max-w-4xl
- Modals/Dialogs: max-w-2xl

---

## Component Library

### Navigation & Structure

**Top Navigation Bar**:
- Fixed height: h-16
- Contains: Logo, primary navigation tabs, user profile, notifications
- Sticky positioning for persistent access

**Sidebar Navigation** (Agent Dashboard):
- Width: w-64 (256px)
- Collapsible to w-16 (icon-only mode)
- Sections: Active Agents, Agent Library, Custom Builders, Knowledge Graph, Metrics

**Breadcrumbs**:
- Display current location in agent hierarchy
- Format: text-sm with separator icons from Heroicons
- Positioned below top nav: py-3

### Dashboard Components

**Agent Status Cards**:
- Grid layout: 3-column on desktop (lg:grid-cols-3)
- Card structure: rounded-lg border with p-6
- Contains: Agent icon, name, status badge, key metrics, quick actions
- Hover state: subtle elevation (shadow-md)

**Metrics Dashboard**:
- KPI Cards in grid: grid-cols-1 md:grid-cols-2 lg:grid-cols-4
- Each card: p-6 space-y-2
- Format: Large metric value (text-3xl font-bold), label (text-sm), trend indicator
- Includes: MTTR, TTC, Retrieval Accuracy, Cost Savings

**Real-time Activity Feed**:
- Right sidebar or dedicated panel: w-80
- List items: py-3 px-4 border-b
- Contains: timestamp, agent avatar, action description, status icon
- Max height with scroll: max-h-[600px] overflow-y-auto

### Conversational Interface

**Chat Container**:
- Center-aligned: max-w-4xl mx-auto
- Messages list: space-y-4 pb-32
- Input area: Fixed bottom position with backdrop blur

**Message Bubbles**:
- User messages: ml-auto max-w-[80%] p-4 rounded-lg
- AI responses: mr-auto max-w-[85%] p-6 rounded-lg
- Code blocks: Monospace font, p-4, with syntax highlighting indicators
- Citations: text-sm with link icons from Heroicons

**Input Area**:
- Multi-line textarea: min-h-[60px] max-h-[200px]
- Controls: Send button, attachment, voice input
- Suggestions: Pill buttons (px-4 py-2 rounded-full) for quick queries

### Knowledge Graph Visualization

**Graph Canvas**:
- Full-width container: w-full h-[600px]
- Interactive SVG/Canvas area
- Zoom controls: Fixed position bottom-right
- Legend panel: Absolute positioned top-right, p-4

**Node Types**:
- Documents: Circular nodes
- Configurations: Square nodes
- Business Rules: Diamond nodes
- Connections: Directional arrows with labels

**Info Panel** (on node selection):
- Slide-in from right: w-96
- Contains: Node details, relationships, quick actions
- Close button: top-right corner

### Custom Agent Builder

**Builder Canvas**:
- Left: Component palette (w-64) with draggable items
- Center: Visual workflow canvas (flex-1)
- Right: Properties panel (w-80) for selected components

**Workflow Nodes**:
- Rounded rectangles: p-4 min-w-[200px]
- Connection points: Absolute positioned dots
- Labels: text-sm font-medium above node

**Configuration Panels**:
- Accordion-style sections for data sources, critique rules, validation
- Each section: p-4 border-b
- Form inputs: space-y-4 within sections

### Data Tables & Lists

**Agent Performance Table**:
- Full-width responsive table
- Headers: py-3 px-4 text-sm font-semibold
- Rows: py-4 px-4 border-b
- Sortable columns with icon indicators
- Row actions: Right-aligned button group

**Knowledge Source List**:
- Card-based list items: p-6 space-y-2
- Each item: Source icon, name (text-lg font-medium), status, last updated
- Grid on desktop: lg:grid-cols-2, single column mobile

### Modals & Overlays

**Agent Configuration Modal**:
- Centered overlay: max-w-3xl
- Header: p-6 border-b (title + close button)
- Body: p-6 max-h-[70vh] overflow-y-auto
- Footer: p-6 border-t (action buttons right-aligned)

**Critique & Validation Panel**:
- Slide-over from right: w-[600px]
- Sections: Validation rules, confidence scores, explanations
- Each validation: p-4 border-l-4 (indicator stripe)

### Value Monitoring Components

**ROI Calculator Card**:
- Featured card: p-8 rounded-xl border-2
- Input fields: grid grid-cols-2 gap-4
- Results: Large text display with trend charts
- Calculation breakdown: Collapsible section

**Risk Scoring Matrix**:
- Heatmap visualization: grid grid-cols-5
- Each cell: aspect-square p-2
- Tooltips on hover showing detailed metrics

---

## Responsive Behavior

**Breakpoints**:
- Mobile: < 768px (single column, hidden sidebar)
- Tablet: 768px - 1024px (2-column grids, collapsible sidebar)
- Desktop: > 1024px (full multi-column layouts)

**Mobile Adaptations**:
- Hamburger menu for navigation
- Stacked agent cards (grid-cols-1)
- Bottom sheet for modals
- Simplified graph views with drill-down

---

## Interaction Patterns

**Loading States**:
- Skeleton screens for dashboard cards
- Spinner for AI responses (16px icon, animated)
- Progress bars for long operations (h-1 rounded-full)

**Empty States**:
- Centered content with icon (w-16 h-16)
- Heading (text-xl) + description (text-base)
- Primary CTA button (mt-6)

**Notifications**:
- Toast position: fixed top-4 right-4
- Toast size: min-w-[320px] p-4
- Auto-dismiss after 5s with progress indicator

**Agent Status Indicators**:
- Badges: px-2.5 py-0.5 rounded-full text-xs font-medium
- States: Active, Idle, Processing, Error, Paused
- Include pulsing animation for active states

---

## Icons

**Library**: Heroicons (via CDN)
- Navigation: outline style, 24px
- Actions: outline style, 20px
- Status indicators: solid style, 16px
- Social proof: solid style, 20px

---

## Images

**Hero Section** (Landing/Overview):
- Large abstract visualization representing AI agent network
- Dimensions: Full viewport width, h-[500px]
- Overlaid elements: Page title (text-5xl), subtitle, CTA buttons with backdrop blur

**Agent Avatars**:
- Circular icons representing different agent types
- Size: w-12 h-12 for cards, w-8 h-8 for lists
- Use geometric/abstract patterns if custom illustrations unavailable

**Empty State Illustrations**:
- No agents configured, no data sources connected, etc.
- Simple line art style, max-w-xs mx-auto