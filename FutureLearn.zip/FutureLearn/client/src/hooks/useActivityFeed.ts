import { useState, useEffect } from "react";

export interface Activity {
  id: string;
  agentName: string;
  action: string;
  timestamp: string;
  type: "success" | "error" | "info" | "warning";
}

const mockActivities: Omit<Activity, 'id' | 'timestamp'>[] = [
  { agentName: 'Knowledge Navigator', action: 'Retrieved design documents for settlement configuration query', type: 'success' },
  { agentName: 'Adaptive Learning', action: 'Completed skill assessment for new user onboarding', type: 'success' },
  { agentName: 'Operational Copilot', action: 'Detected configuration conflict in deal template', type: 'warning' },
  { agentName: 'Knowledge Navigator', action: 'Successfully mapped knowledge graph relationships', type: 'success' },
  { agentName: 'Custom Agent', action: 'Validation check failed on data source integration', type: 'error' },
  { agentName: 'Adaptive Learning', action: 'Generated personalized learning path for ETRM workflows', type: 'info' },
  { agentName: 'Operational Copilot', action: 'Root cause analysis completed for incident #1247', type: 'success' },
  { agentName: 'Knowledge Navigator', action: 'Retrieved 5 SOPs related to commodity trading', type: 'success' },
  { agentName: 'Best Practices Agent', action: 'Identified design pattern conflict in proposed architecture', type: 'warning' },
  { agentName: 'Impact Analyzer', action: 'Change impact assessment completed', type: 'info' },
];

function getRandomActivity(): Omit<Activity, 'id' | 'timestamp'> {
  return mockActivities[Math.floor(Math.random() * mockActivities.length)];
}

function getRelativeTime(seconds: number): string {
  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  return `${hours}h ago`;
}

export function useActivityFeed(maxItems = 20) {
  const [activities, setActivities] = useState<Activity[]>(() => {
    const now = Date.now();
    return Array.from({ length: 5 }, (_, i) => {
      const activity = getRandomActivity();
      return {
        ...activity,
        id: `initial-${i}`,
        timestamp: getRelativeTime(Math.floor((5 + i * 3) * 60)),
      };
    });
  });

  const [startTime] = useState(Date.now());

  useEffect(() => {
    const updateInterval = setInterval(() => {
      setActivities(prev => 
        prev.map(activity => {
          const match = activity.id.match(/^(initial|activity)-(\d+)$/);
          if (match) {
            const baseSeconds = match[1] === 'initial' 
              ? (5 + parseInt(match[2]) * 3) * 60 
              : parseInt(match[2]);
            const elapsedSeconds = Math.floor((Date.now() - startTime) / 1000);
            return {
              ...activity,
              timestamp: getRelativeTime(baseSeconds + elapsedSeconds),
            };
          }
          return activity;
        })
      );
    }, 10000);

    const addInterval = setInterval(() => {
      const newActivity = getRandomActivity();
      const secondsAgo = Math.floor(Math.random() * 30);
      
      setActivities(prev => {
        const updated = [
          {
            ...newActivity,
            id: `activity-${secondsAgo}`,
            timestamp: getRelativeTime(secondsAgo),
          },
          ...prev
        ].slice(0, maxItems);
        return updated;
      });
    }, 15000 + Math.random() * 15000);

    return () => {
      clearInterval(updateInterval);
      clearInterval(addInterval);
    };
  }, [maxItems, startTime]);

  return activities;
}
