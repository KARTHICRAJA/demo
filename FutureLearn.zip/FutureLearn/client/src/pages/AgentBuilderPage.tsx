import AgentBuilder from "@/components/AgentBuilder";

export default function AgentBuilderPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2" data-testid="text-page-title">Custom Agent Builder</h1>
        <p className="text-muted-foreground">
          Create specialized AI agents tailored to specific analysis needs with configurable critique and validation features
        </p>
      </div>
      <AgentBuilder />
    </div>
  );
}
