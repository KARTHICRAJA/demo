import ActivityFeed from "@/components/ActivityFeed";
import { useActivityFeed } from "@/hooks/useActivityFeed";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { 
  FileText, 
  GitBranch, 
  Activity, 
  Briefcase, 
  Award, 
  Settings, 
  Network, 
  Wrench, 
  BarChart3, 
  MessageSquare,
  Sparkles,
  Users,
  ArrowRight
} from "lucide-react";
import heroImage from '@assets/generated_images/Hero_AI_network_visualization_c6f4a3fd.png'

export default function Welcome() {
  const activities = useActivityFeed(30);

  const shortcuts = [
    {
      title: "AI Agents",
      description: "Manage AI agents",
      icon: Sparkles,
      url: "/agents",
      color: "text-violet-500",
      bgColor: "bg-violet-500/10",
    },
    {
      title: "Endur Documents",
      description: "Browse structured documentation",
      icon: FileText,
      url: "/documents",
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
    },
    {
      title: "bp ETRM Process",
      description: "View process diagrams",
      icon: GitBranch,
      url: "/process",
      color: "text-emerald-500",
      bgColor: "bg-emerald-500/10",
    },
    {
      title: "Incident Analysis",
      description: "Monitor system health",
      icon: Activity,
      url: "/monitoring",
      color: "text-amber-500",
      bgColor: "bg-amber-500/10",
    },
    {
      title: "Business Analyst",
      description: "Create requirements",
      icon: Briefcase,
      url: "/business-analyst",
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
    },
    {
      title: "Architect",
      description: "Best practices & design",
      icon: Award,
      url: "/architect",
      color: "text-pink-500",
      bgColor: "bg-pink-500/10",
    },
    {
      title: "Ops Engineer",
      description: "Impact analysis",
      icon: Settings,
      url: "/ops-engineer",
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
    },
    {
      title: "Knowledge Graph",
      description: "Explore relationships",
      icon: Network,
      url: "/knowledge-graph",
      color: "text-cyan-500",
      bgColor: "bg-cyan-500/10",
    },
    {
      title: "Agent Builder",
      description: "Build custom agents",
      icon: Wrench,
      url: "/builder",
      color: "text-indigo-500",
      bgColor: "bg-indigo-500/10",
    },
    {
      title: "Metrics & Value",
      description: "Track ROI & performance",
      icon: BarChart3,
      url: "/metrics",
      color: "text-green-500",
      bgColor: "bg-green-500/10",
    },
    {
      title: "AI Insights",
      description: "Event analysis & recommendations",
      icon: Sparkles,
      url: "/insights",
      color: "text-violet-500",
      bgColor: "bg-violet-500/10",
    },
    {
      title: "User Administration",
      description: "Manage users & roles",
      icon: Users,
      url: "/users",
      color: "text-teal-500",
      bgColor: "bg-teal-500/10",
    },
    {
      title: "AI Chat",
      description: "Chat with AI assistants",
      icon: MessageSquare,
      url: "/chat",
      color: "text-rose-500",
      bgColor: "bg-rose-500/10",
    },
  ];

  return (
    <div className="space-y-6">
      <div className="relative h-[300px] rounded-lg overflow-hidden">
        <img src={heroImage} alt="AI Network" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/80 to-transparent flex items-center">
          <div className="px-8 space-y-4 max-w-2xl">
            <h1 className="text-4xl font-bold" data-testid="text-hero-title">
              Welcome to Endur HyperIQ
            </h1>
            <p className="text-lg text-muted-foreground">
              Transform institutional knowledge into actionable intelligence with AI-powered agents
            </p>
          </div>
        </div>
      </div>

      <div>
        <h2 className="text-2xl font-semibold mb-4">Quick Access</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {shortcuts.map((shortcut) => (
            <Link key={shortcut.url} href={shortcut.url}>
              <Card className="hover-elevate cursor-pointer transition-all h-full" data-testid={`shortcut-${shortcut.url.slice(1)}`}>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className={`w-12 h-12 rounded-md ${shortcut.bgColor} flex items-center justify-center flex-shrink-0`}>
                      <shortcut.icon className={`w-6 h-6 ${shortcut.color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold mb-1 flex items-center gap-2">
                        {shortcut.title}
                        <ArrowRight className="w-4 h-4 text-muted-foreground" />
                      </h3>
                      <p className="text-sm text-muted-foreground">{shortcut.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      <div>
        <ActivityFeed activities={activities} />
      </div>
    </div>
  );
}
