import PageLayout from "@/components/sections/PageLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowRight, GitBranch, Workflow, Zap, FileCheck, DollarSign } from "lucide-react";

export default function ETRMProcess() {
  const tradingProcess = [
    { step: 1, name: "Deal Capture", desc: "Enter trade details and counterparty", duration: "2-5 min" },
    { step: 2, name: "Validation", desc: "Credit check and risk limits", duration: "1-2 min" },
    { step: 3, name: "Confirmation", desc: "Send/receive trade confirmations", duration: "5-10 min" },
    { step: 4, name: "Settlement", desc: "Invoice generation and payment", duration: "1-2 days" },
    { step: 5, name: "Accounting", desc: "GL posting and financial reporting", duration: "End of day" },
  ];

  const riskProcess = [
    { step: 1, name: "Position Extraction", desc: "Extract portfolio positions", duration: "5 min" },
    { step: 2, name: "Market Data Update", desc: "Refresh forward curves and prices", duration: "10 min" },
    { step: 3, name: "Valuation", desc: "Mark-to-market calculations", duration: "15 min" },
    { step: 4, name: "Risk Metrics", desc: "VaR, Greeks, and exposure analysis", duration: "20 min" },
    { step: 5, name: "Reporting", desc: "Generate risk reports", duration: "10 min" },
  ];

  const settlementProcess = [
    { step: 1, name: "Volume Extraction", desc: "Extract physical delivery volumes", duration: "5 min" },
    { step: 2, name: "Price Application", desc: "Apply settlement prices from curves", duration: "10 min" },
    { step: 3, name: "Invoice Generation", desc: "Create invoices with line items", duration: "15 min" },
    { step: 4, name: "Approval Workflow", desc: "Review and approve invoices", duration: "1-2 days" },
    { step: 5, name: "Payment Processing", desc: "Send to AP/AR for payment", duration: "3-5 days" },
  ];

  const keyMetrics = [
    { label: "Avg Deal Capture Time", value: "3.5 min", change: "-15%", icon: Zap, color: "text-emerald-500" },
    { label: "Risk Calculation Time", value: "45 min", change: "-22%", icon: GitBranch, color: "text-blue-500" },
    { label: "Settlement Accuracy", value: "99.2%", change: "+2.1%", icon: FileCheck, color: "text-purple-500" },
    { label: "Daily Trading Volume", value: "$24M", change: "+18%", icon: DollarSign, color: "text-amber-500" },
  ];

  return (
    <PageLayout
      title="bp ETRM Business Processes"
      description="bp's energy trading lifecycle with process optimization insights and efficiency metrics"
    >
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {keyMetrics.map((metric, idx) => (
          <Card key={idx}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-2">
                <div className={`w-10 h-10 rounded-md bg-card border flex items-center justify-center ${metric.color}`}>
                  <metric.icon className="w-5 h-5" />
                </div>
                <Badge variant={metric.change.startsWith('+') ? 'secondary' : 'outline'} className="text-xs">
                  {metric.change}
                </Badge>
              </div>
              <p className="text-2xl font-bold mb-1">{metric.value}</p>
              <p className="text-xs text-muted-foreground">{metric.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="trading">
        <TabsList>
          <TabsTrigger value="trading">Trading Lifecycle</TabsTrigger>
          <TabsTrigger value="risk">Risk Management</TabsTrigger>
          <TabsTrigger value="settlement">Settlement Flow</TabsTrigger>
        </TabsList>

        <TabsContent value="trading" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Workflow className="w-5 h-5 text-primary" />
                Trading Lifecycle Process
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex items-center justify-between gap-4 overflow-x-auto pb-4">
                  {tradingProcess.map((step, idx) => (
                    <div key={step.step} className="flex items-center gap-4">
                      <div className="flex-shrink-0 min-w-[200px]">
                        <Card className="hover-elevate">
                          <CardContent className="p-4">
                            <Badge className="mb-2">{step.step}</Badge>
                            <h4 className="font-semibold mb-1">{step.name}</h4>
                            <p className="text-xs text-muted-foreground mb-2">{step.desc}</p>
                            <Badge variant="outline" className="text-xs">⏱️ {step.duration}</Badge>
                          </CardContent>
                        </Card>
                      </div>
                      {idx < tradingProcess.length - 1 && (
                        <ArrowRight className="w-6 h-6 text-primary flex-shrink-0" />
                      )}
                    </div>
                  ))}
                </div>

                <Card className="bg-muted/50">
                  <CardContent className="p-6">
                    <h4 className="font-semibold mb-3">bp Trading Lifecycle Insights</h4>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span><strong>Real-time credit management:</strong> bp's automated credit engine monitors $2B+ in daily exposure across 500+ counterparties with sub-second validation</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span><strong>Multi-commodity coverage:</strong> Unified workflow handles natural gas, power, crude oil, refined products, and renewable energy certificates</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span><strong>Automated confirmations:</strong> 95% of trades electronically confirmed within 30 minutes via SWIFT, ICE, and proprietary platforms</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span><strong>Template optimization:</strong> 50+ standardized deal templates reduce capture time by 60% while maintaining compliance</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span><strong>Straight-through processing:</strong> 80% of standard deals flow from capture to accounting without manual intervention</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="risk" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GitBranch className="w-5 h-5 text-primary" />
                Risk Management Process
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex items-center justify-between gap-4 overflow-x-auto pb-4">
                  {riskProcess.map((step, idx) => (
                    <div key={step.step} className="flex items-center gap-4">
                      <div className="flex-shrink-0 min-w-[200px]">
                        <Card className="hover-elevate">
                          <CardContent className="p-4">
                            <Badge className="mb-2">{step.step}</Badge>
                            <h4 className="font-semibold mb-1">{step.name}</h4>
                            <p className="text-xs text-muted-foreground mb-2">{step.desc}</p>
                            <Badge variant="outline" className="text-xs">⏱️ {step.duration}</Badge>
                          </CardContent>
                        </Card>
                      </div>
                      {idx < riskProcess.length - 1 && (
                        <ArrowRight className="w-6 h-6 text-primary flex-shrink-0" />
                      )}
                    </div>
                  ))}
                </div>

                <Card className="bg-muted/50">
                  <CardContent className="p-6">
                    <h4 className="font-semibold mb-3">bp Risk Management Insights</h4>
                    <div className="space-y-3 mb-4">
                      <ul className="space-y-2 text-sm">
                        <li className="flex items-start gap-2">
                          <span className="text-primary">•</span>
                          <span><strong>Portfolio-wide risk aggregation:</strong> Real-time consolidation across natural gas, power, oil, and products portfolios</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-primary">•</span>
                          <span><strong>Advanced Greeks calculation:</strong> Delta, gamma, vega computed for options across all commodity types</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-primary">•</span>
                          <span><strong>Stress testing:</strong> Multiple scenario analysis including price shocks, volatility spikes, and liquidity crises</span>
                        </li>
                      </ul>
                    </div>
                    <div className="grid grid-cols-3 gap-4 pt-3 border-t">
                      <div>
                        <p className="text-xs text-muted-foreground">Value at Risk (95%)</p>
                        <p className="text-2xl font-bold">$2.4M</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Delta Exposure</p>
                        <p className="text-2xl font-bold">1,247 MW</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Active Positions</p>
                        <p className="text-2xl font-bold">342</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settlement" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-primary" />
                Settlement Workflow
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex items-center justify-between gap-4 overflow-x-auto pb-4">
                  {settlementProcess.map((step, idx) => (
                    <div key={step.step} className="flex items-center gap-4">
                      <div className="flex-shrink-0 min-w-[200px]">
                        <Card className="hover-elevate">
                          <CardContent className="p-4">
                            <Badge className="mb-2">{step.step}</Badge>
                            <h4 className="font-semibold mb-1">{step.name}</h4>
                            <p className="text-xs text-muted-foreground mb-2">{step.desc}</p>
                            <Badge variant="outline" className="text-xs">⏱️ {step.duration}</Badge>
                          </CardContent>
                        </Card>
                      </div>
                      {idx < settlementProcess.length - 1 && (
                        <ArrowRight className="w-6 h-6 text-primary flex-shrink-0" />
                      )}
                    </div>
                  ))}
                </div>

                <Card className="bg-muted/50">
                  <CardContent className="p-6">
                    <h4 className="font-semibold mb-3">Settlement Best Practices</h4>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>Automated price curve application reduces manual errors by 95%</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>Approval workflows ensure compliance with corporate policies</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>Integration with accounting systems provides real-time GL visibility</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>Reconciliation tools match invoices against physical delivery data</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </PageLayout>
  );
}
