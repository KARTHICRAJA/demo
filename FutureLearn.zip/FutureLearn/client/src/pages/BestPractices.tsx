import PageLayout from "@/components/sections/PageLayout";
import QueryConsole from "@/components/sections/QueryConsole";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Award, BookOpen, Code, Shield } from "lucide-react";

export default function BestPractices() {
  const categories = [
    {
      id: "architecture",
      icon: Code,
      title: "Architecture & Design",
      count: 12,
      color: "text-primary",
    },
    {
      id: "security",
      icon: Shield,
      title: "Security & Compliance",
      count: 8,
      color: "text-emerald-500",
    },
    {
      id: "performance",
      icon: Award,
      title: "Performance & Optimization",
      count: 10,
      color: "text-amber-500",
    },
    {
      id: "process",
      icon: BookOpen,
      title: "Process & Methodology",
      count: 15,
      color: "text-blue-500",
    },
  ];

  const architecturePractices = [
    {
      title: "Separation of Concerns",
      description: "Keep business logic separate from presentation layer. Use service layers for complex operations.",
      keyDecisions: ["Implemented service-oriented architecture", "Created reusable business rule engine"],
      impact: "High",
    },
    {
      title: "Configuration Over Customization",
      description: "Prefer configurable templates over code customizations when possible.",
      keyDecisions: ["Built flexible deal template framework", "Parameterized settlement rules"],
      impact: "Medium",
    },
  ];

  const securityPractices = [
    {
      title: "Role-Based Access Control",
      description: "Implement granular permissions based on user roles and responsibilities.",
      keyDecisions: ["Defined 12 standard roles", "Created approval workflows for sensitive operations"],
      impact: "High",
    },
  ];

  const querySuggestions = [
    "What are the best practices for deal template design?",
    "Show me security guidelines for API integrations",
    "How should we handle performance optimization?",
  ];

  return (
    <PageLayout
      title="Best Practices & Design Decisions"
      description="Queryable knowledge base of proven practices and key architectural decisions"
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            {categories.map((category) => (
              <Card key={category.id} className="hover-elevate cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <div className={`w-12 h-12 rounded-md bg-card border flex items-center justify-center ${category.color}`}>
                      <category.icon className="w-6 h-6" />
                    </div>
                    <Badge variant="secondary">{category.count}</Badge>
                  </div>
                  <h3 className="font-semibold">{category.title}</h3>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Architecture & Design Practices</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                {architecturePractices.map((practice, idx) => (
                  <AccordionItem key={idx} value={`item-${idx}`}>
                    <AccordionTrigger>
                      <div className="flex items-center gap-3">
                        <span>{practice.title}</span>
                        <Badge variant={practice.impact === 'High' ? 'default' : 'secondary'} className="text-xs">
                          {practice.impact} Impact
                        </Badge>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="space-y-3">
                      <p className="text-sm text-muted-foreground">{practice.description}</p>
                      <div>
                        <p className="text-sm font-medium mb-2">Key Decisions:</p>
                        <ul className="space-y-1">
                          {practice.keyDecisions.map((decision, didx) => (
                            <li key={didx} className="text-sm text-muted-foreground flex items-start gap-2">
                              <span className="text-primary">•</span>
                              {decision}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Security & Compliance Practices</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                {securityPractices.map((practice, idx) => (
                  <AccordionItem key={idx} value={`sec-${idx}`}>
                    <AccordionTrigger>
                      <div className="flex items-center gap-3">
                        <span>{practice.title}</span>
                        <Badge variant="default" className="text-xs">
                          {practice.impact} Impact
                        </Badge>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="space-y-3">
                      <p className="text-sm text-muted-foreground">{practice.description}</p>
                      <div>
                        <p className="text-sm font-medium mb-2">Key Decisions:</p>
                        <ul className="space-y-1">
                          {practice.keyDecisions.map((decision, didx) => (
                            <li key={didx} className="text-sm text-muted-foreground flex items-start gap-2">
                              <span className="text-primary">•</span>
                              {decision}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <QueryConsole
            title="Search Best Practices"
            placeholder="Search for design decisions, patterns, or guidelines..."
            suggestions={querySuggestions}
            onQuery={(q) => console.log('Search:', q)}
          />

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Recently Updated</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="text-sm p-3 rounded-md border">
                <Badge variant="outline" className="mb-2 text-xs">Architecture</Badge>
                <p className="font-medium mb-1">Microservices Integration Pattern</p>
                <p className="text-xs text-muted-foreground">Updated 3 days ago</p>
              </div>
              <div className="text-sm p-3 rounded-md border">
                <Badge variant="outline" className="mb-2 text-xs">Security</Badge>
                <p className="font-medium mb-1">API Authentication Guidelines</p>
                <p className="text-xs text-muted-foreground">Updated 1 week ago</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Total Practices</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <p className="text-4xl font-bold text-primary" data-testid="text-total-practices">45</p>
                <p className="text-sm text-muted-foreground mt-1">Documented best practices</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageLayout>
  );
}
