import PageLayout from "@/components/sections/PageLayout";
import QueryConsole from "@/components/sections/QueryConsole";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertTriangle, Bug, TrendingDown, AlertCircle, Lightbulb, GitBranch } from "lucide-react";

export default function AIInsights() {
  const recentIncidents = [
    {
      id: 1,
      type: "bug",
      severity: "high",
      title: "Memory leak in real-time pricing calculation",
      insight: "Pattern detected: Similar issues occurred 3 times in past 6 months during high-volume trading periods. Root cause likely related to unclosed database connections in pricing engine.",
      affectedSystems: ["Pricing Engine", "Market Data Feed"],
      timestamp: "2 hours ago",
      status: "analyzing",
    },
    {
      id: 2,
      type: "incident",
      severity: "critical",
      title: "Settlement batch job failure",
      insight: "AI detected correlation with recent schema change in invoices table. Recommended rollback to previous version while investigating data migration issues.",
      affectedSystems: ["Settlement System", "Invoice Generator"],
      timestamp: "1 day ago",
      status: "resolved",
    },
    {
      id: 3,
      type: "error",
      severity: "medium",
      title: "API timeout in position extraction",
      insight: "Recurring pattern every Monday at 8 AM. Likely caused by weekend data accumulation. Suggested solution: Implement incremental extraction instead of full batch.",
      affectedSystems: ["Position Service", "Risk Engine"],
      timestamp: "3 days ago",
      status: "monitoring",
    },
  ];

  const changeRequests = [
    {
      id: 1,
      title: "Upgrade forward curve pricing model",
      aiRecommendation: "Low risk change. Similar upgrades in dev environment showed 15% performance improvement with no breaking changes.",
      impactScore: 8.5,
      dependencies: ["Market Data Module", "Valuation Engine"],
      estimatedEffort: "2-3 days",
    },
    {
      id: 2,
      title: "Migrate legacy deal templates to new format",
      aiRecommendation: "High impact change affecting 234 active deal templates. Recommend phased migration starting with commodity deals (lowest risk).",
      impactScore: 9.2,
      dependencies: ["Deal Capture", "Template Engine", "Validation Service"],
      estimatedEffort: "2-3 weeks",
    },
  ];

  const deprecatedConfigs = [
    {
      config: "Legacy XML-based price curve format",
      usage: "Used in 12 active workflows",
      deprecationDate: "June 2024",
      replacement: "JSON-based curve format v2.0",
      migrationPath: "Automated migration tool available",
      dependencies: [
        { system: "Forward Curve Builder", count: 5 },
        { system: "Historical Price Loader", count: 4 },
        { system: "Risk Calculation Engine", count: 3 },
      ],
      riskLevel: "medium",
    },
    {
      config: "Old settlement calculation ruleset (v1.x)",
      usage: "Used in 8 active workflows",
      deprecationDate: "March 2024",
      replacement: "Enhanced ruleset v2.5 with formula auditing",
      migrationPath: "Manual review required for custom rules",
      dependencies: [
        { system: "Physical Settlement", count: 5 },
        { system: "Financial Settlement", count: 3 },
      ],
      riskLevel: "high",
    },
    {
      config: "SOAP-based market data connector",
      usage: "Used in 3 active workflows",
      deprecationDate: "December 2024",
      replacement: "REST API with WebSocket streaming",
      migrationPath: "Drop-in replacement available",
      dependencies: [
        { system: "Real-time Market Data", count: 2 },
        { system: "End-of-Day Price Feed", count: 1 },
      ],
      riskLevel: "low",
    },
  ];

  const insights = [
    {
      icon: Lightbulb,
      title: "Proactive Recommendation",
      description: "Based on historical patterns, system predicts 80% chance of increased trade volume next week. Consider scaling pricing engine resources.",
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
    },
    {
      icon: TrendingDown,
      title: "Cost Optimization",
      description: "AI identified 5 unused database connections consuming resources. Estimated savings: $450/month.",
      color: "text-emerald-500",
      bgColor: "bg-emerald-500/10",
    },
  ];

  const querySuggestions = [
    "What are the common patterns in recent incidents?",
    "Show impact analysis for deprecated configurations",
    "Which change requests have the highest risk?",
  ];

  return (
    <PageLayout
      title="AI Insights & Event Analysis"
      description="AI-powered analysis of system events, deprecated configurations, and proactive recommendations"
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            {insights.map((insight, idx) => (
              <Card key={idx} className="hover-elevate">
                <CardContent className="p-6">
                  <div className={`w-12 h-12 rounded-md ${insight.bgColor} flex items-center justify-center mb-4 ${insight.color}`}>
                    <insight.icon className="w-6 h-6" />
                  </div>
                  <h3 className="font-semibold mb-2">{insight.title}</h3>
                  <p className="text-sm text-muted-foreground">{insight.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <Tabs defaultValue="events">
            <TabsList>
              <TabsTrigger value="events">Recent Events</TabsTrigger>
              <TabsTrigger value="changes">Change Requests</TabsTrigger>
              <TabsTrigger value="deprecated">Deprecated Configs</TabsTrigger>
            </TabsList>

            <TabsContent value="events" className="space-y-4 mt-6">
              {recentIncidents.map((incident) => (
                <Card key={incident.id} className="hover-elevate">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-start gap-3">
                        <div className={`w-10 h-10 rounded-md flex items-center justify-center ${
                          incident.severity === 'critical' ? 'bg-red-500/10 text-red-500' :
                          incident.severity === 'high' ? 'bg-orange-500/10 text-orange-500' :
                          'bg-yellow-500/10 text-yellow-500'
                        }`}>
                          {incident.type === 'bug' ? <Bug className="w-5 h-5" /> :
                           incident.type === 'incident' ? <AlertTriangle className="w-5 h-5" /> :
                           <AlertCircle className="w-5 h-5" />}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-semibold">{incident.title}</h3>
                            <Badge variant={
                              incident.severity === 'critical' ? 'destructive' :
                              incident.severity === 'high' ? 'default' : 'secondary'
                            } className="text-xs">
                              {incident.severity}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">{incident.timestamp}</p>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {incident.status}
                      </Badge>
                    </div>
                    <div className="bg-primary/5 border-l-4 border-primary p-4 rounded-md mb-3">
                      <p className="text-sm font-medium mb-1">AI Insight:</p>
                      <p className="text-sm text-muted-foreground">{incident.insight}</p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {incident.affectedSystems.map((system, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {system}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="changes" className="space-y-4 mt-6">
              {changeRequests.map((request) => (
                <Card key={request.id} className="hover-elevate">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-3">
                      <h3 className="font-semibold">{request.title}</h3>
                      <Badge variant="default" className="text-xs">
                        Impact: {request.impactScore}/10
                      </Badge>
                    </div>
                    <div className="bg-blue-500/5 border-l-4 border-blue-500 p-4 rounded-md mb-3">
                      <p className="text-sm font-medium mb-1">AI Recommendation:</p>
                      <p className="text-sm text-muted-foreground">{request.aiRecommendation}</p>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <span className="font-medium">Estimated Effort:</span>
                        <Badge variant="outline" className="text-xs">{request.estimatedEffort}</Badge>
                      </div>
                      <div>
                        <p className="text-sm font-medium mb-2">Dependencies:</p>
                        <div className="flex flex-wrap gap-2">
                          {request.dependencies.map((dep, idx) => (
                            <Badge key={idx} variant="secondary" className="text-xs">
                              {dep}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="deprecated" className="space-y-4 mt-6">
              {deprecatedConfigs.map((config, idx) => (
                <Card key={idx} className="hover-elevate">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-start gap-3">
                        <div className={`w-10 h-10 rounded-md flex items-center justify-center ${
                          config.riskLevel === 'high' ? 'bg-red-500/10 text-red-500' :
                          config.riskLevel === 'medium' ? 'bg-yellow-500/10 text-yellow-500' :
                          'bg-green-500/10 text-green-500'
                        }`}>
                          <GitBranch className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="font-semibold mb-1">{config.config}</h3>
                          <p className="text-sm text-muted-foreground">{config.usage}</p>
                        </div>
                      </div>
                      <Badge variant={
                        config.riskLevel === 'high' ? 'destructive' :
                        config.riskLevel === 'medium' ? 'default' : 'secondary'
                      } className="text-xs">
                        {config.riskLevel} risk
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Deprecated Since</p>
                        <p className="text-sm font-medium">{config.deprecationDate}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Replacement</p>
                        <p className="text-sm font-medium">{config.replacement}</p>
                      </div>
                    </div>

                    <div className="bg-muted/50 p-4 rounded-md mb-4">
                      <p className="text-sm font-medium mb-1">Migration Path:</p>
                      <p className="text-sm text-muted-foreground">{config.migrationPath}</p>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Dependent Systems:</p>
                      <div className="space-y-2">
                        {config.dependencies.map((dep, didx) => (
                          <div key={didx} className="flex items-center justify-between p-2 rounded-md border">
                            <span className="text-sm">{dep.system}</span>
                            <Badge variant="outline" className="text-xs">
                              {dep.count} workflows
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <QueryConsole
            title="Ask AI About Events"
            placeholder="Query insights, patterns, or recommendations..."
            suggestions={querySuggestions}
            onQuery={(q) => console.log('Query:', q)}
          />

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Analysis Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center p-4 rounded-md border">
                <p className="text-3xl font-bold text-red-500">3</p>
                <p className="text-sm text-muted-foreground mt-1">Active Incidents</p>
              </div>
              <div className="text-center p-4 rounded-md border">
                <p className="text-3xl font-bold text-blue-500">2</p>
                <p className="text-sm text-muted-foreground mt-1">Pending Changes</p>
              </div>
              <div className="text-center p-4 rounded-md border">
                <p className="text-3xl font-bold text-yellow-500">3</p>
                <p className="text-sm text-muted-foreground mt-1">Deprecated Configs</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageLayout>
  );
}
