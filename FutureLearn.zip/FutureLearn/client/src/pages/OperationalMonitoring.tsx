import { useState } from "react";
import PageLayout from "@/components/sections/PageLayout";
import QueryConsole from "@/components/sections/QueryConsole";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, CheckCircle, Clock, Search } from "lucide-react";

export default function OperationalMonitoring() {
  const [investigating, setInvestigating] = useState(false);

  const recentIncidents = [
    {
      id: "INC-2847",
      title: "Settlement calculation timeout",
      severity: "high",
      status: "investigating",
      time: "15m ago",
      rootCause: "Database query optimization needed for large position sets",
    },
    {
      id: "INC-2846",
      title: "Market data feed latency",
      severity: "medium",
      status: "resolved",
      time: "2h ago",
      rootCause: "Network congestion during peak hours",
    },
    {
      id: "INC-2845",
      title: "Deal confirmation failure",
      severity: "high",
      status: "resolved",
      time: "4h ago",
      rootCause: "Email service configuration error",
    },
  ];

  const rootCausePatterns = [
    { category: "Database Performance", count: 12, percentage: 35 },
    { category: "Integration Failures", count: 8, percentage: 24 },
    { category: "Configuration Issues", count: 7, percentage: 21 },
    { category: "External Dependencies", count: 7, percentage: 20 },
  ];

  const querySuggestions = [
    "Why did settlement fail for gas contracts?",
    "Analyze performance degradation pattern",
    "Find incidents related to pricing engine",
  ];

  return (
    <PageLayout
      title="Incident Analysis"
      description="Real-time incident tracking, root cause analysis, and operational data investigation"
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Tabs defaultValue="incidents">
            <TabsList>
              <TabsTrigger value="incidents">Active Incidents</TabsTrigger>
              <TabsTrigger value="patterns">Root Cause Patterns</TabsTrigger>
            </TabsList>

            <TabsContent value="incidents" className="space-y-4 mt-6">
              {recentIncidents.map((incident) => (
                <Card key={incident.id} className="hover-elevate">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between gap-4 mb-3">
                      <div className="flex items-start gap-3">
                        <div className={`mt-1 ${
                          incident.severity === 'high' ? 'text-red-500' : 'text-amber-500'
                        }`}>
                          {incident.status === 'resolved' ? (
                            <CheckCircle className="w-5 h-5 text-emerald-500" />
                          ) : (
                            <AlertCircle className="w-5 h-5" />
                          )}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <Badge variant="outline" className="font-mono text-xs">
                              {incident.id}
                            </Badge>
                            <Badge
                              variant={incident.severity === 'high' ? 'destructive' : 'secondary'}
                              className="text-xs"
                            >
                              {incident.severity}
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              {incident.status}
                            </Badge>
                          </div>
                          <h4 className="font-semibold mb-1">{incident.title}</h4>
                          <p className="text-sm text-muted-foreground mb-2">
                            Root Cause: {incident.rootCause}
                          </p>
                          <p className="text-xs text-muted-foreground flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {incident.time}
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="patterns" className="space-y-4 mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Top Root Causes (Last 30 Days)</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {rootCausePatterns.map((pattern) => (
                    <div key={pattern.category} className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>{pattern.category}</span>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold">{pattern.count} incidents</span>
                          <Badge variant="outline">{pattern.percentage}%</Badge>
                        </div>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full bg-primary"
                          style={{ width: `${pattern.percentage}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <QueryConsole
            title="Investigate Incident"
            placeholder="Describe the issue or ask about operational data..."
            suggestions={querySuggestions}
            onQuery={(q) => {
              console.log('Investigating:', q);
              setInvestigating(true);
              setTimeout(() => setInvestigating(false), 3000);
            }}
          />

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Search className="w-5 h-5 text-primary" />
                Investigation Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              {investigating ? (
                <div className="space-y-3">
                  <p className="text-sm">Analyzing operational logs...</p>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                      Scanning incident database
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                      Correlating with system metrics
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Use the query console to investigate incidents and analyze patterns
                </p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">System Health</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">Uptime</span>
                <Badge variant="secondary" className="bg-emerald-500/10 text-emerald-500 border-0">
                  99.94%
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Active Alerts</span>
                <Badge variant="outline">2</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">MTTR</span>
                <Badge variant="outline">12.4m</Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageLayout>
  );
}
