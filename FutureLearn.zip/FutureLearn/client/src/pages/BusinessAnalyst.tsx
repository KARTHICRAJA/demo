import { useState } from "react";
import PageLayout from "@/components/sections/PageLayout";
import QueryConsole from "@/components/sections/QueryConsole";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { FileText, Lightbulb, CheckCircle } from "lucide-react";

export default function BusinessAnalyst() {
  const [reqTitle, setReqTitle] = useState("");
  const [reqDescription, setReqDescription] = useState("");

  const templates = [
    {
      id: "deal-template",
      title: "New Deal Template",
      desc: "Create custom deal type with workflow",
      fields: 5,
    },
    {
      id: "report-req",
      title: "Reporting Requirement",
      desc: "New report or dashboard specification",
      fields: 4,
    },
    {
      id: "integration",
      title: "System Integration",
      desc: "External system interface requirement",
      fields: 6,
    },
  ];

  const bestPractices = [
    "Define clear acceptance criteria for each requirement",
    "Include data validation rules and error handling",
    "Specify user roles and access permissions",
    "Document dependencies on existing configurations",
  ];

  const querySuggestions = [
    "How should I structure a deal template requirement?",
    "What are best practices for reporting requirements?",
    "Show me examples of integration requirements",
  ];

  return (
    <PageLayout
      title="Business Analyst Workspace"
      description="Detail business requirements using system knowledge and industry best practices"
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" />
                New Business Requirement
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="req-title">Requirement Title</Label>
                <Input
                  id="req-title"
                  placeholder="e.g., Power Trading Deal Template Enhancement"
                  value={reqTitle}
                  onChange={(e) => setReqTitle(e.target.value)}
                  data-testid="input-requirement-title"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="req-description">Description</Label>
                <Textarea
                  id="req-description"
                  placeholder="Describe the business requirement in detail..."
                  value={reqDescription}
                  onChange={(e) => setReqDescription(e.target.value)}
                  className="min-h-[120px]"
                  data-testid="input-requirement-description"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="business-unit">Business Unit</Label>
                  <Input id="business-unit" placeholder="e.g., Power Trading" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="priority">Priority</Label>
                  <Input id="priority" placeholder="High / Medium / Low" />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Impacted Systems</Label>
                <div className="flex flex-wrap gap-2">
                  {['Endur', 'SAP', 'Risk Engine', 'Reporting'].map((system) => (
                    <Badge key={system} variant="outline" className="cursor-pointer hover-elevate">
                      {system}
                    </Badge>
                  ))}
                </div>
              </div>

              <Button className="w-full" data-testid="button-save-requirement">
                <CheckCircle className="w-4 h-4 mr-2" />
                Save Requirement
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Requirement Templates</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {templates.map((template) => (
                  <Card key={template.id} className="hover-elevate cursor-pointer">
                    <CardContent className="p-4">
                      <h4 className="font-semibold mb-1 text-sm">{template.title}</h4>
                      <p className="text-xs text-muted-foreground mb-2">{template.desc}</p>
                      <Badge variant="secondary" className="text-xs">
                        {template.fields} fields
                      </Badge>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <QueryConsole
            title="Requirement Assistant"
            placeholder="Ask about requirement templates, best practices, or examples..."
            suggestions={querySuggestions}
            onQuery={(q) => console.log('Query:', q)}
          />

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Lightbulb className="w-5 h-5 text-amber-500" />
                Best Practices
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                {bestPractices.map((practice, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
                    <span>{practice}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Recent Requirements</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="text-sm p-3 rounded-md border hover-elevate cursor-pointer">
                <p className="font-medium mb-1">Gas Deal Template</p>
                <p className="text-xs text-muted-foreground">Updated 2 days ago</p>
              </div>
              <div className="text-sm p-3 rounded-md border hover-elevate cursor-pointer">
                <p className="font-medium mb-1">Risk Report Enhancement</p>
                <p className="text-xs text-muted-foreground">Updated 5 days ago</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageLayout>
  );
}
