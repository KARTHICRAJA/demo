import { useState } from "react";
import PageLayout from "@/components/sections/PageLayout";
import AgentCard from "@/components/AgentCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Sparkles } from "lucide-react";
import knowledgeIcon from '@assets/generated_images/Knowledge_Navigator_agent_icon_fb59e30c.png'
import learningIcon from '@assets/generated_images/Adaptive_Learning_agent_icon_6fc8d570.png'
import copilotIcon from '@assets/generated_images/Operational_Copilot_agent_icon_255146df.png'

export default function AIAgents() {
  type AgentStatus = "active" | "idle" | "processing" | "paused";
  
  const [builtInAgents, setBuiltInAgents] = useState<Array<{
    id: string;
    name: string;
    description: string;
    status: AgentStatus;
    icon: string;
    metrics: { queries: number; accuracy: number; avgResponseTime: string };
  }>>([
    {
      id: 'knowledge-nav',
      name: "Knowledge Navigator",
      description: "Hybrid RAG with semantic search and graph traversal",
      status: "active",
      icon: knowledgeIcon,
      metrics: { queries: 1247, accuracy: 94, avgResponseTime: "1.2s" },
    },
    {
      id: 'adaptive-learning',
      name: "Adaptive Learning Companion",
      description: "Personalized learning paths with skill gap assessment",
      status: "active",
      icon: learningIcon,
      metrics: { queries: 834, accuracy: 91, avgResponseTime: "0.8s" },
    },
    {
      id: 'operational-copilot',
      name: "Operational Copilot",
      description: "Real-time troubleshooting and root cause analysis",
      status: "idle",
      icon: copilotIcon,
      metrics: { queries: 456, accuracy: 96, avgResponseTime: "1.5s" },
    },
  ]);

  const [customAgents, setCustomAgents] = useState<Array<{
    id: string;
    name: string;
    description: string;
    status: AgentStatus;
    createdBy: string;
    lastModified: string;
    metrics: { queries: number; accuracy: number; avgResponseTime: string };
  }>>([
    {
      id: 'custom-1',
      name: "Deal Validator",
      description: "Custom agent for pre-trade compliance validation",
      status: "active",
      createdBy: "John Smith",
      lastModified: "2 days ago",
      metrics: { queries: 234, accuracy: 98, avgResponseTime: "0.6s" },
    },
    {
      id: 'custom-2',
      name: "Settlement Analyzer",
      description: "Analyzes settlement patterns and identifies anomalies",
      status: "active",
      createdBy: "Sarah Johnson",
      lastModified: "1 week ago",
      metrics: { queries: 156, accuracy: 93, avgResponseTime: "1.1s" },
    },
  ]);

  const toggleBuiltInAgent = (id: string) => {
    setBuiltInAgents(prev => prev.map(agent => {
      if (agent.id === id) {
        const isActive = agent.status === "active" || agent.status === "processing";
        return { ...agent, status: (isActive ? "paused" : "active") as AgentStatus };
      }
      return agent;
    }));
  };

  const toggleCustomAgent = (id: string) => {
    setCustomAgents(prev => prev.map(agent => {
      if (agent.id === id) {
        const isActive = agent.status === "active" || agent.status === "processing";
        return { ...agent, status: (isActive ? "paused" : "active") as AgentStatus };
      }
      return agent;
    }));
  };

  return (
    <PageLayout
      title="AI Agents"
      description="Manage built-in and custom AI agents for knowledge management and automation"
    >
      <div className="space-y-8">
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-semibold">Built-in Agents</h2>
            <Badge variant="secondary" className="text-sm">
              {builtInAgents.filter(a => a.status === "active").length} Active
            </Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {builtInAgents.map((agent) => (
              <AgentCard
                key={agent.id}
                {...agent}
                onToggle={() => toggleBuiltInAgent(agent.id)}
                onConfigure={() => console.log('Configure', agent.id)}
              />
            ))}
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-semibold">Custom Agents</h2>
            <Button data-testid="button-create-agent">
              <Plus className="w-4 h-4 mr-2" />
              Create Agent
            </Button>
          </div>
          
          {customAgents.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {customAgents.map((agent) => (
                <Card key={agent.id} className="hover-elevate" data-testid={`custom-agent-${agent.id}`}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg mb-1">{agent.name}</CardTitle>
                        <p className="text-sm text-muted-foreground">{agent.description}</p>
                      </div>
                      <Badge variant={agent.status === "active" ? "default" : "outline"} className="ml-2">
                        {agent.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="grid grid-cols-3 gap-2 text-center">
                        <div>
                          <p className="text-xs text-muted-foreground">Queries</p>
                          <p className="text-sm font-semibold">{agent.metrics.queries}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Accuracy</p>
                          <p className="text-sm font-semibold">{agent.metrics.accuracy}%</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Avg Time</p>
                          <p className="text-sm font-semibold">{agent.metrics.avgResponseTime}</p>
                        </div>
                      </div>
                      <div className="pt-3 border-t">
                        <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                          <span>Created by {agent.createdBy}</span>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Modified {agent.lastModified}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant={agent.status === "active" ? "outline" : "default"}
                          size="sm"
                          className="flex-1"
                          onClick={() => toggleCustomAgent(agent.id)}
                          data-testid={`button-toggle-${agent.id}`}
                        >
                          {agent.status === "active" ? "Pause" : "Activate"}
                        </Button>
                        <Button variant="outline" size="sm" className="flex-1">
                          Configure
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Sparkles className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">No Custom Agents Yet</h3>
                <p className="text-muted-foreground mb-4">
                  Create your first custom agent to automate specific workflows
                </p>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Your First Agent
                </Button>
              </CardContent>
            </Card>
          )}
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Agent Performance Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-4 gap-4">
              <div className="text-center">
                <p className="text-3xl font-bold text-primary">
                  {builtInAgents.length + customAgents.length}
                </p>
                <p className="text-sm text-muted-foreground mt-1">Total Agents</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-emerald-500">
                  {builtInAgents.filter(a => a.status === "active").length + 
                   customAgents.filter(a => a.status === "active").length}
                </p>
                <p className="text-sm text-muted-foreground mt-1">Active</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-blue-500">
                  {builtInAgents.reduce((sum, a) => sum + a.metrics.queries, 0) +
                   customAgents.reduce((sum, a) => sum + a.metrics.queries, 0)}
                </p>
                <p className="text-sm text-muted-foreground mt-1">Total Queries</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-purple-500">94%</p>
                <p className="text-sm text-muted-foreground mt-1">Avg Accuracy</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  );
}
