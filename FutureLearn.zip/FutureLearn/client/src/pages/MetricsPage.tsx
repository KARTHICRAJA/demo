import ValueMonitoring from "@/components/ValueMonitoring";
import MetricsCard from "@/components/MetricsCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, TrendingUp, Target, DollarSign } from "lucide-react";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

export default function MetricsPage() {
  const performanceData = [
    { month: 'Jan', mttr: 28, ttc: 8 },
    { month: 'Feb', mttr: 25, ttc: 7.2 },
    { month: 'Mar', mttr: 22, ttc: 6.5 },
    { month: 'Apr', mttr: 18, ttc: 5.8 },
    { month: 'May', mttr: 15, ttc: 4.2 },
    { month: 'Jun', mttr: 12.4, ttc: 3.2 },
  ];

  const usageData = [
    { month: 'Jan', queries: 420 },
    { month: 'Feb', queries: 680 },
    { month: 'Mar', queries: 920 },
    { month: 'Apr', queries: 1240 },
    { month: 'May', queries: 1580 },
    { month: 'Jun', queries: 2150 },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2" data-testid="text-page-title">Metrics & Value Monitoring</h1>
        <p className="text-muted-foreground">
          Track KPIs, ROI, productivity gains, and knowledge loss risk reduction
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricsCard
          title="Mean Time to Resolution"
          value="12.4m"
          subtitle="Average incident resolution"
          trend={{ value: 23, isPositive: true }}
          icon={Clock}
        />
        <MetricsCard
          title="Time to Competency"
          value="3.2 weeks"
          subtitle="New hire onboarding"
          trend={{ value: 45, isPositive: true }}
          icon={TrendingUp}
        />
        <MetricsCard
          title="Retrieval Accuracy"
          value="94.3%"
          subtitle="Knowledge matching score"
          trend={{ value: 8, isPositive: true }}
          icon={Target}
        />
        <MetricsCard
          title="Annual Savings"
          value="$1.2M"
          subtitle="Total cost reduction"
          trend={{ value: 156, isPositive: true }}
          icon={DollarSign}
        />
      </div>

      <ValueMonitoring />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Performance Trends</CardTitle>
            <p className="text-sm text-muted-foreground">
              MTTR and TTC improvement over time
            </p>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey="month" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="mttr"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  name="MTTR (min)"
                />
                <Line
                  type="monotone"
                  dataKey="ttc"
                  stroke="hsl(var(--chart-2))"
                  strokeWidth={2}
                  name="TTC (weeks)"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Agent Usage Growth</CardTitle>
            <p className="text-sm text-muted-foreground">
              Total queries processed by all agents
            </p>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={usageData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey="month" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip />
                <Area
                  type="monotone"
                  dataKey="queries"
                  stroke="hsl(var(--primary))"
                  fill="hsl(var(--primary) / 0.2)"
                  name="Total Queries"
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Agent Performance Comparison</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { name: 'Knowledge Navigator', accuracy: 94, queries: 1247, color: 'bg-primary' },
              { name: 'Operational Copilot', accuracy: 96, queries: 456, color: 'bg-chart-2' },
              { name: 'Adaptive Learning', accuracy: 91, queries: 834, color: 'bg-chart-3' },
            ].map((agent) => (
              <div key={agent.name} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full ${agent.color}`} />
                    <span className="font-medium">{agent.name}</span>
                  </div>
                  <div className="flex items-center gap-6 text-sm">
                    <Badge variant="outline">{agent.accuracy}% accuracy</Badge>
                    <Badge variant="outline">{agent.queries.toLocaleString()} queries</Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
