import { useState } from "react";
import ChatInterface from "@/components/ChatInterface";

export default function Chat() {
  type Message = {
    id: string;
    role: "user" | "assistant";
    content: string;
    timestamp: string;
    citations?: { title: string; source: string }[];
  };

  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Hello! I\'m your Endur HyperIQ assistant. I can help you with ETRM configurations, business rules, troubleshooting, and learning. What would you like to know?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const handleSendMessage = (content: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMessage]);

    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'I understand your question. Let me search through the Project Design Documents, Configuration Guides, and SOPs to provide you with accurate information...\n\nBased on the documentation, here\'s what I found:\n\n[This is a demo response. In the full application, this would be powered by the actual AI agents with access to your 11 knowledge sources.]',
        citations: [
          { title: 'Settlement Configuration Guide', source: 'SOPs' },
          { title: 'Key Design Document v2.3', source: 'Project Docs' },
        ],
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, aiResponse]);
    }, 1000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2" data-testid="text-page-title">AI Chat Assistant</h1>
        <p className="text-muted-foreground">
          Ask questions about Endur ETRM configurations, business processes, troubleshooting, or request guided learning
        </p>
      </div>
      <ChatInterface messages={messages} onSendMessage={handleSendMessage} />
    </div>
  );
}
