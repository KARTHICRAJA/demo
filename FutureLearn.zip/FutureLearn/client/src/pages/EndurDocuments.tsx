import { useState } from "react";
import PageLayout from "@/components/sections/PageLayout";
import KnowledgeGraphNavigator from "@/components/KnowledgeGraphNavigator";
import StructuredChatInterface from "@/components/StructuredChatInterface";
import DataIngestionArchitecture from "@/components/DataIngestionArchitecture";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Database, MessageSquare, Network, Lightbulb, Play } from "lucide-react";

type GraphNode = {
  id: string;
  label: string;
  type: "module" | "process" | "concept" | "api";
  children?: GraphNode[];
  metadata?: {
    role?: string[];
    phase?: string;
    dependencies?: string[];
  };
};

export default function EndurDocuments() {
  const [selectedContext, setSelectedContext] = useState<{
    selectedPath: string[];
    nodeLabel: string;
  } | undefined>(undefined);

  const [activeTab, setActiveTab] = useState("navigator");

  const handleNodeSelect = (path: string[], node: GraphNode) => {
    setSelectedContext({
      selectedPath: path,
      nodeLabel: node.label,
    });
  };

  const exampleQueries = [
    {
      title: "Settlement Workflow Comparison",
      query: "Explain how the settlement workflow differs for a physical gas trade versus a financial power swap, and visualize the document flow",
      icon: "⚡",
    },
    {
      title: "VaR Methodology Comparison",
      query: "Compare parametric VaR vs standard VaR",
      icon: "📊",
    },
    {
      title: "APM Architecture",
      query: "Explain the relationship between APM services and Connex",
      icon: "🔄",
    },
  ];

  const ragFeatures = [
    {
      title: "Parent-Child Chunking",
      description: "Maintains document hierarchy with backlinks from specific concepts to broader modules",
      example: "SimResult definition → Parametric VaR module",
    },
    {
      title: "Knowledge Graph Filter",
      description: "Pre-filter context by exploring trade lifecycle or module dependencies before querying",
      example: "Navigate: Deal Entry → Valuation → Settlement to focus retrieval",
    },
    {
      title: "Multi-Role Metadata",
      description: "Documents tagged by user role (Trader, Developer, Back Office, Risk Manager)",
      example: "Trader sees deal entry workflows, Developer sees API references",
    },
    {
      title: "Hybrid Retrieval",
      description: "Combines vector similarity search with knowledge graph traversal for precision",
      example: "Graph filters → Vector search → Re-rank by relevance",
    },
  ];

  return (
    <PageLayout
      title="Endur Knowledge Hub"
      description="RAG-powered knowledge management with visual navigation, structured analysis, and comprehensive Endur ETRM documentation"
    >
      <div className="space-y-6">
        <Card className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-primary/20">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle className="flex items-center gap-2 text-xl">
                  <Lightbulb className="w-6 h-6 text-primary" />
                  Intelligent RAG System for Endur Documentation
                </CardTitle>
                <p className="text-sm text-muted-foreground mt-2">
                  Navigate thousands of pages with visual knowledge graphs, get structured AI responses with comparative tables and live diagrams
                </p>
              </div>
              <Badge variant="default" className="text-xs">
                Production Ready
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {ragFeatures.map((feature) => (
                <div key={feature.title} className="bg-background/60 backdrop-blur rounded-lg p-3 border">
                  <h4 className="font-semibold text-sm mb-1">{feature.title}</h4>
                  <p className="text-xs text-muted-foreground mb-2">{feature.description}</p>
                  <p className="text-xs italic text-primary">{feature.example}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="navigator" data-testid="tab-navigator">
              <Network className="w-4 h-4 mr-2" />
              Visual Navigator
            </TabsTrigger>
            <TabsTrigger value="chat" data-testid="tab-chat">
              <MessageSquare className="w-4 h-4 mr-2" />
              Structured Chat
            </TabsTrigger>
            <TabsTrigger value="ingestion" data-testid="tab-ingestion">
              <Database className="w-4 h-4 mr-2" />
              Data Pipeline
            </TabsTrigger>
            <TabsTrigger value="examples" data-testid="tab-examples">
              <Play className="w-4 h-4 mr-2" />
              Examples
            </TabsTrigger>
          </TabsList>

          <TabsContent value="navigator" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <KnowledgeGraphNavigator onNodeSelect={handleNodeSelect} />
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Context Information</CardTitle>
                  {selectedContext && (
                    <Badge variant="outline" className="w-fit">
                      Selected: {selectedContext.nodeLabel}
                    </Badge>
                  )}
                </CardHeader>
                <CardContent>
                  {selectedContext ? (
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-semibold text-sm mb-2">Selection Path</h4>
                        <div className="flex items-center gap-2 flex-wrap">
                          {selectedContext.selectedPath.map((node, idx) => (
                            <div key={idx} className="flex items-center gap-2">
                              <Badge variant="secondary" className="text-xs">
                                {node}
                              </Badge>
                              {idx < selectedContext.selectedPath.length - 1 && (
                                <span className="text-muted-foreground">→</span>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold text-sm mb-2">How This Filters Your Queries</h4>
                        <p className="text-sm text-muted-foreground">
                          When you ask questions in the chat, the system will prioritize documents and concepts
                          related to <strong>{selectedContext.nodeLabel}</strong> and its dependencies in the knowledge graph.
                          This dramatically improves retrieval precision by pre-filtering the context before vector search.
                        </p>
                      </div>

                      <Button
                        onClick={() => setActiveTab("chat")}
                        className="w-full"
                        data-testid="button-goto-chat"
                      >
                        <MessageSquare className="w-4 h-4 mr-2" />
                        Ask Questions with This Context
                      </Button>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <Network className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p className="text-sm">
                        Click on any node in the Knowledge Graph to select it as context
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="chat" className="mt-6">
            <div className="grid grid-cols-1 gap-6">
              <StructuredChatInterface context={selectedContext} />
            </div>
          </TabsContent>

          <TabsContent value="ingestion" className="mt-6">
            <DataIngestionArchitecture />
          </TabsContent>

          <TabsContent value="examples" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Play className="w-5 h-5" />
                  Example User Flow: Settlement Workflow Comparison
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Demonstrating physical gas trade vs financial power swap with document flow visualization
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <Badge variant="default" className="text-xs">User Query</Badge>
                  </h3>
                  <p className="text-sm italic">
                    "Explain how the settlement workflow differs for a physical gas trade versus a financial power swap, and visualize the document flow."
                  </p>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold flex items-center gap-2">
                    <Badge variant="default" className="text-xs">System Response</Badge>
                  </h3>

                  <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-4">
                    <h4 className="font-semibold text-sm mb-2">1. Concept Summary</h4>
                    <p className="text-sm leading-relaxed">
                      Physical gas trades and financial power swaps follow different settlement workflows in Endur. Physical gas requires delivery scheduling, nomination management, and volume reconciliation, while financial power swaps settle based on index prices without physical delivery. Both integrate with the invoicing module but follow distinct document flows.
                    </p>
                  </div>

                  <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-4">
                    <h4 className="font-semibold text-sm mb-2">2. Comparative Table</h4>
                    <div className="overflow-x-auto mt-3">
                      <table className="w-full border-collapse text-sm">
                        <thead>
                          <tr className="border-b-2 border-primary/20">
                            <th className="text-left p-2 font-semibold bg-muted/50">Aspect</th>
                            <th className="text-left p-2 font-semibold bg-muted/50">Physical Gas Trade</th>
                            <th className="text-left p-2 font-semibold bg-muted/50">Financial Power Swap</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="border-b border-border">
                            <td className="p-2 font-medium">Delivery Type</td>
                            <td className="p-2">Physical delivery required</td>
                            <td className="p-2">Cash settlement only</td>
                          </tr>
                          <tr className="border-b border-border">
                            <td className="p-2 font-medium">Nomination</td>
                            <td className="p-2">Required (pipeline nomination)</td>
                            <td className="p-2">Not applicable</td>
                          </tr>
                          <tr className="border-b border-border">
                            <td className="p-2 font-medium">Volume Reconciliation</td>
                            <td className="p-2">Daily meter readings</td>
                            <td className="p-2">Index-based calculation</td>
                          </tr>
                          <tr className="border-b border-border">
                            <td className="p-2 font-medium">Invoice Generation</td>
                            <td className="p-2">Actual delivered volumes</td>
                            <td className="p-2">Notional × (Market Price - Strike)</td>
                          </tr>
                          <tr className="border-b border-border">
                            <td className="p-2 font-medium">Settlement Timing</td>
                            <td className="p-2">Monthly based on actuals</td>
                            <td className="p-2">Daily mark-to-market</td>
                          </tr>
                          <tr className="border-b border-border">
                            <td className="p-2 font-medium">Document Flow</td>
                            <td className="p-2">Nomination → Confirmation → Invoice → Payment</td>
                            <td className="p-2">Deal Confirmation → MTM Report → Cash Settlement</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-4">
                    <h4 className="font-semibold text-sm mb-3">3. Document Flow Visualization (Mermaid.js Sequence Diagram)</h4>
                    <div className="bg-white p-4 rounded border">
                      <pre className="text-xs font-mono whitespace-pre-wrap">
{`sequenceDiagram
    participant Trader
    participant EndurDealEntry
    participant Scheduling
    participant Invoicing
    participant Settlement
    
    Note over Trader,Settlement: Physical Gas Trade Flow
    Trader->>EndurDealEntry: Enter Physical Gas Deal
    EndurDealEntry->>Scheduling: Create Nomination
    Scheduling->>Scheduling: Pipeline Coordination
    Scheduling->>Invoicing: Send Actual Volumes
    Invoicing->>Settlement: Generate Invoice
    Settlement->>Settlement: Process Payment
    
    Note over Trader,Settlement: Financial Power Swap Flow
    Trader->>EndurDealEntry: Enter Financial Swap
    EndurDealEntry->>Invoicing: Daily MTM Calculation
    Invoicing->>Settlement: Net Cash Settlement
    Settlement->>Settlement: Process Payment`}
                      </pre>
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      This Mermaid code renders as an interactive sequence diagram in the chat interface, showing the parallel workflows side-by-side.
                    </p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={() => setActiveTab("chat")}
                    className="flex-1"
                    data-testid="button-try-in-chat"
                  >
                    <MessageSquare className="w-4 h-4 mr-2" />
                    Try This Query in Chat
                  </Button>
                  <Button
                    onClick={() => setActiveTab("navigator")}
                    variant="outline"
                    className="flex-1"
                    data-testid="button-explore-graph"
                  >
                    <Network className="w-4 h-4 mr-2" />
                    Explore in Knowledge Graph
                  </Button>
                </div>

                {exampleQueries.map((example) => (
                  <Card key={example.title} className="hover-elevate cursor-pointer" onClick={() => setActiveTab("chat")}>
                    <CardHeader>
                      <div className="flex items-start gap-3">
                        <div className="text-3xl">{example.icon}</div>
                        <div className="flex-1">
                          <CardTitle className="text-base mb-2">{example.title}</CardTitle>
                          <p className="text-sm text-muted-foreground italic">
                            "{example.query}"
                          </p>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Badge variant="outline" className="text-xs">Concept Summary</Badge>
                        <Badge variant="outline" className="text-xs">Comparative Table</Badge>
                        <Badge variant="outline" className="text-xs">Mermaid Diagram</Badge>
                      </div>
                      <Button
                        className="w-full mt-3"
                        variant="outline"
                        size="sm"
                        data-testid={`button-example-${example.title.toLowerCase().replace(/\s/g, '-')}`}
                      >
                        Try This Query
                      </Button>
                    </CardContent>
                  </Card>
                ))}

                <Card className="bg-muted/50">
                  <CardHeader>
                    <CardTitle className="text-base">System Prompt Strategy</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-sm">
                      <div>
                        <h4 className="font-semibold mb-1">1. Concept Summary (Executive Level)</h4>
                        <p className="text-muted-foreground">
                          "Provide a high-level executive summary of the concept in 2-3 sentences, focusing on business value and key distinctions."
                        </p>
                      </div>
                      <div>
                        <h4 className="font-semibold mb-1">2. Comparative Table (Analyst Grade)</h4>
                        <p className="text-muted-foreground">
                          "When comparing features, ALWAYS generate a Markdown table with columns: Aspect, [Option A], [Option B]. Include rows for: Method, Use Case, Dependencies, Strengths, Limitations."
                        </p>
                      </div>
                      <div>
                        <h4 className="font-semibold mb-1">3. Visual Aid (Interactive Diagram)</h4>
                        <p className="text-muted-foreground">
                          "Generate Mermaid.js code for sequence diagrams (workflows), flowcharts (processes), or graph diagrams (relationships). Use clear labels and color coding."
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PageLayout>
  );
}
