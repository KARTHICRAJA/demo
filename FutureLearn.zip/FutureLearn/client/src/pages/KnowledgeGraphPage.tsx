import KnowledgeGraph from "@/components/KnowledgeGraph";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Database, FileText, Settings } from "lucide-react";

export default function KnowledgeGraphPage() {
  const stats = [
    { label: "Documents", count: 247, icon: FileText, color: "text-primary" },
    { label: "Configurations", count: 89, icon: Settings, color: "text-emerald-500" },
    { label: "Business Rules", count: 156, icon: Database, color: "text-amber-500" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2" data-testid="text-page-title">Knowledge Graph</h1>
        <p className="text-muted-foreground">
          Interactive visualization of relationships between design documents, configurations, and business rules
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {stats.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="text-3xl font-bold mt-1" data-testid={`text-${stat.label.toLowerCase()}-count`}>
                    {stat.count}
                  </p>
                </div>
                <div className={`w-12 h-12 rounded-md bg-card border flex items-center justify-center ${stat.color}`}>
                  <stat.icon className="w-6 h-6" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <KnowledgeGraph />

      <Card>
        <CardContent className="p-6">
          <h3 className="font-semibold mb-4">Recent Insights</h3>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 rounded-md border hover-elevate">
              <Badge variant="outline" className="mt-0.5">High Impact</Badge>
              <div className="flex-1">
                <p className="text-sm font-medium">Settlement Rule Dependencies</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Identified 12 deal templates dependent on deprecated settlement configuration
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 rounded-md border hover-elevate">
              <Badge variant="outline" className="mt-0.5">New Connection</Badge>
              <div className="flex-1">
                <p className="text-sm font-medium">Credit Risk Integration</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Discovered undocumented link between credit limit checks and margin calculations
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
