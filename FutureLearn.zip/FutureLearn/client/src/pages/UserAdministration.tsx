import { useState } from "react";
import PageLayout from "@/components/sections/PageLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { UserPlus, Shield, Users, Settings, Search } from "lucide-react";

export default function UserAdministration() {
  const [searchQuery, setSearchQuery] = useState("");

  const users = [
    {
      id: "1",
      name: "John Smith",
      email: "john.smith@company.com",
      role: "Admin",
      status: "active",
      lastLogin: "2 hours ago",
      initials: "JS",
    },
    {
      id: "2",
      name: "Sarah Johnson",
      email: "sarah.johnson@company.com",
      role: "Power User",
      status: "active",
      lastLogin: "1 day ago",
      initials: "SJ",
    },
    {
      id: "3",
      name: "Michael Chen",
      email: "michael.chen@company.com",
      role: "Analyst",
      status: "active",
      lastLogin: "3 hours ago",
      initials: "MC",
    },
    {
      id: "4",
      name: "Emily Davis",
      email: "emily.davis@company.com",
      role: "Trader",
      status: "inactive",
      lastLogin: "2 weeks ago",
      initials: "ED",
    },
  ];

  const roles = [
    {
      id: "admin",
      name: "Admin",
      description: "Full system access with user management",
      users: 3,
      permissions: ["All permissions", "User management", "System configuration"],
      color: "text-red-500",
    },
    {
      id: "power-user",
      name: "Power User",
      description: "Advanced features and agent configuration",
      users: 8,
      permissions: ["Agent builder", "Knowledge graph", "Custom queries"],
      color: "text-purple-500",
    },
    {
      id: "analyst",
      name: "Analyst",
      description: "Business analysis and reporting",
      users: 15,
      permissions: ["Documentation access", "Process views", "Reporting"],
      color: "text-blue-500",
    },
    {
      id: "trader",
      name: "Trader",
      description: "Trading operations and monitoring",
      users: 24,
      permissions: ["ETRM process", "Ops monitoring", "Read-only access"],
      color: "text-emerald-500",
    },
  ];

  const getRoleBadgeVariant = (role: string) => {
    if (role === "Admin") return "destructive";
    if (role === "Power User") return "default";
    return "secondary";
  };

  return (
    <PageLayout
      title="User Administration"
      description="Manage users, roles, and permissions across the Endur HyperIQ platform"
    >
      <Tabs defaultValue="users">
        <TabsList>
          <TabsTrigger value="users">
            <Users className="w-4 h-4 mr-2" />
            Users
          </TabsTrigger>
          <TabsTrigger value="roles">
            <Shield className="w-4 h-4 mr-2" />
            Roles & Permissions
          </TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="space-y-6 mt-6">
          <div className="flex items-center justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search users..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search-users"
              />
            </div>
            <Button data-testid="button-add-user">
              <UserPlus className="w-4 h-4 mr-2" />
              Add User
            </Button>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {users.map((user) => (
              <Card key={user.id} className="hover-elevate">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <Avatar className="w-12 h-12">
                        <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                          {user.initials}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold" data-testid={`text-user-name-${user.id}`}>
                          {user.name}
                        </h3>
                        <p className="text-sm text-muted-foreground">{user.email}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Last login: {user.lastLogin}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge variant={getRoleBadgeVariant(user.role)}>{user.role}</Badge>
                      <Badge
                        variant={user.status === "active" ? "secondary" : "outline"}
                        className={user.status === "active" ? "bg-emerald-500/10 text-emerald-500 border-0" : ""}
                      >
                        {user.status}
                      </Badge>
                      <Button variant="ghost" size="icon">
                        <Settings className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">User Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-4 gap-4">
                <div className="text-center">
                  <p className="text-3xl font-bold text-primary">50</p>
                  <p className="text-sm text-muted-foreground mt-1">Total Users</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-emerald-500">42</p>
                  <p className="text-sm text-muted-foreground mt-1">Active</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-amber-500">8</p>
                  <p className="text-sm text-muted-foreground mt-1">Inactive</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-blue-500">15</p>
                  <p className="text-sm text-muted-foreground mt-1">This Week</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="roles" className="space-y-6 mt-6">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              Configure role-based access control and permissions
            </p>
            <Button variant="outline" data-testid="button-create-role">
              Create Role
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {roles.map((role) => (
              <Card key={role.id} className="hover-elevate">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Shield className={`w-5 h-5 ${role.color}`} />
                      {role.name}
                    </CardTitle>
                    <Badge variant="outline">{role.users} users</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">{role.description}</p>
                  <div>
                    <p className="text-sm font-medium mb-2">Permissions:</p>
                    <div className="flex flex-wrap gap-2">
                      {role.permissions.map((permission, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {permission}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="w-full">
                    <Settings className="w-4 h-4 mr-2" />
                    Configure
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </PageLayout>
  );
}
