import { useState } from "react";
import PageLayout from "@/components/sections/PageLayout";
import QueryConsole from "@/components/sections/QueryConsole";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { AlertTriangle, GitBranch, Database, FileCode } from "lucide-react";

export default function OpsEngineer() {
  const [changeRequest, setChangeRequest] = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [impactResults, setImpactResults] = useState<any>(null);

  const handleAnalyze = () => {
    setAnalyzing(true);
    setTimeout(() => {
      setImpactResults({
        impactLevel: "Medium",
        affectedComponents: 8,
        affectedUsers: 45,
        estimatedDowntime: "15 minutes",
        dependencies: [
          { name: "Settlement Engine", risk: "medium" },
          { name: "Risk Calculation Service", risk: "low" },
          { name: "Reporting Database", risk: "high" },
        ],
        recommendations: [
          "Schedule during off-peak hours (2-4 AM)",
          "Notify all power trading desk users",
          "Prepare rollback scripts for database changes",
        ],
      });
      setAnalyzing(false);
    }, 2000);
  };

  const recentChanges = [
    {
      id: "CR-1247",
      title: "Update deal template validation rules",
      impact: "Low",
      status: "Approved",
      date: "2 days ago",
    },
    {
      id: "CR-1246",
      title: "Modify settlement calculation logic",
      impact: "High",
      status: "In Review",
      date: "1 week ago",
    },
  ];

  const querySuggestions = [
    "What systems depend on the settlement engine?",
    "Show me recent changes to pricing module",
    "Which users will be affected by database migration?",
  ];

  return (
    <PageLayout
      title="Ops Engineer - Impact Analysis"
      description="Analyze change requests and assess impact on system components, users, and operations"
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GitBranch className="w-5 h-5 text-primary" />
                Change Request Analysis
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="change-id">Change Request ID</Label>
                <Input
                  id="change-id"
                  placeholder="e.g., CR-1248"
                  data-testid="input-change-id"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="change-desc">Description</Label>
                <Textarea
                  id="change-desc"
                  placeholder="Describe the proposed change..."
                  value={changeRequest}
                  onChange={(e) => setChangeRequest(e.target.value)}
                  className="min-h-[100px]"
                  data-testid="input-change-description"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Target Component</Label>
                  <Input placeholder="e.g., Settlement Engine" />
                </div>
                <div className="space-y-2">
                  <Label>Planned Date</Label>
                  <Input type="date" />
                </div>
              </div>

              <Button
                className="w-full"
                onClick={handleAnalyze}
                disabled={!changeRequest.trim() || analyzing}
                data-testid="button-analyze-impact"
              >
                {analyzing ? "Analyzing..." : "Analyze Impact"}
              </Button>
            </CardContent>
          </Card>

          {impactResults && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-amber-500" />
                  Impact Analysis Results
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-4 gap-4">
                  <div className="p-4 rounded-md border bg-card">
                    <p className="text-xs text-muted-foreground mb-1">Impact Level</p>
                    <Badge variant={impactResults.impactLevel === 'High' ? 'destructive' : 'secondary'}>
                      {impactResults.impactLevel}
                    </Badge>
                  </div>
                  <div className="p-4 rounded-md border bg-card">
                    <p className="text-xs text-muted-foreground mb-1">Components</p>
                    <p className="text-2xl font-bold">{impactResults.affectedComponents}</p>
                  </div>
                  <div className="p-4 rounded-md border bg-card">
                    <p className="text-xs text-muted-foreground mb-1">Affected Users</p>
                    <p className="text-2xl font-bold">{impactResults.affectedUsers}</p>
                  </div>
                  <div className="p-4 rounded-md border bg-card">
                    <p className="text-xs text-muted-foreground mb-1">Downtime</p>
                    <p className="text-lg font-bold">{impactResults.estimatedDowntime}</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <Database className="w-4 h-4" />
                    Dependency Analysis
                  </h4>
                  <div className="space-y-2">
                    {impactResults.dependencies.map((dep: any, idx: number) => (
                      <div key={idx} className="flex items-center justify-between p-3 rounded-md border">
                        <span className="text-sm">{dep.name}</span>
                        <Badge
                          variant={dep.risk === 'high' ? 'destructive' : dep.risk === 'medium' ? 'secondary' : 'outline'}
                          className="text-xs"
                        >
                          {dep.risk} risk
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <FileCode className="w-4 h-4" />
                    Recommendations
                  </h4>
                  <ul className="space-y-2">
                    {impactResults.recommendations.map((rec: string, idx: number) => (
                      <li key={idx} className="flex items-start gap-2 text-sm">
                        <span className="text-primary mt-1">•</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Recent Change Requests</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {recentChanges.map((change) => (
                <div key={change.id} className="p-4 rounded-md border hover-elevate cursor-pointer">
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="outline" className="font-mono text-xs">{change.id}</Badge>
                    <div className="flex items-center gap-2">
                      <Badge variant={change.impact === 'High' ? 'destructive' : 'secondary'} className="text-xs">
                        {change.impact}
                      </Badge>
                      <Badge variant="outline" className="text-xs">{change.status}</Badge>
                    </div>
                  </div>
                  <p className="text-sm font-medium mb-1">{change.title}</p>
                  <p className="text-xs text-muted-foreground">{change.date}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <QueryConsole
            title="Dependency Analysis"
            placeholder="Query about system dependencies, integrations, or user impact..."
            suggestions={querySuggestions}
            onQuery={(q) => console.log('Query:', q)}
          />

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Analysis Metrics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Changes This Month</span>
                <span className="font-semibold">24</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Avg Impact Score</span>
                <span className="font-semibold">3.2/5</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Success Rate</span>
                <Badge variant="secondary" className="bg-emerald-500/10 text-emerald-500 border-0">
                  96%
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageLayout>
  );
}
