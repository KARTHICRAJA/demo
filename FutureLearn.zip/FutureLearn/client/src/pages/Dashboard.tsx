import { useState } from "react";
import AgentCard from "@/components/AgentCard";
import MetricsCard from "@/components/MetricsCard";
import ActivityFeed from "@/components/ActivityFeed";
import { useActivityFeed } from "@/hooks/useActivityFeed";
import { Clock, TrendingUp, Target, DollarSign } from "lucide-react";
import knowledgeIcon from '@assets/generated_images/Knowledge_Navigator_agent_icon_fb59e30c.png'
import learningIcon from '@assets/generated_images/Adaptive_Learning_agent_icon_6fc8d570.png'
import copilotIcon from '@assets/generated_images/Operational_Copilot_agent_icon_255146df.png'
import heroImage from '@assets/generated_images/Hero_AI_network_visualization_c6f4a3fd.png'

export default function Dashboard() {
  type AgentStatus = "active" | "idle" | "processing" | "paused";
  
  const [agents, setAgents] = useState<Array<{
    id: string;
    name: string;
    description: string;
    status: AgentStatus;
    icon: string;
    metrics: { queries: number; accuracy: number; avgResponseTime: string };
  }>>([
    {
      id: 'knowledge-nav',
      name: "Knowledge Navigator",
      description: "Hybrid RAG with semantic search and graph traversal",
      status: "active",
      icon: knowledgeIcon,
      metrics: { queries: 1247, accuracy: 94, avgResponseTime: "1.2s" },
    },
    {
      id: 'adaptive-learning',
      name: "Adaptive Learning Companion",
      description: "Personalized learning paths with skill gap assessment",
      status: "active",
      icon: learningIcon,
      metrics: { queries: 834, accuracy: 91, avgResponseTime: "0.8s" },
    },
    {
      id: 'operational-copilot',
      name: "Operational Copilot",
      description: "Real-time troubleshooting and root cause analysis",
      status: "idle",
      icon: copilotIcon,
      metrics: { queries: 456, accuracy: 96, avgResponseTime: "1.5s" },
    },
  ]);

  const activities = useActivityFeed(20);

  const toggleAgent = (id: string) => {
    setAgents(prev => prev.map(agent => {
      if (agent.id === id) {
        const isActive = agent.status === "active" || agent.status === "processing";
        return { ...agent, status: (isActive ? "paused" : "active") as AgentStatus };
      }
      return agent;
    }));
  };

  return (
    <div className="space-y-6">
      <div className="relative h-[300px] rounded-lg overflow-hidden">
        <img src={heroImage} alt="AI Network" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/80 to-transparent flex items-center">
          <div className="px-8 space-y-4 max-w-2xl">
            <h1 className="text-4xl font-bold" data-testid="text-hero-title">
              Endur HyperIQ
            </h1>
            <p className="text-lg text-muted-foreground">
              Transform institutional knowledge into actionable intelligence with AI-powered agents
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricsCard
          title="Mean Time to Resolution"
          value="12.4m"
          subtitle="Average incident resolution"
          trend={{ value: 23, isPositive: true }}
          icon={Clock}
        />
        <MetricsCard
          title="Time to Competency"
          value="3.2 weeks"
          subtitle="New hire onboarding"
          trend={{ value: 45, isPositive: true }}
          icon={TrendingUp}
        />
        <MetricsCard
          title="Retrieval Accuracy"
          value="94.3%"
          subtitle="Knowledge matching score"
          trend={{ value: 8, isPositive: true }}
          icon={Target}
        />
        <MetricsCard
          title="Annual Savings"
          value="$1.2M"
          subtitle="Total cost reduction"
          trend={{ value: 156, isPositive: true }}
          icon={DollarSign}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div>
            <h2 className="text-2xl font-semibold mb-4">Active AI Agents</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {agents.map((agent) => (
                <AgentCard
                  key={agent.id}
                  {...agent}
                  onToggle={() => toggleAgent(agent.id)}
                  onConfigure={() => console.log('Configure', agent.id)}
                />
              ))}
            </div>
          </div>
        </div>

        <div>
          <ActivityFeed activities={activities} />
        </div>
      </div>
    </div>
  );
}
