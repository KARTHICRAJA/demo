import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";
import { 
  LayoutDashboard, 
  MessageSquare, 
  Network, 
  Wrench, 
  BarChart3, 
  Sparkles,
  FileText,
  GitBranch,
  Activity,
  Briefcase,
  Award,
  Settings,
  Users,
  BookOpen,
  UsersRound,
  Settings2
} from "lucide-react";
import { Link, useLocation } from "wouter";

const mainMenuItems = [
  {
    title: "Welcome",
    url: "/",
    icon: LayoutDashboard,
    iconColor: "text-blue-500",
  },
  {
    title: "Incident Analysis",
    url: "/monitoring",
    icon: Activity,
    iconColor: "text-emerald-500",
  },
  {
    title: "AI Insights",
    url: "/insights",
    icon: Sparkles,
    iconColor: "text-amber-500",
  },
];

const knowledgeHubItems = [
  {
    title: "Endur Knowledge Hub",
    url: "/documents",
    icon: FileText,
    iconColor: "text-cyan-500",
  },
  {
    title: "Hyperion Knowledge Hub",
    url: "/process",
    icon: GitBranch,
    iconColor: "text-indigo-500",
  },
  {
    title: "Dependency Graph",
    url: "/knowledge-graph",
    icon: Network,
    iconColor: "text-teal-500",
  },
  {
    title: "Metrics & Value",
    url: "/metrics",
    icon: BarChart3,
    iconColor: "text-purple-500",
  },
  {
    title: "AI Chat",
    url: "/chat",
    icon: MessageSquare,
    iconColor: "text-rose-500",
  },
];

const teamItems = [
  {
    title: "Requirement Analysis",
    url: "/business-analyst",
    icon: Briefcase,
    iconColor: "text-violet-500",
  },
  {
    title: "Architecture",
    url: "/architect",
    icon: Award,
    iconColor: "text-pink-500",
  },
  {
    title: "Prod CR Analysis",
    url: "/ops-engineer",
    icon: Settings,
    iconColor: "text-orange-500",
  },
  {
    title: "AI Agents",
    url: "/agents",
    icon: Sparkles,
    iconColor: "text-sky-500",
  },
];

const settingsItems = [
  {
    title: "Agent Builder",
    url: "/builder",
    icon: Wrench,
    iconColor: "text-lime-500",
  },
  {
    title: "User Administration",
    url: "/users",
    icon: Users,
    iconColor: "text-fuchsia-500",
  },
];

export function AppSidebar() {
  const [location] = useLocation();

  const renderMenuItems = (items: typeof mainMenuItems) => {
    return items.map((item) => {
      const isActive = location === item.url;
      return (
        <SidebarMenuItem key={item.title}>
          <SidebarMenuButton 
            asChild 
            isActive={isActive}
            className={isActive ? "bg-[#0047AB] text-white hover:bg-[#0047AB] hover:text-white data-[active=true]:bg-[#0047AB] data-[active=true]:text-white" : ""}
          >
            <Link href={item.url} data-testid={`link-${item.title.toLowerCase().replace(/\s/g, '-')}`}>
              <item.icon className={`w-4 h-4 ${isActive ? '' : item.iconColor}`} />
              <span>{item.title}</span>
            </Link>
          </SidebarMenuButton>
        </SidebarMenuItem>
      );
    });
  };

  return (
    <Sidebar>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="flex items-center gap-2 px-4 py-3">
            <Sparkles className="w-5 h-5 text-primary" />
            <span className="text-base font-semibold">Endur HyperIQ</span>
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {renderMenuItems(mainMenuItems)}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="px-4 py-2 text-sm font-semibold">
            Knowledge Hub
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {renderMenuItems(knowledgeHubItems)}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="px-4 py-2 text-sm font-semibold">
            Skills
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {renderMenuItems(teamItems)}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="px-4 py-2 text-sm font-semibold">
            Settings
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {renderMenuItems(settingsItems)}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
