import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Activity, Pause, Play, Settings } from "lucide-react";

interface AgentCardProps {
  name: string;
  description: string;
  status: "active" | "idle" | "processing" | "paused";
  icon: string;
  metrics: {
    queries: number;
    accuracy: number;
    avgResponseTime: string;
  };
  onToggle?: () => void;
  onConfigure?: () => void;
}

const statusConfig = {
  active: { label: "Active", className: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20" },
  idle: { label: "Idle", className: "bg-slate-500/10 text-slate-500 border-slate-500/20" },
  processing: { label: "Processing", className: "bg-primary/10 text-primary border-primary/20" },
  paused: { label: "Paused", className: "bg-amber-500/10 text-amber-500 border-amber-500/20" },
};

export default function AgentCard({ 
  name, 
  description, 
  status, 
  icon, 
  metrics,
  onToggle,
  onConfigure 
}: AgentCardProps) {
  const statusInfo = statusConfig[status];
  const isActive = status === "active" || status === "processing";

  return (
    <Card className="hover-elevate" data-testid={`card-agent-${name.toLowerCase().replace(/\s/g, '-')}`}>
      <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0 pb-4">
        <div className="flex items-center gap-4 flex-1 min-w-0">
          <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
            <img src={icon} alt={name} className="w-8 h-8" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-lg" data-testid={`text-agent-name-${name.toLowerCase().replace(/\s/g, '-')}`}>{name}</h3>
            <p className="text-sm text-muted-foreground truncate">{description}</p>
          </div>
        </div>
        <Badge 
          className={`${statusInfo.className} flex items-center gap-1.5 px-2.5 py-0.5`}
          data-testid={`badge-status-${status}`}
        >
          {status === "active" && <Activity className="w-3 h-3 animate-pulse" />}
          {statusInfo.label}
        </Badge>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-3 gap-4">
          <div>
            <p className="text-xs text-muted-foreground">Queries</p>
            <p className="text-2xl font-bold" data-testid="text-queries">{metrics.queries.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Accuracy</p>
            <p className="text-2xl font-bold" data-testid="text-accuracy">{metrics.accuracy}%</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Avg Time</p>
            <p className="text-2xl font-bold" data-testid="text-response-time">{metrics.avgResponseTime}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant={isActive ? "secondary" : "default"}
            onClick={onToggle}
            data-testid={`button-toggle-${isActive ? 'pause' : 'start'}`}
            className="flex-1"
          >
            {isActive ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
            {isActive ? "Pause" : "Start"}
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={onConfigure}
            data-testid="button-configure"
          >
            <Settings className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
