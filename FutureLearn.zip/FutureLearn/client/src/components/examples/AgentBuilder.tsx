import AgentBuilder from '../AgentBuilder'

export default function AgentBuilderExample() {
  return (
    <div className="p-8">
      <AgentBuilder />
    </div>
  )
}
