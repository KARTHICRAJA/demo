import AgentCard from '../AgentCard'
import knowledgeIcon from '@assets/generated_images/Knowledge_Navigator_agent_icon_fb59e30c.png'

export default function AgentCardExample() {
  return (
    <div className="p-8 max-w-md">
      <AgentCard 
        name="Knowledge Navigator"
        description="Hybrid RAG with semantic search and graph traversal"
        status="active"
        icon={knowledgeIcon}
        metrics={{
          queries: 1247,
          accuracy: 94,
          avgResponseTime: "1.2s"
        }}
        onToggle={() => console.log('Toggle agent')}
        onConfigure={() => console.log('Configure agent')}
      />
    </div>
  )
}
