import MetricsCard from '../MetricsCard'
import { Clock } from 'lucide-react'

export default function MetricsCardExample() {
  return (
    <div className="p-8 max-w-xs">
      <MetricsCard 
        title="Mean Time to Resolution"
        value="12.4m"
        subtitle="Average incident resolution"
        trend={{ value: 23, isPositive: true }}
        icon={Clock}
      />
    </div>
  )
}
