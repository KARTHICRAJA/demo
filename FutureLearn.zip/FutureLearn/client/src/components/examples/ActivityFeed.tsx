import ActivityFeed from '../ActivityFeed'

export default function ActivityFeedExample() {
  const mockActivities = [
    { id: '1', agentName: 'Knowledge Navigator', action: 'Retrieved 3 design documents for query about settlement rules', timestamp: '2m ago', type: 'success' as const },
    { id: '2', agentName: 'Adaptive Learning', action: 'Assessed skill gap in credit risk configuration', timestamp: '5m ago', type: 'info' as const },
    { id: '3', agentName: 'Operational Copilot', action: 'Warning: Proposed configuration conflicts with existing deal template', timestamp: '8m ago', type: 'warning' as const },
    { id: '4', agentName: 'Knowledge Navigator', action: 'Successfully mapped knowledge graph relationships', timestamp: '12m ago', type: 'success' as const },
    { id: '5', agentName: 'Custom Agent', action: 'Failed validation check on data source integration', timestamp: '15m ago', type: 'error' as const },
  ];

  return (
    <div className="p-8 max-w-md">
      <ActivityFeed activities={mockActivities} />
    </div>
  )
}
