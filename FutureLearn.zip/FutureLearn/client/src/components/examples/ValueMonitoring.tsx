import ValueMonitoring from '../ValueMonitoring'

export default function ValueMonitoringExample() {
  return (
    <div className="p-8">
      <ValueMonitoring />
    </div>
  )
}
