import ChatInterface from '../ChatInterface'

export default function ChatInterfaceExample() {
  const mockMessages = [
    {
      id: '1',
      role: 'user' as const,
      content: 'How do I configure commodity derivative settlement for power trading?',
      timestamp: '10:30 AM',
    },
    {
      id: '2',
      role: 'assistant' as const,
      content: 'To configure commodity derivative settlement for power trading in Endur, you need to follow these key steps:\n\n1. Set up the settlement type in the Trade Entry screens\n2. Configure the settlement rules based on your power trading contract terms\n3. Link the settlement profile to your deal template\n4. Verify the accounting integration parameters\n\nThe settlement configuration requires understanding of both the market curves and the specific deal rules documented in your Project Design Documents.',
      citations: [
        { title: 'Settlement Configuration Guide', source: 'SOPs' },
        { title: 'Power Trading Workflows', source: 'Process Flows' },
      ],
      timestamp: '10:31 AM',
    },
  ];

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <ChatInterface 
        messages={mockMessages} 
        onSendMessage={(msg) => console.log('Send message:', msg)}
      />
    </div>
  )
}
