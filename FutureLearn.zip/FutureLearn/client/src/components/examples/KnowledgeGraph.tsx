import KnowledgeGraph from '../KnowledgeGraph'

export default function KnowledgeGraphExample() {
  return (
    <div className="p-8">
      <KnowledgeGraph />
    </div>
  )
}
