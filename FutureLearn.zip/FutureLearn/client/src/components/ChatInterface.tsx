import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Bot, User, ExternalLink } from "lucide-react";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  citations?: { title: string; source: string }[];
  timestamp: string;
}

interface ChatInterfaceProps {
  messages: Message[];
  onSendMessage?: (message: string) => void;
}

export default function ChatInterface({ messages, onSendMessage }: ChatInterfaceProps) {
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (input.trim() && onSendMessage) {
      onSendMessage(input);
      setInput("");
    }
  };

  return (
    <Card className="flex flex-col h-[600px]" data-testid="card-chat-interface">
      <CardContent className="flex-1 flex flex-col p-0">
        <ScrollArea className="flex-1 p-6">
          <div className="space-y-6">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-4 ${
                  message.role === "user" ? "justify-end" : "justify-start"
                }`}
                data-testid={`message-${message.role}`}
              >
                {message.role === "assistant" && (
                  <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Bot className="w-4 h-4 text-primary" />
                  </div>
                )}
                <div
                  className={`max-w-[85%] space-y-2 ${
                    message.role === "user" ? "max-w-[80%]" : ""
                  }`}
                >
                  <Card className={message.role === "user" ? "bg-primary text-primary-foreground" : ""}>
                    <CardContent className="p-4">
                      <p className="text-sm whitespace-pre-wrap" data-testid="text-message-content">
                        {message.content}
                      </p>
                    </CardContent>
                  </Card>
                  {message.citations && message.citations.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {message.citations.map((citation, idx) => (
                        <Badge
                          key={idx}
                          variant="outline"
                          className="text-xs cursor-pointer hover-elevate"
                          data-testid={`badge-citation-${idx}`}
                        >
                          <ExternalLink className="w-3 h-3 mr-1" />
                          {citation.title}
                        </Badge>
                      ))}
                    </div>
                  )}
                  <p className="text-xs text-muted-foreground px-1">
                    {message.timestamp}
                  </p>
                </div>
                {message.role === "user" && (
                  <div className="w-8 h-8 rounded-md bg-secondary flex items-center justify-center flex-shrink-0">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </ScrollArea>
        <div className="p-4 border-t">
          <div className="flex gap-2">
            <Textarea
              placeholder="Ask about ETRM configurations, business rules, or troubleshooting..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              className="min-h-[60px] max-h-[120px] resize-none"
              data-testid="input-chat-message"
            />
            <Button
              onClick={handleSend}
              disabled={!input.trim()}
              data-testid="button-send-message"
              className="self-end"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
