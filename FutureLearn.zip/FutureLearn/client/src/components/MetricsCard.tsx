import { Card, CardContent } from "@/components/ui/card";
import { TrendingDown, TrendingUp } from "lucide-react";
import { LucideIcon } from "lucide-react";

interface MetricsCardProps {
  title: string;
  value: string;
  subtitle: string;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  icon: LucideIcon;
}

export default function MetricsCard({ title, value, subtitle, trend, icon: Icon }: MetricsCardProps) {
  return (
    <Card data-testid={`card-metric-${title.toLowerCase().replace(/\s/g, '-')}`}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-2">
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center">
            <Icon className="w-4 h-4 text-primary" />
          </div>
        </div>
        <div className="space-y-1">
          <p className="text-3xl font-bold" data-testid="text-metric-value">{value}</p>
          <div className="flex items-center gap-2">
            <p className="text-xs text-muted-foreground">{subtitle}</p>
            {trend && (
              <div className={`flex items-center gap-0.5 text-xs font-medium ${
                trend.isPositive ? 'text-emerald-500' : 'text-red-500'
              }`}>
                {trend.isPositive ? (
                  <TrendingUp className="w-3 h-3" />
                ) : (
                  <TrendingDown className="w-3 h-3" />
                )}
                <span data-testid="text-trend">{Math.abs(trend.value)}%</span>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
