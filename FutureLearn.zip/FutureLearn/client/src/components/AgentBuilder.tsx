import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Plus, Database, Shield, Zap } from "lucide-react";

export default function AgentBuilder() {
  const [agentName, setAgentName] = useState("");
  const [selectedSources, setSelectedSources] = useState<string[]>([]);
  const [critiqueEnabled, setCritiqueEnabled] = useState(true);
  
  const dataSources = [
    "Project Design Documents",
    "Energy Trading Lifecycle Flows",
    "Configuration Guides",
    "Test Cases & UAT Scripts",
    "Defects & Resolution Logs",
    "SOPs & Playbooks",
  ];

  const toggleSource = (source: string) => {
    setSelectedSources(prev =>
      prev.includes(source)
        ? prev.filter(s => s !== source)
        : [...prev, source]
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" data-testid="container-agent-builder">
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle className="text-lg">Configure Custom Agent</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="general">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="general">General</TabsTrigger>
              <TabsTrigger value="sources">Data Sources</TabsTrigger>
              <TabsTrigger value="critique">Critique & Validation</TabsTrigger>
            </TabsList>
            <TabsContent value="general" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="agent-name">Agent Name</Label>
                <Input
                  id="agent-name"
                  placeholder="e.g., Risk Assessment Specialist"
                  value={agentName}
                  onChange={(e) => setAgentName(e.target.value)}
                  data-testid="input-agent-name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="agent-description">Description</Label>
                <Input
                  id="agent-description"
                  placeholder="Describe the agent's purpose..."
                  data-testid="input-agent-description"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Model</Label>
                  <Badge variant="outline" className="w-full justify-center py-2">
                    GPT-4o
                  </Badge>
                </div>
                <div className="space-y-2">
                  <Label>Temperature</Label>
                  <Badge variant="outline" className="w-full justify-center py-2">
                    0.7
                  </Badge>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="sources" className="space-y-4 mt-4">
              <p className="text-sm text-muted-foreground">
                Select knowledge sources for this agent to access
              </p>
              <div className="space-y-2">
                {dataSources.map((source) => (
                  <div
                    key={source}
                    className={`flex items-center justify-between p-3 rounded-md border cursor-pointer hover-elevate ${
                      selectedSources.includes(source) ? 'bg-primary/5 border-primary/20' : ''
                    }`}
                    onClick={() => toggleSource(source)}
                    data-testid={`source-${source.toLowerCase().replace(/\s/g, '-')}`}
                  >
                    <div className="flex items-center gap-3">
                      <Database className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">{source}</span>
                    </div>
                    {selectedSources.includes(source) && (
                      <Badge variant="secondary" className="text-xs">Selected</Badge>
                    )}
                  </div>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="critique" className="space-y-4 mt-4">
              <div className="flex items-center justify-between p-4 rounded-md border">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-primary" />
                    <Label htmlFor="critique-toggle" className="cursor-pointer">
                      Enable Critique System
                    </Label>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Validate responses with confidence scoring
                  </p>
                </div>
                <Switch
                  id="critique-toggle"
                  checked={critiqueEnabled}
                  onCheckedChange={setCritiqueEnabled}
                  data-testid="switch-critique"
                />
              </div>
              {critiqueEnabled && (
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="item-1">
                    <AccordionTrigger>Validation Rules</AccordionTrigger>
                    <AccordionContent className="space-y-2">
                      <div className="flex items-center justify-between p-2">
                        <span className="text-sm">Minimum confidence threshold</span>
                        <Badge variant="outline">85%</Badge>
                      </div>
                      <div className="flex items-center justify-between p-2">
                        <span className="text-sm">Require citation sources</span>
                        <Badge variant="outline">Enabled</Badge>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-2">
                    <AccordionTrigger>Explainability Settings</AccordionTrigger>
                    <AccordionContent className="space-y-2">
                      <div className="flex items-center justify-between p-2">
                        <span className="text-sm">Show reasoning steps</span>
                        <Badge variant="outline">Enabled</Badge>
                      </div>
                      <div className="flex items-center justify-between p-2">
                        <span className="text-sm">Include source documents</span>
                        <Badge variant="outline">Enabled</Badge>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Preview</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 rounded-md border bg-card space-y-3">
            <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center">
              <Zap className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h4 className="font-semibold" data-testid="text-preview-name">
                {agentName || "Custom Agent"}
              </h4>
              <p className="text-sm text-muted-foreground">
                {selectedSources.length} data sources
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline" className="text-xs">
                <Shield className="w-3 h-3 mr-1" />
                Critique {critiqueEnabled ? 'On' : 'Off'}
              </Badge>
            </div>
          </div>
          <Button className="w-full" data-testid="button-create-agent">
            <Plus className="w-4 h-4 mr-2" />
            Create Agent
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
