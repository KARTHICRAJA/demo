import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ZoomIn, ZoomOut, Maximize2 } from "lucide-react";
import graphBg from '@assets/generated_images/Knowledge_graph_visualization_background_20311d03.png'

export default function KnowledgeGraph() {
  return (
    <Card data-testid="card-knowledge-graph">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <CardTitle className="text-lg">Knowledge Graph</CardTitle>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="outline" data-testid="button-zoom-in">
            <ZoomIn className="w-4 h-4" />
          </Button>
          <Button size="sm" variant="outline" data-testid="button-zoom-out">
            <ZoomOut className="w-4 h-4" />
          </Button>
          <Button size="sm" variant="outline" data-testid="button-fullscreen">
            <Maximize2 className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="relative h-[500px] rounded-md border overflow-hidden bg-card">
          <img 
            src={graphBg} 
            alt="Knowledge Graph" 
            className="w-full h-full object-cover opacity-80"
          />
          <div className="absolute top-4 right-4 space-y-2">
            <Card className="p-3">
              <div className="space-y-2">
                <p className="text-xs font-medium">Legend</p>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-primary" />
                  <span className="text-xs">Documents</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded bg-emerald-500" />
                  <span className="text-xs">Configurations</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rotate-45 bg-amber-500" />
                  <span className="text-xs">Business Rules</span>
                </div>
              </div>
            </Card>
          </div>
          <div className="absolute bottom-4 left-4">
            <Badge className="bg-background/80 backdrop-blur-sm" data-testid="badge-node-count">
              247 nodes • 892 connections
            </Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
