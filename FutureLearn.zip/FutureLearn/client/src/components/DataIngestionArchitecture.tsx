import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Database, FileText, Network, Tags, Layers, GitBranch } from "lucide-react";

export default function DataIngestionArchitecture() {
  const ingestionSteps = [
    {
      title: "Document Parsing",
      icon: FileText,
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
      borderColor: "rgb(59, 130, 246)",
      description: "Multi-format ingestion (HTML, PDF, API docs, Schema definitions)",
      technologies: ["Apache Tika", "PyPDF2", "BeautifulSoup", "Custom parsers"],
    },
    {
      title: "Chunking Strategy",
      icon: Layers,
      color: "text-emerald-500",
      bgColor: "bg-emerald-500/10",
      borderColor: "rgb(16, 185, 129)",
      description: "Parent-Child relationship preservation with hierarchical chunking",
      strategies: [
        "Semantic chunking (512-1024 tokens)",
        "Section-aware splitting (headers, tables)",
        "Parent chunk: Full section context",
        "Child chunks: Specific concepts with backlinks",
      ],
    },
    {
      title: "Metadata Tagging",
      icon: Tags,
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
      borderColor: "rgb(168, 85, 247)",
      description: "Multi-dimensional metadata for precise retrieval",
      metadata: [
        { key: "user_role", values: ["Trader", "Developer", "Back Office", "Risk Manager"] },
        { key: "module", values: ["APM", "Risk", "Settlement", "Trading"] },
        { key: "lifecycle_phase", values: ["Deal Entry", "Valuation", "Settlement", "Reporting"] },
        { key: "doc_type", values: ["API Reference", "Process Guide", "Schema Definition", "Tutorial"] },
        { key: "dependencies", values: ["SimResult", "Connex", "Market Data", "JVS"] },
      ],
    },
    {
      title: "Vector Embeddings",
      icon: Database,
      color: "text-amber-500",
      bgColor: "bg-amber-500/10",
      borderColor: "rgb(245, 158, 11)",
      description: "High-dimensional semantic representations for similarity search",
      technologies: ["OpenAI Ada-002", "Pinecone", "Dimension: 1536"],
    },
    {
      title: "Knowledge Graph",
      icon: Network,
      color: "text-rose-500",
      bgColor: "bg-rose-500/10",
      borderColor: "rgb(244, 63, 94)",
      description: "Explicit relationship mapping between concepts and modules",
      relationships: [
        "APM → Services → Connex",
        "Parametric VaR → SimResult → Market Data",
        "Deal Entry → Validation → Counterparty DB",
        "Settlement → Invoicing → Payment Processing",
      ],
    },
    {
      title: "Hybrid Retrieval",
      icon: GitBranch,
      color: "text-cyan-500",
      bgColor: "bg-cyan-500/10",
      borderColor: "rgb(6, 182, 212)",
      description: "Combined vector similarity + graph traversal for context-aware retrieval",
      approach: "Graph filters context → Vector search finds relevant chunks → Re-rank by relevance",
    },
  ];

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5" />
            Data Ingestion Pipeline Architecture
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Sophisticated multi-stage ingestion for complex technical documentation
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {ingestionSteps.map((step, index) => (
            <Card key={step.title} className="border-l-[4px]" style={{ borderLeftColor: step.borderColor }}>
              <CardHeader>
                <div className="flex items-start gap-3">
                  <div className={`${step.bgColor} p-2 rounded-lg`}>
                    <step.icon className={`w-5 h-5 ${step.color}`} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline" className="text-xs">
                        Stage {index + 1}
                      </Badge>
                      <h3 className="font-semibold">{step.title}</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">{step.description}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                {"technologies" in step && step.technologies && (
                  <div className="flex flex-wrap gap-2">
                    {step.technologies.map((tech) => (
                      <Badge key={tech} variant="secondary" className="text-xs">
                        {tech}
                      </Badge>
                    ))}
                  </div>
                )}

                {"strategies" in step && step.strategies && (
                  <ul className="space-y-1 text-sm">
                    {step.strategies.map((strategy, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-primary mt-1">•</span>
                        <span>{strategy}</span>
                      </li>
                    ))}
                  </ul>
                )}

                {"metadata" in step && step.metadata && (
                  <div className="space-y-2 text-sm">
                    {step.metadata.map((meta) => (
                      <div key={meta.key} className="border rounded p-2">
                        <span className="font-semibold text-xs text-muted-foreground uppercase">
                          {meta.key}:
                        </span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {meta.values.map((value) => (
                            <Badge key={value} variant="outline" className="text-xs">
                              {value}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {"relationships" in step && step.relationships && (
                  <ul className="space-y-1 text-sm">
                    {step.relationships.map((rel, i) => (
                      <li key={i} className="flex items-start gap-2 font-mono text-xs">
                        <span className="text-primary mt-1">→</span>
                        <span>{rel}</span>
                      </li>
                    ))}
                  </ul>
                )}

                {"approach" in step && step.approach && (
                  <p className="text-sm italic bg-muted p-2 rounded">
                    {step.approach}
                  </p>
                )}
              </CardContent>
            </Card>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
