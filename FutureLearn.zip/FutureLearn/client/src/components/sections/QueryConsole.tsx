import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Send, Sparkles } from "lucide-react";

interface QueryConsoleProps {
  title: string;
  placeholder: string;
  onQuery?: (query: string) => void;
  suggestions?: string[];
}

export default function QueryConsole({ title, placeholder, onQuery, suggestions = [] }: QueryConsoleProps) {
  const [query, setQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = () => {
    if (query.trim()) {
      setIsLoading(true);
      onQuery?.(query);
      setTimeout(() => {
        setIsLoading(false);
        setQuery("");
      }, 2000);
    }
  };

  return (
    <Card data-testid="card-query-console">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Textarea
            placeholder={placeholder}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSubmit();
              }
            }}
            className="min-h-[80px]"
            data-testid="input-query"
            disabled={isLoading}
          />
          <Button
            onClick={handleSubmit}
            disabled={!query.trim() || isLoading}
            data-testid="button-submit-query"
            className="self-end"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        {suggestions.length > 0 && (
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground">Quick queries:</p>
            <div className="flex flex-wrap gap-2">
              {suggestions.map((suggestion, idx) => (
                <Badge
                  key={idx}
                  variant="outline"
                  className="cursor-pointer hover-elevate"
                  onClick={() => setQuery(suggestion)}
                  data-testid={`badge-suggestion-${idx}`}
                >
                  {suggestion}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
