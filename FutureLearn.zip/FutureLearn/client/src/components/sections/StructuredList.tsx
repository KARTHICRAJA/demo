import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChevronRight } from "lucide-react";

interface StructuredListItem {
  id: string;
  title: string;
  description?: string;
  badge?: string;
  items?: number;
}

interface StructuredListProps {
  title?: string;
  items: StructuredListItem[];
  onItemClick?: (id: string) => void;
}

export default function StructuredList({ title, items, onItemClick }: StructuredListProps) {
  return (
    <div className="space-y-3">
      {title && <h3 className="font-semibold">{title}</h3>}
      <div className="space-y-2">
        {items.map((item) => (
          <Card
            key={item.id}
            className="hover-elevate cursor-pointer transition-all"
            onClick={() => onItemClick?.(item.id)}
            data-testid={`list-item-${item.id}`}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-medium" data-testid="text-item-title">{item.title}</h4>
                    {item.badge && (
                      <Badge variant="secondary" className="text-xs">
                        {item.badge}
                      </Badge>
                    )}
                  </div>
                  {item.description && (
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                  )}
                  {item.items !== undefined && (
                    <p className="text-xs text-muted-foreground mt-1">
                      {item.items} {item.items === 1 ? 'item' : 'items'}
                    </p>
                  )}
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
