interface PageLayoutProps {
  title: string;
  description: string;
  children: React.ReactNode;
  heroImage?: string;
}

export default function PageLayout({ title, description, children, heroImage }: PageLayoutProps) {
  return (
    <div className="space-y-6">
      {heroImage ? (
        <div className="relative h-[200px] rounded-lg overflow-hidden">
          <img src={heroImage} alt={title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/80 to-transparent flex items-center">
            <div className="px-8 space-y-2 max-w-2xl">
              <h1 className="text-3xl font-bold" data-testid="text-page-title">{title}</h1>
              <p className="text-muted-foreground">{description}</p>
            </div>
          </div>
        </div>
      ) : (
        <div>
          <h1 className="text-3xl font-bold mb-2" data-testid="text-page-title">{title}</h1>
          <p className="text-muted-foreground">{description}</p>
        </div>
      )}
      {children}
    </div>
  );
}
