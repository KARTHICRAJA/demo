import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Network, ChevronRight, FileText, Database, Zap } from "lucide-react";

type GraphNode = {
  id: string;
  label: string;
  type: "module" | "process" | "concept" | "api";
  children?: GraphNode[];
  metadata?: {
    role?: string[];
    phase?: string;
    dependencies?: string[];
  };
};

const knowledgeGraph: GraphNode = {
  id: "root",
  label: "Endur ETRM System",
  type: "module",
  children: [
    {
      id: "trade-lifecycle",
      label: "Trade Lifecycle",
      type: "process",
      metadata: { phase: "Trading", role: ["Trader", "Back Office"] },
      children: [
        {
          id: "deal-entry",
          label: "Deal Entry",
          type: "process",
          metadata: { phase: "Execution", role: ["Trader"], dependencies: ["deal-validation", "counterparty"] },
        },
        {
          id: "valuation",
          label: "Valuation",
          type: "process",
          metadata: { phase: "Valuation", role: ["Trader", "Risk"], dependencies: ["market-data", "simresult"] },
        },
        {
          id: "settlement",
          label: "Settlement",
          type: "process",
          metadata: { phase: "Settlement", role: ["Back Office"], dependencies: ["invoicing", "payment-processing"] },
        },
      ],
    },
    {
      id: "risk-management",
      label: "Risk Management",
      type: "module",
      metadata: { role: ["Risk", "Developer"] },
      children: [
        {
          id: "parametric-var",
          label: "Parametric VaR",
          type: "concept",
          metadata: { dependencies: ["simresult", "market-data"] },
          children: [
            {
              id: "simresult",
              label: "SimResult",
              type: "api",
              metadata: { role: ["Developer"], dependencies: ["simulation-engine"] },
            },
          ],
        },
        {
          id: "standard-var",
          label: "Standard VaR",
          type: "concept",
          metadata: { dependencies: ["historical-data"] },
        },
      ],
    },
    {
      id: "apm",
      label: "APM (Advanced Process Manager)",
      type: "module",
      metadata: { role: ["Developer", "Back Office"] },
      children: [
        {
          id: "apm-services",
          label: "Services",
          type: "concept",
          metadata: { dependencies: ["connex"] },
        },
        {
          id: "connex",
          label: "Connex",
          type: "api",
          metadata: { role: ["Developer"] },
        },
      ],
    },
  ],
};

type KnowledgeGraphNavigatorProps = {
  onNodeSelect: (path: string[], node: GraphNode) => void;
};

export default function KnowledgeGraphNavigator({ onNodeSelect }: KnowledgeGraphNavigatorProps) {
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set(["root"]));
  const [selectedPath, setSelectedPath] = useState<string[]>([]);

  const toggleNode = (nodeId: string) => {
    const newExpanded = new Set(expandedNodes);
    if (newExpanded.has(nodeId)) {
      newExpanded.delete(nodeId);
    } else {
      newExpanded.add(nodeId);
    }
    setExpandedNodes(newExpanded);
  };

  const selectNode = (path: string[], node: GraphNode) => {
    const fullPath = [...path, node.id];
    setSelectedPath(fullPath);
    onNodeSelect(fullPath, node);
  };

  const renderNode = (node: GraphNode, path: string[] = [], depth: number = 0) => {
    const isExpanded = expandedNodes.has(node.id);
    const currentFullPath = [...path, node.id].join("/");
    const isSelected = selectedPath.join("/") === currentFullPath;
    const hasChildren = node.children && node.children.length > 0;

    const getTypeColor = (type: string) => {
      switch (type) {
        case "module": return "text-blue-500";
        case "process": return "text-emerald-500";
        case "concept": return "text-purple-500";
        case "api": return "text-amber-500";
        default: return "text-gray-500";
      }
    };

    const getTypeIcon = (type: string) => {
      switch (type) {
        case "module": return <Database className="w-3 h-3" />;
        case "process": return <Zap className="w-3 h-3" />;
        case "concept": return <Network className="w-3 h-3" />;
        case "api": return <FileText className="w-3 h-3" />;
        default: return <FileText className="w-3 h-3" />;
      }
    };

    return (
      <div key={node.id} className="select-none">
        <div
          className={`flex items-center gap-2 py-1.5 px-2 rounded cursor-pointer hover-elevate ${
            isSelected ? "bg-primary/10 border border-primary/20" : ""
          }`}
          style={{ paddingLeft: `${depth * 1.5 + 0.5}rem` }}
          onClick={() => selectNode(path, node)}
          data-testid={`graph-node-${node.id}`}
        >
          {hasChildren && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                toggleNode(node.id);
              }}
              className="p-0.5 hover-elevate rounded"
              data-testid={`toggle-${node.id}`}
            >
              <ChevronRight
                className={`w-3 h-3 transition-transform ${isExpanded ? "rotate-90" : ""}`}
              />
            </button>
          )}
          {!hasChildren && <div className="w-4" />}
          <div className={`${getTypeColor(node.type)}`}>
            {getTypeIcon(node.type)}
          </div>
          <span className="text-sm font-medium flex-1">{node.label}</span>
          <Badge variant="outline" className="text-xs">
            {node.type}
          </Badge>
        </div>

        {isExpanded && hasChildren && (
          <div>
            {node.children!.map((child) => renderNode(child, [...path, node.id], depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Network className="w-5 h-5" />
          Knowledge Graph Navigator
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Explore document dependencies and trade lifecycle phases
        </p>
      </CardHeader>
      <CardContent className="p-4">
        <div className="space-y-1 max-h-[600px] overflow-y-auto">
          {renderNode(knowledgeGraph)}
        </div>
      </CardContent>
    </Card>
  );
}
