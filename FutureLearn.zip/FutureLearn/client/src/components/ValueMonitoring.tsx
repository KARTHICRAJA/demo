import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, DollarSign, Users, AlertTriangle } from "lucide-react";

export default function ValueMonitoring() {
  const roiMetrics = {
    totalSavings: "$1.2M",
    savingsBreakdown: [
      { category: "Reduced Incident Time", value: 450000, percentage: 37.5 },
      { category: "Faster Onboarding", value: 360000, percentage: 30 },
      { category: "Productivity Gains", value: 270000, percentage: 22.5 },
      { category: "Knowledge Retention", value: 120000, percentage: 10 },
    ],
    knowledgeLossRisk: {
      current: 23,
      previous: 67,
      reduction: 66,
    },
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6" data-testid="container-value-monitoring">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-primary" />
            ROI Analysis
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <p className="text-sm text-muted-foreground">Total Annual Savings</p>
            <p className="text-4xl font-bold text-primary mt-1" data-testid="text-total-savings">
              {roiMetrics.totalSavings}
            </p>
            <Badge className="mt-2 bg-emerald-500/10 text-emerald-500 border-emerald-500/20">
              <TrendingUp className="w-3 h-3 mr-1" />
              156% ROI
            </Badge>
          </div>
          <div className="space-y-4">
            <p className="text-sm font-medium">Savings Breakdown</p>
            {roiMetrics.savingsBreakdown.map((item) => (
              <div key={item.category} className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">{item.category}</span>
                  <span className="font-medium" data-testid={`text-savings-${item.category.toLowerCase().replace(/\s/g, '-')}`}>
                    ${(item.value / 1000).toFixed(0)}K
                  </span>
                </div>
                <Progress value={item.percentage} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-500" />
            Knowledge Loss Risk
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-md border bg-card">
              <p className="text-sm text-muted-foreground">Current Risk Score</p>
              <p className="text-3xl font-bold mt-1" data-testid="text-current-risk">
                {roiMetrics.knowledgeLossRisk.current}%
              </p>
              <Badge variant="secondary" className="mt-2 bg-emerald-500/10 text-emerald-500 border-0">
                Low Risk
              </Badge>
            </div>
            <div className="p-4 rounded-md border bg-card">
              <p className="text-sm text-muted-foreground">Previous Risk Score</p>
              <p className="text-3xl font-bold mt-1 text-muted-foreground" data-testid="text-previous-risk">
                {roiMetrics.knowledgeLossRisk.previous}%
              </p>
              <Badge variant="secondary" className="mt-2 bg-red-500/10 text-red-500 border-0">
                High Risk
              </Badge>
            </div>
          </div>
          <div className="p-4 rounded-md border-2 border-primary/20 bg-primary/5">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="font-semibold text-lg" data-testid="text-risk-reduction">
                  {roiMetrics.knowledgeLossRisk.reduction}% Reduction
                </p>
                <p className="text-sm text-muted-foreground">
                  in knowledge loss risk since deployment
                </p>
              </div>
            </div>
          </div>
          <div className="space-y-3">
            <p className="text-sm font-medium">Impact Metrics</p>
            <div className="flex items-center justify-between p-3 rounded-md border">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm">Staff Retention Rate</span>
              </div>
              <Badge variant="outline">94%</Badge>
            </div>
            <div className="flex items-center justify-between p-3 rounded-md border">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm">Knowledge Transfer Success</span>
              </div>
              <Badge variant="outline">87%</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
