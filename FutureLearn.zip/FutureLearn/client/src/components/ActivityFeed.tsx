import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CheckCircle2, AlertCircle, Info, XCircle } from "lucide-react";

interface Activity {
  id: string;
  agentName: string;
  action: string;
  timestamp: string;
  type: "success" | "error" | "info" | "warning";
}

const typeConfig = {
  success: { icon: CheckCircle2, className: "text-emerald-500" },
  error: { icon: XCircle, className: "text-red-500" },
  info: { icon: Info, className: "text-primary" },
  warning: { icon: AlertCircle, className: "text-amber-500" },
};

interface ActivityFeedProps {
  activities: Activity[];
}

export default function ActivityFeed({ activities }: ActivityFeedProps) {
  return (
    <Card data-testid="card-activity-feed">
      <CardHeader>
        <CardTitle className="text-lg">Real-time Activity</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[400px]">
          <div className="space-y-0">
            {activities.map((activity, index) => {
              const config = typeConfig[activity.type];
              const Icon = config.icon;
              return (
                <div
                  key={activity.id}
                  className={`px-6 py-4 hover-elevate ${
                    index !== activities.length - 1 ? "border-b" : ""
                  }`}
                  data-testid={`activity-item-${activity.id}`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`mt-0.5 ${config.className}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center justify-between gap-2">
                        <Badge variant="outline" className="text-xs">
                          {activity.agentName}
                        </Badge>
                        <span className="text-xs text-muted-foreground whitespace-nowrap">
                          {activity.timestamp}
                        </span>
                      </div>
                      <p className="text-sm" data-testid="text-activity-action">{activity.action}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
