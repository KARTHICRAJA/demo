import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Send, Sparkles, Loader2 } from "lucide-react";
import mermaid from "mermaid";

type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  structuredOutput?: {
    conceptSummary?: string;
    comparativeTable?: string;
    visualAid?: {
      type: "mermaid" | "flowchart";
      code: string;
    };
  };
};

type StructuredChatInterfaceProps = {
  context?: {
    selectedPath: string[];
    nodeLabel: string;
  };
};

export default function StructuredChatInterface({ context }: StructuredChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    mermaid.initialize({ 
      startOnLoad: true, 
      theme: 'default',
      securityLevel: 'loose',
    });
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    // Render mermaid diagrams whenever messages change
    const renderDiagrams = async () => {
      const elements = Array.from(document.querySelectorAll('.mermaid-diagram'));
      for (const element of elements) {
        if (element.getAttribute('data-processed') !== 'true') {
          const code = element.getAttribute('data-mermaid-code');
          if (code) {
            try {
              const { svg } = await mermaid.render(`mermaid-${Date.now()}-${Math.random()}`, code);
              element.innerHTML = svg;
              element.setAttribute('data-processed', 'true');
            } catch (error) {
              console.error('Mermaid rendering error:', error);
            }
          }
        }
      }
    };
    renderDiagrams();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    // Simulate AI response with structured output
    setTimeout(() => {
      const assistantMessage = generateStructuredResponse(input, context);
      setMessages((prev) => [...prev, assistantMessage]);
      setIsLoading(false);
    }, 1500);
  };

  const renderMarkdownTable = (markdown: string) => {
    const lines = markdown.trim().split('\n');
    const headers = lines[0].split('|').filter(cell => cell.trim());
    const rows = lines.slice(2).map(line => 
      line.split('|').filter(cell => cell.trim())
    );

    return (
      <div className="overflow-x-auto my-4">
        <table className="w-full border-collapse text-sm">
          <thead>
            <tr className="border-b-2 border-primary/20">
              {headers.map((header, i) => (
                <th key={i} className="text-left p-2 font-semibold bg-muted/50">
                  {header.trim()}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, i) => (
              <tr key={i} className="border-b border-border">
                {row.map((cell, j) => (
                  <td key={j} className="p-2">
                    {cell.trim()}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Sparkles className="w-5 h-5" />
          Structured Analysis Chat
        </CardTitle>
        {context && (
          <Badge variant="outline" className="w-fit">
            Context: {context.nodeLabel}
          </Badge>
        )}
      </CardHeader>
      <CardContent className="flex-1 flex flex-col gap-4 p-4">
        <div className="flex-1 overflow-y-auto space-y-4 min-h-0">
          {messages.length === 0 && (
            <div className="text-center text-muted-foreground py-8">
              <Sparkles className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p className="text-sm">Ask a question to explore Endur documentation</p>
              <p className="text-xs mt-2">Try: "Compare parametric VaR vs standard VaR"</p>
            </div>
          )}
          
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[85%] rounded-lg p-3 ${
                  message.role === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted"
                }`}
              >
                {message.role === "user" ? (
                  <p className="text-sm">{message.content}</p>
                ) : (
                  <div className="space-y-4">
                    {message.structuredOutput?.conceptSummary && (
                      <div className="bg-blue-500/10 border border-blue-500/20 rounded p-3">
                        <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                          <Badge variant="default" className="text-xs">Concept Summary</Badge>
                        </h4>
                        <p className="text-sm leading-relaxed">
                          {message.structuredOutput.conceptSummary}
                        </p>
                      </div>
                    )}

                    {message.structuredOutput?.comparativeTable && (
                      <div>
                        <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                          <Badge variant="default" className="text-xs">Comparative Analysis</Badge>
                        </h4>
                        {renderMarkdownTable(message.structuredOutput.comparativeTable)}
                      </div>
                    )}

                    {message.structuredOutput?.visualAid && (
                      <div>
                        <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                          <Badge variant="default" className="text-xs">Visual Diagram</Badge>
                        </h4>
                        <div className="bg-white p-4 rounded border">
                          <div 
                            className="mermaid-diagram"
                            data-mermaid-code={message.structuredOutput.visualAid.code}
                          />
                        </div>
                      </div>
                    )}

                    {!message.structuredOutput && (
                      <p className="text-sm">{message.content}</p>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-muted rounded-lg p-3 flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="text-sm">Analyzing documentation...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        <div className="flex gap-2">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about Endur concepts, compare features, or explore workflows..."
            className="resize-none"
            rows={2}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            data-testid="input-chat-query"
          />
          <Button 
            onClick={handleSend} 
            disabled={isLoading || !input.trim()}
            data-testid="button-send-message"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// Mock AI response generator with structured output
function generateStructuredResponse(query: string, context?: { selectedPath: string[]; nodeLabel: string }): Message {
  const lowerQuery = query.toLowerCase();

  // Example 1: Settlement workflow comparison
  if (lowerQuery.includes("settlement") && (lowerQuery.includes("gas") || lowerQuery.includes("power"))) {
    return {
      id: Date.now().toString(),
      role: "assistant",
      content: "",
      structuredOutput: {
        conceptSummary: "Physical gas trades and financial power swaps follow different settlement workflows in Endur. Physical gas requires delivery scheduling, nomination management, and volume reconciliation, while financial power swaps settle based on index prices without physical delivery. Both integrate with the invoicing module but follow distinct document flows.",
        comparativeTable: `| Aspect | Physical Gas Trade | Financial Power Swap |
| --- | --- | --- |
| Delivery Type | Physical delivery required | Cash settlement only |
| Nomination | Required (pipeline nomination) | Not applicable |
| Volume Reconciliation | Daily meter readings | Index-based calculation |
| Invoice Generation | Actual delivered volumes | Notional × (Market Price - Strike) |
| Settlement Timing | Monthly based on actuals | Daily mark-to-market |
| Document Flow | Nomination → Confirmation → Invoice → Payment | Deal Confirmation → MTM Report → Cash Settlement |`,
        visualAid: {
          type: "mermaid",
          code: `sequenceDiagram
    participant Trader
    participant EndurDealEntry
    participant Scheduling
    participant Invoicing
    participant Settlement
    
    Note over Trader,Settlement: Physical Gas Trade Flow
    Trader->>EndurDealEntry: Enter Physical Gas Deal
    EndurDealEntry->>Scheduling: Create Nomination
    Scheduling->>Scheduling: Pipeline Coordination
    Scheduling->>Invoicing: Send Actual Volumes
    Invoicing->>Settlement: Generate Invoice
    Settlement->>Settlement: Process Payment
    
    Note over Trader,Settlement: Financial Power Swap Flow
    Trader->>EndurDealEntry: Enter Financial Swap
    EndurDealEntry->>Invoicing: Daily MTM Calculation
    Invoicing->>Settlement: Net Cash Settlement
    Settlement->>Settlement: Process Payment`
        }
      }
    };
  }

  // Example 2: VaR comparison
  if (lowerQuery.includes("var") || lowerQuery.includes("parametric") || lowerQuery.includes("standard")) {
    return {
      id: Date.now().toString(),
      role: "assistant",
      content: "",
      structuredOutput: {
        conceptSummary: "Endur supports two primary VaR calculation methodologies: Parametric VaR and Standard (Historical) VaR. Parametric VaR uses variance-covariance matrices and assumes normal distribution of returns, enabling faster computation. Standard VaR uses historical simulation with actual price movements, providing more accurate tail risk assessment but requiring more computational resources.",
        comparativeTable: `| Feature | Parametric VaR | Standard VaR |
| --- | --- | --- |
| Calculation Method | Variance-covariance matrix | Historical simulation |
| Distribution Assumption | Normal distribution | No assumption (empirical) |
| Data Requirements | Volatilities and correlations | Full historical price series |
| Computation Speed | Fast (milliseconds) | Slower (seconds to minutes) |
| Tail Risk Accuracy | Underestimates extreme events | Captures actual tail behavior |
| Dependencies | SimResult, Market Data | Historical Data module |
| Best Use Case | Daily monitoring, large portfolios | Regulatory reporting, stress testing |`,
        visualAid: {
          type: "mermaid",
          code: `graph TD
    A[Portfolio Positions] --> B{VaR Method Selection}
    B --> C[Parametric VaR]
    B --> D[Standard VaR]
    
    C --> E[Load Market Data]
    E --> F[Calculate Variance-Covariance]
    F --> G[SimResult Engine]
    G --> H[Parametric VaR Output]
    
    D --> I[Load Historical Prices]
    I --> J[Simulate Historical Scenarios]
    J --> K[Sort P&L Distribution]
    K --> L[Standard VaR Output]
    
    H --> M[Risk Report]
    L --> M
    
    style C fill:#e3f2fd
    style D fill:#fff3e0
    style M fill:#e8f5e9`
        }
      }
    };
  }

  // Example 3: APM workflow
  if (lowerQuery.includes("apm") || lowerQuery.includes("service") || lowerQuery.includes("connex")) {
    return {
      id: Date.now().toString(),
      role: "assistant",
      content: "",
      structuredOutput: {
        conceptSummary: "The Advanced Process Manager (APM) is Endur's workflow automation engine that orchestrates batch processes, scheduled tasks, and system integrations. APM Services define reusable business logic, while Connex provides the inter-system connectivity framework. Together, they enable automated settlement processing, risk batch runs, and external system synchronization.",
        comparativeTable: `| Component | APM Services | Connex |
| --- | --- | --- |
| Purpose | Workflow orchestration | System connectivity |
| Scope | Internal Endur processes | External integrations |
| Configuration | Service definitions in APM | Connection profiles |
| Execution | Scheduled or event-driven | Request/response based |
| Use Cases | EOD batch, settlement runs | Market data feeds, ERP sync |
| Dependencies | APM engine, database | Network protocols, APIs |`,
        visualAid: {
          type: "mermaid",
          code: `graph LR
    A[APM Scheduler] --> B[APM Service: EOD Process]
    B --> C[Valuation Service]
    B --> D[Risk Calculation Service]
    B --> E[Settlement Service]
    
    C --> F[SimResult]
    D --> F
    E --> G[Invoicing Module]
    
    G --> H[Connex: ERP Connector]
    H --> I[External ERP System]
    
    F --> J[Connex: Market Data]
    J --> K[External Price Feeds]
    
    style A fill:#e1f5fe
    style B fill:#f3e5f5
    style H fill:#fff9c4
    style J fill:#fff9c4`
        }
      }
    };
  }

  // Default response
  return {
    id: Date.now().toString(),
    role: "assistant",
    content: "",
    structuredOutput: {
      conceptSummary: `Your query about "${query}" has been processed. ${context ? `Current context: ${context.nodeLabel}. ` : ''}This is a demonstration of the structured output format. In production, this would retrieve relevant documentation chunks from the vector database, filtered by the knowledge graph context you've selected.`,
      comparativeTable: `| Aspect | Description | Details |
| --- | --- | --- |
| Query | ${query} | User input |
| Context | ${context?.nodeLabel || 'None'} | Knowledge graph selection |
| Retrieval Strategy | Hybrid RAG | Vector DB + Knowledge Graph |
| Output Format | Structured | Summary + Table + Diagram |`,
      visualAid: {
        type: "mermaid",
        code: `graph TD
    A[User Query] --> B[Knowledge Graph Filter]
    B --> C[Vector Database Search]
    C --> D[Retrieve Relevant Chunks]
    D --> E[LLM Processing]
    E --> F[Structured Output]
    F --> G[Concept Summary]
    F --> H[Comparative Table]
    F --> I[Visual Diagram]
    
    style A fill:#e3f2fd
    style F fill:#f3e5f5
    style G fill:#e8f5e9
    style H fill:#fff9c4
    style I fill:#fce4ec`
      }
    }
  };
}
