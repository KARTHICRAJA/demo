import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import ThemeToggle from "@/components/ThemeToggle";
import Welcome from "@/pages/Welcome";
import Chat from "@/pages/Chat";
import AIAgents from "@/pages/AIAgents";
import EndurDocuments from "@/pages/EndurDocuments";
import ETRMProcess from "@/pages/ETRMProcess";
import OperationalMonitoring from "@/pages/OperationalMonitoring";
import BusinessAnalyst from "@/pages/BusinessAnalyst";
import Architect from "@/pages/Architect";
import OpsEngineer from "@/pages/OpsEngineer";
import UserAdministration from "@/pages/UserAdministration";
import AIInsights from "@/pages/AIInsights";
import KnowledgeGraphPage from "@/pages/KnowledgeGraphPage";
import AgentBuilderPage from "@/pages/AgentBuilderPage";
import MetricsPage from "@/pages/MetricsPage";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Welcome} />
      <Route path="/agents" component={AIAgents} />
      <Route path="/chat" component={Chat} />
      <Route path="/documents" component={EndurDocuments} />
      <Route path="/process" component={ETRMProcess} />
      <Route path="/monitoring" component={OperationalMonitoring} />
      <Route path="/business-analyst" component={BusinessAnalyst} />
      <Route path="/architect" component={Architect} />
      <Route path="/ops-engineer" component={OpsEngineer} />
      <Route path="/users" component={UserAdministration} />
      <Route path="/insights" component={AIInsights} />
      <Route path="/knowledge-graph" component={KnowledgeGraphPage} />
      <Route path="/builder" component={AgentBuilderPage} />
      <Route path="/metrics" component={MetricsPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SidebarProvider style={style as React.CSSProperties}>
          <div className="flex h-screen w-full">
            <AppSidebar />
            <div className="flex flex-col flex-1">
              <header className="flex items-center justify-between p-4 border-b sticky top-0 bg-background z-50">
                <SidebarTrigger data-testid="button-sidebar-toggle" />
                <ThemeToggle />
              </header>
              <main className="flex-1 overflow-auto p-8">
                <Router />
              </main>
            </div>
          </div>
        </SidebarProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}
