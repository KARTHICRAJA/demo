import React from "react";
import { Layout } from "@/components/layout/Layout";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, AlertTriangle, ArrowRight, FileJson, Code } from "lucide-react";

export function RequirementAnalysis() {
  return (
    <Layout>
      <div className="flex flex-col h-full bg-background p-6 md:p-10 space-y-8 overflow-y-auto">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Badge variant="outline" className="text-primary border-primary/30 bg-primary/5">SKILL MODULE</Badge>
            <span className="text-muted-foreground text-sm">ID: REQ-2025-001</span>
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Requirement Analysis</h1>
          <p className="text-lg text-muted-foreground mt-2 max-w-3xl">
            Analyze and map business requirements to Endur native capabilities vs. custom development.
          </p>
        </div>

        <Tabs defaultValue="scenario" className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-3 bg-secondary/50">
            <TabsTrigger value="scenario">Scenario</TabsTrigger>
            <TabsTrigger value="analysis">Analysis</TabsTrigger>
            <TabsTrigger value="solution">Solution Map</TabsTrigger>
          </TabsList>
          
          <TabsContent value="scenario" className="mt-6 space-y-4">
            <Card className="bg-card/50 border-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileJson className="w-5 h-5 text-blue-400" />
                  Business Request: Renewable PPA Modeling
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                <p className="text-muted-foreground">
                  <strong>Client:</strong> GreenEnergy Co.<br/>
                  <strong>Goal:</strong> Model a 10-year Solar Power Purchase Agreement (PPA) with hourly shaping and negative price protection.
                </p>
                <div className="bg-secondary/30 p-4 rounded-md border border-border/50 font-mono text-xs">
                  "We need to capture a deal where we buy solar power at a fixed price of $35/MWh, but if the Hub price drops below $0, the volume resets to zero. Settlement must be monthly."
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analysis" className="mt-6">
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="border-l-4 border-l-green-500 bg-card/50">
                  <CardHeader><CardTitle className="text-base">Standard Capabilities</CardTitle></CardHeader>
                  <CardContent className="text-sm space-y-2">
                    <div className="flex gap-2 items-start">
                      <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />
                      <span>Fixed Price PPA structure supported via 'Power Swap'.</span>
                    </div>
                    <div className="flex gap-2 items-start">
                      <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />
                      <span>Hourly profiles supported via 'Profile Inputs'.</span>
                    </div>
                  </CardContent>
                </Card>
                <Card className="border-l-4 border-l-yellow-500 bg-card/50">
                  <CardHeader><CardTitle className="text-base">Gaps Identified</CardTitle></CardHeader>
                  <CardContent className="text-sm space-y-2">
                    <div className="flex gap-2 items-start">
                      <AlertTriangle className="w-4 h-4 text-yellow-500 mt-0.5" />
                      <span>Negative price volume reset (curtailment logic) is not native to standard Swap instrument.</span>
                    </div>
                  </CardContent>
                </Card>
             </div>
          </TabsContent>

           <TabsContent value="solution" className="mt-6">
            <Card className="bg-card/50 border-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="w-5 h-5 text-purple-400" />
                  Recommended Implementation
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h4 className="font-semibold text-sm">Option A: Advanced Option (Native)</h4>
                  <p className="text-sm text-muted-foreground">Model as a composite deal: Swap + Asian Put Option with strike at $0 to offset the loss.</p>
                </div>
                 <div className="space-y-2">
                  <h4 className="font-semibold text-sm">Option B: OpenComponents (Scripted)</h4>
                  <p className="text-sm text-muted-foreground">Implement a JVS Post-Process script on the Valuation simulation to override volume to 0 when hourly price &lt; 0.</p>
                </div>
                <div className="bg-primary/10 p-3 rounded border border-primary/20 text-primary text-sm font-medium flex items-center gap-2">
                  <CheckCircle className="w-4 h-4" /> Recommendation: Option B for better reporting transparency.
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
