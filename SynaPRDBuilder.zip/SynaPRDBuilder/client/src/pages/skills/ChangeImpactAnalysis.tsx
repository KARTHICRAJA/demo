import React from "react";
import { Layout } from "@/components/layout/Layout";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { GitCommit, GitPullRequest, AlertOctagon } from "lucide-react";

export function ChangeImpactAnalysis() {
  return (
    <Layout>
       <div className="flex flex-col h-full bg-background p-6 md:p-10 space-y-8 overflow-y-auto">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Badge variant="outline" className="text-primary border-primary/30 bg-primary/5">SKILL MODULE</Badge>
            <span className="text-muted-foreground text-sm">ID: CHG-2025-104</span>
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Change Impact Analysis</h1>
          <p className="text-lg text-muted-foreground mt-2 max-w-3xl">
            Assessing the regression risks of upgrades, patches, and configuration changes.
          </p>
        </div>

        <div className="space-y-6">
          <Card className="bg-card/50 border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GitPullRequest className="w-5 h-5 text-orange-400" />
                Change Request: Upgrade Endur v23 to v25
              </CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6">
               <div className="space-y-3">
                 <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Affected Modules</h3>
                 <ul className="text-sm space-y-2">
                   <li className="flex items-center gap-2">
                     <span className="w-2 h-2 rounded-full bg-red-500"></span>
                     <span>Settlement Engine (Deprecated functions)</span>
                   </li>
                   <li className="flex items-center gap-2">
                     <span className="w-2 h-2 rounded-full bg-yellow-500"></span>
                     <span>Connex (Java Version Update)</span>
                   </li>
                   <li className="flex items-center gap-2">
                     <span className="w-2 h-2 rounded-full bg-green-500"></span>
                     <span>Deal Capture (No Change)</span>
                   </li>
                 </ul>
               </div>
               
               <div className="space-y-3 col-span-2">
                 <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Risk Assessment</h3>
                 <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-md space-y-2">
                   <div className="flex items-center gap-2 text-red-400 font-medium">
                     <AlertOctagon className="w-4 h-4" />
                     Critical Risk: Custom Invoicing Scripts
                   </div>
                   <p className="text-sm text-muted-foreground">
                     Endur v25 removes support for `Table.formatQuery()`. 14 custom invoicing scripts use this method. These will throw runtime exceptions immediately post-upgrade.
                   </p>
                   <div className="mt-2 p-2 bg-background/50 rounded text-xs font-mono">
                     Action: Refactor to use `DBUserTable.loadFromDB()` before migration.
                   </div>
                 </div>
               </div>
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <Card className="bg-card/50 border-border">
               <CardHeader><CardTitle className="text-base">Database Schema Changes</CardTitle></CardHeader>
               <CardContent>
                 <div className="space-y-4">
                   <div className="flex justify-between items-center text-sm p-2 border-b border-border/50">
                     <span>Table: `ab_tran`</span>
                     <Badge variant="outline">Modified</Badge>
                   </div>
                   <div className="flex justify-between items-center text-sm p-2 border-b border-border/50">
                     <span>Table: `idx_unit`</span>
                     <Badge variant="outline" className="text-red-400 border-red-400/30">Dropped</Badge>
                   </div>
                   <div className="flex justify-between items-center text-sm p-2 border-b border-border/50">
                     <span>Table: `deal_leg_cflow`</span>
                     <Badge variant="outline" className="text-green-400 border-green-400/30">New Columns</Badge>
                   </div>
                 </div>
               </CardContent>
             </Card>
             
             <Card className="bg-card/50 border-border">
               <CardHeader><CardTitle className="text-base">Regression Test Scope</CardTitle></CardHeader>
               <CardContent>
                 <div className="space-y-2 text-sm text-muted-foreground">
                   <p>Based on impact analysis, the following test suites must be executed:</p>
                   <ul className="list-disc pl-4 space-y-1 mt-2 text-foreground">
                     <li>Full EOD Batch Run (Settlement Focus)</li>
                     <li>Connex Interface Connectivity Check</li>
                     <li>Historical Data Integrity Check (Pre/Post Upgrade)</li>
                   </ul>
                 </div>
               </CardContent>
             </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
