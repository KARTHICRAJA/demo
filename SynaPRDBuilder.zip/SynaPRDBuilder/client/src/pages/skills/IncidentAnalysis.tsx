import React from "react";
import { Layout } from "@/components/layout/Layout";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, Clock, FileText, Terminal } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

export function IncidentAnalysis() {
  return (
    <Layout>
       <div className="flex flex-col h-full bg-background p-6 md:p-10 space-y-8 overflow-y-auto">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Badge variant="outline" className="text-destructive border-destructive/30 bg-destructive/5">INCIDENT REPORT</Badge>
            <span className="text-muted-foreground text-sm">ID: INC-2025-882</span>
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Incident Analysis</h1>
          <p className="text-lg text-muted-foreground mt-2 max-w-3xl">
            Root cause analysis (RCA) and remediation for production system failures.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full pb-20">
           {/* Incident Details */}
           <div className="col-span-2 space-y-6">
             <Card className="bg-card/50 border-border">
               <CardHeader>
                 <CardTitle className="flex items-center gap-2 text-red-400">
                   <Activity className="w-5 h-5" />
                   EOD Batch Failure: PFE Engine Timeout
                 </CardTitle>
               </CardHeader>
               <CardContent className="space-y-4">
                 <div className="grid grid-cols-2 gap-4 text-sm">
                   <div>
                     <span className="text-muted-foreground block">Detected At</span>
                     <span className="font-mono">02:45:00 UTC</span>
                   </div>
                   <div>
                     <span className="text-muted-foreground block">Severity</span>
                     <span className="font-bold text-red-500">Sev 1 (Critical)</span>
                   </div>
                   <div>
                     <span className="text-muted-foreground block">Impact</span>
                     <span>Risk Reports delayed 4h. Traders flying blind.</span>
                   </div>
                   <div>
                     <span className="text-muted-foreground block">Status</span>
                     <Badge variant="secondary">Resolved</Badge>
                   </div>
                 </div>
                 
                 <div className="pt-4 border-t border-border/50">
                   <h3 className="font-semibold mb-2">Description</h3>
                   <p className="text-sm text-muted-foreground">
                     The nightly "Official PFE" simulation workflow failed at step 4/10. The Grid Engine logs showed 40% of worker nodes disconnecting simultaneously.
                   </p>
                 </div>
               </CardContent>
             </Card>

             <Card className="bg-card/50 border-border">
               <CardHeader><CardTitle>Root Cause Analysis (5 Whys)</CardTitle></CardHeader>
               <CardContent className="space-y-4 relative">
                 <div className="absolute left-4 top-4 bottom-4 w-0.5 bg-border"></div>
                 {[
                   "Why did the workflow fail? -> Worker nodes disconnected.",
                   "Why did nodes disconnect? -> OutOfMemoryError (OOM) on JVM.",
                   "Why OOM? -> Heap usage spiked to 100% during 'Gas Swing' valuation.",
                   "Why the spike? -> A new 'Gas Swing' deal was booked with 50,000 hourly profile rows.",
                   "Root Cause -> Deal Skin allowed entry of super-granular profile without aggregation, overwhelming the valuation model."
                 ].map((why, i) => (
                   <div key={i} className="relative pl-8 text-sm">
                     <div className="absolute left-[-5px] top-1.5 w-2.5 h-2.5 rounded-full bg-secondary border border-muted-foreground"></div>
                     {why}
                   </div>
                 ))}
               </CardContent>
             </Card>
           </div>

           {/* Logs & Artifacts */}
           <div className="space-y-6">
              <Card className="bg-black/40 border-border h-full">
                <CardHeader className="pb-2">
                   <CardTitle className="text-sm font-mono text-muted-foreground flex items-center gap-2">
                     <Terminal className="w-4 h-4" />
                     System Logs
                   </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[400px] w-full rounded border border-border/30 bg-black/60 p-4">
                    <pre className="text-[10px] font-mono text-red-300 leading-relaxed">
{`[02:44:58] INFO  SimEngine: Starting batch chunk #42
[02:44:59] DEBUG ValModel: Loading deal 884922...
[02:45:01] WARN  GridNode: Heap usage > 95%
[02:45:02] ERROR JVM: java.lang.OutOfMemoryError: Java heap space
    at com.olf.jm.GasModel.expandProfile(GasModel.java:402)
    at com.olf.jm.Valuation.calc(Valuation.java:112)
[02:45:03] FATAL GridMaster: Heartbeat lost for Worker-04
[02:45:03] FATAL GridMaster: Heartbeat lost for Worker-05
[02:45:05] INFO  Workflow: Aborting due to resource exhaustion.`}
                    </pre>
                  </ScrollArea>
                </CardContent>
              </Card>
           </div>
        </div>
      </div>
    </Layout>
  );
}
