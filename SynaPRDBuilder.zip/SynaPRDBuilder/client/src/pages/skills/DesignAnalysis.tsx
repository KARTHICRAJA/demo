import React from "react";
import { Layout } from "@/components/layout/Layout";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Code, Database, ArrowRight, Network } from "lucide-react";

export function DesignAnalysis() {
  return (
    <Layout>
      <div className="flex flex-col h-full bg-background p-6 md:p-10 space-y-8 overflow-y-auto">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Badge variant="outline" className="text-primary border-primary/30 bg-primary/5">SKILL MODULE</Badge>
            <span className="text-muted-foreground text-sm">ID: DES-2025-042</span>
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Design Analysis</h1>
          <p className="text-lg text-muted-foreground mt-2 max-w-3xl">
            Architecting robust solutions within the Endur ecosystem using OpenComponents and Core Services.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
           {/* Context */}
           <Card className="bg-card/50 border-border">
             <CardHeader>
               <CardTitle className="text-lg">Design Challenge: Real-time Credit Check</CardTitle>
             </CardHeader>
             <CardContent className="text-sm text-muted-foreground space-y-4">
               <p>
                 Design a mechanism to block trades at Deal Entry if the counterparty's exposure exceeds their credit limit, fetching real-time exposure from an external Credit Risk Engine.
               </p>
               <div className="flex flex-col gap-2 mt-4">
                 <div className="flex items-center gap-2 p-2 bg-secondary/50 rounded">
                    <Network className="w-4 h-4 text-blue-400" />
                    <span>Latency Budget: &lt; 200ms</span>
                 </div>
                 <div className="flex items-center gap-2 p-2 bg-secondary/50 rounded">
                    <Database className="w-4 h-4 text-purple-400" />
                    <span>Fail-safe: Allow trade if external system down (soft warn)</span>
                 </div>
               </div>
             </CardContent>
           </Card>

           {/* Architecture Diagram Mockup */}
           <Card className="bg-card/50 border-border border-l-4 border-l-primary">
             <CardHeader>
               <CardTitle className="text-lg">Proposed Architecture</CardTitle>
             </CardHeader>
             <CardContent className="space-y-6">
                <div className="relative pl-4 border-l border-dashed border-muted-foreground/50 space-y-6">
                  <div className="relative">
                    <div className="absolute -left-[21px] top-1 w-3 h-3 rounded-full bg-primary"></div>
                    <h4 className="font-semibold text-foreground">Pre-Processing Script (JVS)</h4>
                    <p className="text-xs text-muted-foreground">Triggered on 'Simulate' button click in Deal Skin.</p>
                  </div>
                  <div className="relative">
                    <div className="absolute -left-[21px] top-1 w-3 h-3 rounded-full bg-blue-500"></div>
                    <h4 className="font-semibold text-foreground">Connex Service Call</h4>
                    <p className="text-xs text-muted-foreground">Async request via REST API to Credit Engine.</p>
                  </div>
                  <div className="relative">
                    <div className="absolute -left-[21px] top-1 w-3 h-3 rounded-full bg-green-500"></div>
                    <h4 className="font-semibold text-foreground">Validation Logic</h4>
                    <p className="text-xs text-muted-foreground">Parse JSON response. If Limit &lt; Exposure, return `Util.exitFail()`.</p>
                  </div>
                </div>
                
                <div className="bg-secondary/50 p-4 rounded border border-border">
                   <h4 className="text-xs font-mono uppercase text-muted-foreground mb-2">Pseudo Code</h4>
                   <pre className="text-[10px] font-mono text-blue-300 overflow-x-auto">
{`try {
   String response = Connex.call("CreditService", payload);
   if (response.status == "DENIED") {
       Util.exitFail("Credit Limit Exceeded: " + response.msg);
   }
} catch (Exception e) {
   Log.error("Credit Check Offline");
   Util.scriptDlg("Warning: Credit check failed. Proceed?");
}`}
                   </pre>
                </div>
             </CardContent>
           </Card>
        </div>
      </div>
    </Layout>
  );
}
