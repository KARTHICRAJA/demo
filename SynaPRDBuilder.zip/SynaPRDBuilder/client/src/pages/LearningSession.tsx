import { Layout } from "@/components/layout/Layout";
import { SplitScreenLayout } from "@/components/synapse/SplitScreenLayout";

export function LearningSession() {
  return (
    <Layout>
      <div className="h-full w-full bg-background">
        <SplitScreenLayout />
      </div>
    </Layout>
  );
}
