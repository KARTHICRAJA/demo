import { Layout } from "@/components/layout/Layout";
import { KnowledgeGraph } from "@/components/synapse/KnowledgeGraph";
import { useLocation } from "wouter";

export function Dashboard() {
  const [_, setLocation] = useLocation();

  const handleNodeClick = (node: any) => {
    // Navigate to learning session if user clicks a node
    // In a real app, we'd pass the node ID
    if (node.status !== 'mastered') {
       setLocation('/learn/mock-session');
    }
  };

  return (
    <Layout>
      <KnowledgeGraph onNodeClick={handleNodeClick} />
    </Layout>
  );
}
