import React, { useState, useRef, useEffect } from 'react';
import { Layout } from "@/components/layout/Layout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Send, Bot, User, Sparkles, Search, Database, FileText, Layers } from "lucide-react";
import { cn } from "@/lib/utils";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  sources?: { title: string; type: string }[];
}

const INITIAL_MESSAGES: Message[] = [
  {
    id: '1',
    role: 'assistant',
    content: "Hello. I am the HyperIQ Discovery Agent. I have access to the full Endur ETRM corpus, including technical documentation, configuration guides, and incident logs. What would you like to explore today?",
    sources: []
  }
];

export function DiscoveryChat() {
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const newUserMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue
    };

    setMessages(prev => [...prev, newUserMsg]);
    setInputValue('');
    setIsTyping(true);

    // Simulate RAG retrieval and response
    setTimeout(() => {
      setIsTyping(false);
      const response: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: "Based on the Endur v25 documentation, implementing a new physically settled gas product requires configuration in both the Reference Manager and the Trading Manager. You'll need to define the 'Delivery Zone' and 'Pipeline' reference data first. \n\nWould you like to see the specific AVS scripts used for nomination validation on this product type?",
        sources: [
          { title: "Endur Reference Manager Guide", type: "Documentation" },
          { title: "Physical Gas Configuration Patterns", type: "Best Practice" },
          { title: "Incident #4922: Nomination Failure", type: "Log" }
        ]
      };
      setMessages(prev => [...prev, response]);
    }, 2000);
  };

  return (
    <Layout>
      <div className="flex flex-col h-full bg-background">
        <div className="flex-1 flex flex-col max-w-5xl mx-auto w-full shadow-sm border-x border-border/30 bg-background/50 backdrop-blur-sm">
          {/* Chat Header */}
          <div className="h-16 border-b border-border flex items-center px-6 justify-between bg-card/30">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary border border-primary/20">
                <Database size={20} />
              </div>
              <div>
                <h1 className="font-semibold text-lg tracking-tight">Corpus Discovery</h1>
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
                  Connected to Endur Knowledge Graph
                </p>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-hidden relative">
            <div ref={scrollRef} className="h-full overflow-y-auto p-6 space-y-8">
              {messages.map((msg) => (
                <div key={msg.id} className={cn("flex gap-4", msg.role === 'user' ? "flex-row-reverse" : "")}>
                   <Avatar className={cn(
                    "h-10 w-10 mt-1 shadow-lg",
                    msg.role === 'assistant' ? "border-primary/30" : "border-border"
                  )}>
                    <AvatarFallback className={cn(
                      msg.role === 'assistant' ? "bg-gradient-to-br from-primary/20 to-purple-500/20 text-primary" : "bg-secondary text-secondary-foreground"
                    )}>
                      {msg.role === 'assistant' ? <Sparkles size={18} /> : <User size={18} />}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className={cn("flex flex-col gap-2 max-w-[80%]", msg.role === 'user' ? "items-end" : "items-start")}>
                    <div className={cn(
                      "p-5 rounded-2xl text-sm leading-relaxed shadow-md",
                      msg.role === 'user' 
                        ? "bg-primary text-primary-foreground rounded-tr-none" 
                        : "bg-card border border-border rounded-tl-none"
                    )}>
                      {msg.content.split('\n').map((line, i) => (
                        <p key={i} className={i > 0 ? "mt-2" : ""}>{line}</p>
                      ))}
                    </div>
                    
                    {/* Sources for Assistant */}
                    {msg.role === 'assistant' && msg.sources && msg.sources.length > 0 && (
                      <div className="flex flex-wrap gap-2 mt-1 animate-in fade-in slide-in-from-top-2">
                        {msg.sources.map((source, idx) => (
                          <Badge key={idx} variant="outline" className="bg-secondary/30 hover:bg-secondary/50 cursor-pointer transition-colors py-1.5 px-3 gap-1.5 border-primary/10">
                            {source.type === 'Documentation' && <FileText size={10} className="text-blue-400" />}
                            {source.type === 'Log' && <Layers size={10} className="text-red-400" />}
                            {source.type === 'Best Practice' && <Sparkles size={10} className="text-yellow-400" />}
                            <span className="opacity-80">{source.title}</span>
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              
              {isTyping && (
                <div className="flex gap-4 animate-in fade-in slide-in-from-bottom-2">
                   <Avatar className="h-10 w-10 mt-1 border-primary/30">
                    <AvatarFallback className="bg-primary/10 text-primary"><Sparkles size={18} /></AvatarFallback>
                  </Avatar>
                  <div className="bg-card border border-border p-5 rounded-2xl rounded-tl-none flex gap-1.5 items-center h-14">
                    <div className="w-2 h-2 bg-primary/50 rounded-full animate-bounce [animation-delay:-0.3s]" />
                    <div className="w-2 h-2 bg-primary/50 rounded-full animate-bounce [animation-delay:-0.15s]" />
                    <div className="w-2 h-2 bg-primary/50 rounded-full animate-bounce" />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Input */}
          <div className="p-6 pt-2">
             <div className="relative shadow-lg rounded-xl overflow-hidden bg-card border border-border/50 focus-within:ring-2 focus-within:ring-primary/20 transition-all">
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Ask about Endur errors, configuration, or architecture..."
                  className="pr-14 border-none bg-transparent h-14 text-base focus-visible:ring-0 px-4"
                />
                <Button 
                  size="icon" 
                  className="absolute right-2 top-2 h-10 w-10 rounded-lg bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground transition-all"
                  onClick={handleSend}
                >
                  <Send className="w-5 h-5" />
                </Button>
             </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
