import React from "react";
import { Layout } from "@/components/layout/Layout";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, ArrowRight, BookOpen, Clock, Star } from "lucide-react";
import { Link } from "wouter";

export function Library() {
  const documents = [
    {
      id: 1,
      title: "Endur ETRM Fundamentals",
      category: "Core Platform",
      description: "Comprehensive guide to Endur v25 architecture, Open Components (OC), and the transition from Classic.",
      readTime: "45 min",
      difficulty: "Beginner",
      progress: 100,
      status: "Mastered"
    },
    {
      id: 2,
      title: "Deal Capture & Trade Lifecycles",
      category: "Front Office",
      description: "Deep dive into physical and financial instrument modeling, deal skins, and transaction types.",
      readTime: "60 min",
      difficulty: "Intermediate",
      progress: 45,
      status: "Learning"
    },
    {
      id: 3,
      title: "Risk Management Frameworks",
      category: "Middle Office",
      description: "Understanding VaR, PFE, stress testing, and Greeks within Endur's risk engine.",
      readTime: "90 min",
      difficulty: "Advanced",
      progress: 0,
      status: "Unseen"
    },
    {
      id: 4,
      title: "Settlement & Accounting",
      category: "Back Office",
      description: "Workflows for invoicing, confirmations, and general ledger integration.",
      readTime: "50 min",
      difficulty: "Intermediate",
      progress: 10,
      status: "Learning"
    },
    {
      id: 5,
      title: "OpenComponents (OC) Development",
      category: "Technical",
      description: "Java-based scripting guide for extending Endur functionality and automating workflows.",
      readTime: "120 min",
      difficulty: "Expert",
      progress: 0,
      status: "Unseen"
    },
    {
      id: 6,
      title: "Connex & Gateway Integration",
      category: "Integration",
      description: "Real-time trade capture and external system integration patterns.",
      readTime: "75 min",
      difficulty: "Advanced",
      progress: 0,
      status: "Unseen"
    }
  ];

  return (
    <Layout>
      <div className="flex flex-col h-full bg-background p-6 md:p-8 space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2">Library</h1>
          <p className="text-muted-foreground">
            Access the complete corpus of Endur ETRM documentation and learning modules.
          </p>
        </div>

        <ScrollArea className="flex-1 -mx-4 px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pb-20">
            {documents.map((doc) => (
              <Card key={doc.id} className="group hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 bg-card/50 backdrop-blur">
                <CardHeader className="space-y-3">
                  <div className="flex items-start justify-between">
                    <Badge variant="outline" className="bg-secondary/50 text-muted-foreground font-mono text-[10px] uppercase tracking-wider">
                      {doc.category}
                    </Badge>
                    {doc.status === "Mastered" && <Star className="w-4 h-4 text-green-500 fill-current" />}
                    {doc.status === "Learning" && <BookOpen className="w-4 h-4 text-yellow-500" />}
                  </div>
                  <CardTitle className="text-xl font-bold leading-tight group-hover:text-primary transition-colors">
                    {doc.title}
                  </CardTitle>
                  <CardDescription className="line-clamp-2 text-sm">
                    {doc.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between text-xs text-muted-foreground mb-4">
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {doc.readTime}
                    </div>
                    <div className="flex items-center gap-1">
                      <span className={
                        doc.difficulty === "Expert" ? "text-red-400" :
                        doc.difficulty === "Advanced" ? "text-orange-400" :
                        doc.difficulty === "Intermediate" ? "text-yellow-400" :
                        "text-green-400"
                      }>
                        {doc.difficulty}
                      </span>
                    </div>
                  </div>
                  
                  {/* Progress Bar */}
                  <div className="h-1.5 w-full bg-secondary rounded-full overflow-hidden mb-4">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${
                        doc.status === "Mastered" ? "bg-green-500" :
                        doc.status === "Learning" ? "bg-yellow-500" :
                        "bg-secondary"
                      }`}
                      style={{ width: `${doc.progress}%` }}
                    />
                  </div>

                  <Link href="/learn/mock-session">
                    <Button className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-all" variant="secondary">
                      <span className="mr-2">
                        {doc.status === "Unseen" ? "Start Module" : "Continue Learning"}
                      </span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </ScrollArea>
      </div>
    </Layout>
  );
}
