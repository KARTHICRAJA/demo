import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  Network, 
  BookOpen, 
  BrainCircuit, 
  Settings, 
  LogOut,
  Search,
  Menu,
  MessageSquare,
  Layers,
  ChevronDown,
  ChevronRight,
  FileJson,
  Code,
  GitPullRequest,
  Activity
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import logo from "@assets/generated_images/bp_helios_logo.png";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { ScrollArea } from "@/components/ui/scroll-area";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isSkillsOpen, setIsSkillsOpen] = useState(true);

  const navItems = [
    { icon: Network, label: "The Atlas", path: "/" },
    { icon: BookOpen, label: "Library", path: "/library" },
    { icon: MessageSquare, label: "Discovery Chat", path: "/discovery" },
    { icon: BrainCircuit, label: "Learning Session", path: "/learn/mock-session" },
  ];

  const skillItems = [
    { icon: FileJson, label: "Requirement Analysis", path: "/skills/requirement-analysis" },
    { icon: Code, label: "Design Analysis", path: "/skills/design-analysis" },
    { icon: GitPullRequest, label: "Change Impact", path: "/skills/change-impact" },
    { icon: Activity, label: "Incident Analysis", path: "/skills/incident-analysis" },
  ];

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden">
      {/* Sidebar */}
      <aside 
        className={cn(
          "flex flex-col border-r border-sidebar-border bg-sidebar transition-all duration-300 ease-in-out z-20",
          isSidebarOpen ? "w-72" : "w-[70px]"
        )}
      >
        {/* Logo Area */}
        <div className="h-16 flex items-center px-4 border-b border-sidebar-border bg-sidebar/50 backdrop-blur">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="relative flex-shrink-0 w-8 h-8">
              <img 
                src={logo} 
                alt="HyperIQ" 
                className="w-full h-full object-contain filter drop-shadow-[0_0_8px_rgba(0,153,0,0.5)]"
              />
            </div>
            <span 
              className={cn(
                "font-mono font-bold text-lg tracking-wider text-sidebar-primary transition-opacity duration-300 whitespace-nowrap",
                !isSidebarOpen && "opacity-0 hidden"
              )}
            >
              HyperIQ
            </span>
          </div>
        </div>

        {/* Navigation */}
        <ScrollArea className="flex-1 py-4">
          <nav className="px-2 space-y-1">
            {navItems.map((item) => (
              <Link key={item.path} href={item.path}>
                <div 
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-md cursor-pointer transition-colors group mb-1",
                    location === item.path 
                      ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                      : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                  )}
                  title={!isSidebarOpen ? item.label : undefined}
                >
                  <item.icon className={cn("w-5 h-5 flex-shrink-0", location === item.path && "text-primary")} />
                  <span className={cn(
                    "font-medium text-sm whitespace-nowrap transition-all duration-300",
                    !isSidebarOpen && "opacity-0 w-0 overflow-hidden"
                  )}>
                    {item.label}
                  </span>
                  
                  {location === item.path && isSidebarOpen && (
                    <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary shadow-[0_0_8px_var(--color-primary)]" />
                  )}
                </div>
              </Link>
            ))}

            {/* Skills Group */}
            <Collapsible open={isSkillsOpen && isSidebarOpen} onOpenChange={setIsSkillsOpen} className="mt-4">
              <CollapsibleTrigger asChild>
                <div 
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-md cursor-pointer text-sidebar-foreground/70 hover:text-sidebar-foreground transition-colors",
                    !isSidebarOpen && "justify-center px-0"
                  )}
                >
                  <Layers className="w-5 h-5 flex-shrink-0" />
                  {isSidebarOpen && (
                    <>
                      <span className="font-medium text-sm flex-1 text-left">Skills</span>
                      {isSkillsOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                    </>
                  )}
                </div>
              </CollapsibleTrigger>
              <CollapsibleContent className="space-y-1 mt-1">
                {skillItems.map((item) => (
                  <Link key={item.path} href={item.path}>
                    <div 
                      className={cn(
                        "flex items-center gap-3 px-3 py-2 rounded-md cursor-pointer transition-colors group ml-4 border-l border-sidebar-border/50",
                        location === item.path 
                          ? "bg-sidebar-accent/50 text-sidebar-accent-foreground border-primary" 
                          : "text-sidebar-foreground/60 hover:bg-sidebar-accent/30 hover:text-sidebar-foreground border-transparent"
                      )}
                    >
                      <item.icon className={cn("w-4 h-4 flex-shrink-0", location === item.path && "text-primary")} />
                      <span className="font-medium text-xs whitespace-nowrap">
                        {item.label}
                      </span>
                    </div>
                  </Link>
                ))}
              </CollapsibleContent>
            </Collapsible>
          </nav>
        </ScrollArea>

        {/* Bottom Actions */}
        <div className="p-2 border-t border-sidebar-border space-y-1">
          <Button 
            variant="ghost" 
            size="icon" 
            className="w-full justify-start px-3 hover:bg-sidebar-accent/50 text-sidebar-foreground/70"
          >
            <Settings className="w-5 h-5" />
            {isSidebarOpen && <span className="ml-3 text-sm font-medium">Settings</span>}
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="w-full justify-start px-3 hover:bg-destructive/20 hover:text-destructive text-sidebar-foreground/70"
          >
            <LogOut className="w-5 h-5" />
            {isSidebarOpen && <span className="ml-3 text-sm font-medium">Logout</span>}
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full overflow-hidden relative bg-background">
        {/* Header */}
        <header className="h-16 border-b border-border bg-background/80 backdrop-blur-md flex items-center justify-between px-6 z-10">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="text-muted-foreground hover:text-foreground"
            >
              <Menu className="w-5 h-5" />
            </Button>
            <div className="relative max-w-md w-64 hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Search nodes, concepts, docs..." 
                className="pl-9 bg-secondary/50 border-transparent focus-visible:bg-secondary focus-visible:border-primary/50 transition-all h-9"
              />
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-xs font-mono text-muted-foreground hidden sm:block">
              <span className="text-green-500 animate-pulse">●</span> HyperIQ v1.0
            </div>
            {/* User Avatar Placeholder */}
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-green-500 to-yellow-400 ring-2 ring-background shadow-lg shadow-green-500/20" />
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-hidden relative">
          {children}
        </div>
      </main>
    </div>
  );
}
