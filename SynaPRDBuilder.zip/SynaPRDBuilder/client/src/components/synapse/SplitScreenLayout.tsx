import React from "react";
import { 
  ResizableHandle, 
  ResizablePanel, 
  ResizablePanelGroup 
} from "@/components/ui/resizable";
import { SocraticChat } from "./SocraticChat";
import { DocumentViewer } from "./DocumentViewer";

export function SplitScreenLayout() {
  return (
    <ResizablePanelGroup direction="horizontal" className="min-h-full w-full rounded-lg border-none">
      <ResizablePanel defaultSize={50} minSize={30}>
        <div className="h-full w-full">
          <DocumentViewer />
        </div>
      </ResizablePanel>
      
      <ResizableHandle withHandle className="bg-border w-1.5 hover:bg-primary transition-colors" />
      
      <ResizablePanel defaultSize={50} minSize={30}>
        <div className="h-full w-full">
          <SocraticChat />
        </div>
      </ResizablePanel>
    </ResizablePanelGroup>
  );
}
