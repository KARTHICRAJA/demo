import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BrainCircuit, ChevronRight } from 'lucide-react';
import splashBg from '@assets/generated_images/hyperiq_splash_screen_background.png'; // Will need to use the generated image path
import logo from "@assets/generated_images/bp_helios_logo.png";

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 3500); // Auto dismiss after 3.5s if no interaction
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <motion.div 
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-background overflow-hidden"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, transition: { duration: 0.8, ease: "easeInOut" } }}
    >
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/80 to-background z-10" />
        <img 
          src={splashBg} 
          alt="Background" 
          className="w-full h-full object-cover opacity-40 animate-pulse-slow" 
        />
      </div>

      {/* Content */}
      <div className="relative z-20 flex flex-col items-center text-center space-y-8 px-4">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="relative w-32 h-32 mb-4"
        >
          <div className="absolute inset-0 rounded-full bg-green-500/20 blur-xl animate-pulse" />
          <img src={logo} alt="HyperIQ" className="w-full h-full object-contain drop-shadow-[0_0_15px_rgba(0,153,0,0.8)]" />
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.8 }}
        >
          <h1 className="text-5xl md:text-7xl font-bold tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-green-500 via-yellow-400 to-green-300">
            HyperIQ
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mt-4 tracking-wide font-light">
            Endur Knowledge Hub
          </p>
        </motion.div>

        <motion.div
          initial={{ width: 0 }}
          animate={{ width: 200 }}
          transition={{ delay: 1, duration: 1.5 }}
          className="h-0.5 bg-gradient-to-r from-transparent via-green-500 to-transparent"
        />

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2 }}
          className="text-sm font-mono text-green-500/60"
        >
          INITIALIZING NEURAL PATHWAYS...
        </motion.div>
        
        <motion.button
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 2.5 }}
            onClick={onComplete}
            className="mt-8 flex items-center gap-2 text-foreground/80 hover:text-green-500 transition-colors group cursor-pointer"
        >
            <span>Enter System</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </motion.button>
      </div>
    </motion.div>
  );
}
