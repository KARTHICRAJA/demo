import React, { useState } from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Maximize2, FileText, Book } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';

export function DocumentViewer() {
  const [hoveredTerm, setHoveredTerm] = useState<string | null>(null);

  // Mock text content for Endur ETRM
  const content = [
    { type: 'h1', text: 'Deal Capture & Transaction Lifecycle' },
    { type: 'p', text: 'In Endur, "Deal Capture" is the primary entry point for all trading activities. Traders and sales personnel use specialized interfaces known as Deal Skins to input transaction details.' },
    { type: 'h2', text: 'Deal Skins and Instruments' },
    { 
      type: 'p', 
      text: 'Deal Skins are highly configurable GUI forms that map to underlying Instruments. An Instrument defines the financial or physical behavior of the trade (e.g., "Future", "Swap", "Physical Gas"). When a user saves a deal, the system validates the data against the Instrument definition and generates a Transaction Record.',
      terms: ['Deal Skins', 'Instruments', 'Transaction Record'] 
    },
    { type: 'h3', text: 'Open Components (OC) Customization' },
    { type: 'p', text: 'While standard Deal Skins cover most use cases, complex structured products often require customization. Open Components (OC) allow developers to inject custom logic (Pre-Process and Post-Process scripts) directly into the deal entry workflow. This ensures that proprietary valuation models or specific compliance checks are run in real-time before the deal is committed.' },
    { type: 'code', text: `// Example JVS/OC Snippet for Deal Validation\nTable dealData = transaction.retrieveTable(TRANF_FIELD.DEAL_SKIN);\nif (dealData.getDouble("Notional") > LIMIT_MAX) {\n   Util.exitFail("Trade exceeds desk limit.");\n}` }
  ];

  const renderText = (text: string, terms?: string[]) => {
    if (!terms) return text;

    let parts = [text];
    terms.forEach(term => {
      const newParts: any[] = [];
      parts.forEach(part => {
        if (typeof part === 'string') {
          const split = part.split(term);
          split.forEach((s, i) => {
            newParts.push(s);
            if (i < split.length - 1) {
              newParts.push(
                <span 
                  key={`${term}-${i}`}
                  className="bg-primary/20 text-primary border-b border-primary/50 cursor-help px-0.5 rounded hover:bg-primary/40 transition-colors"
                  onMouseEnter={() => setHoveredTerm(term)}
                  onMouseLeave={() => setHoveredTerm(null)}
                >
                  {term}
                </span>
              );
            }
          });
        } else {
          newParts.push(part);
        }
      });
      parts = newParts;
    });
    return parts;
  };

  return (
    <div className="flex flex-col h-full bg-background relative">
      {/* Navbar / Breadcrumbs */}
      <div className="h-14 flex items-center px-4 border-b border-border bg-background/95 backdrop-blur z-10">
        <Link href="/">
          <Button variant="ghost" size="icon" className="mr-2 text-muted-foreground hover:text-foreground">
            <ArrowLeft size={18} />
          </Button>
        </Link>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Book size={14} />
          <span>Library</span>
          <span>/</span>
          <span className="text-foreground font-medium">Endur Documentation</span>
          <span>/</span>
          <span className="text-primary">Deal Capture Module</span>
        </div>
        <div className="ml-auto">
           <Button variant="ghost" size="icon" title="Focus Mode">
             <Maximize2 size={18} className="text-muted-foreground" />
           </Button>
        </div>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1 p-8 md:p-12 max-w-3xl mx-auto w-full">
        <div className="space-y-6 pb-20 font-serif text-lg leading-relaxed text-foreground/90">
          {content.map((block, idx) => {
            if (block.type === 'h1') return <h1 key={idx} className="text-4xl font-bold font-sans tracking-tight mb-6 mt-2">{block.text}</h1>;
            if (block.type === 'h2') return <h2 key={idx} className="text-2xl font-semibold font-sans tracking-tight mt-8 mb-4 text-primary">{block.text}</h2>;
            if (block.type === 'h3') return <h3 key={idx} className="text-xl font-medium font-sans mt-6 mb-3">{block.text}</h3>;
            if (block.type === 'code') return (
              <pre key={idx} className="bg-secondary/50 border border-border rounded-lg p-4 overflow-x-auto font-mono text-sm my-4 text-blue-300">
                <code>{block.text}</code>
              </pre>
            );
            return (
              <p key={idx} className="text-muted-foreground/90">
                {renderText(block.text, block.terms)}
              </p>
            );
          })}
        </div>
      </ScrollArea>

      {/* Floating Entity Card (Simulating Graph Interaction) */}
      {hoveredTerm && (
        <div className="absolute top-20 right-8 w-64 bg-popover border border-border rounded-lg shadow-xl p-4 animate-in fade-in zoom-in-95 duration-200 pointer-events-none z-50">
          <div className="flex items-center justify-between mb-2">
             <span className="text-xs font-mono text-muted-foreground uppercase">Concept Node</span>
             <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">Learning</Badge>
          </div>
          <h4 className="font-bold text-lg text-primary mb-1">{hoveredTerm}</h4>
          <p className="text-xs text-muted-foreground mb-3">
            Core Front Office Concept. Linked to "Open Components" and "Validation Scripts".
          </p>
          <div className="h-1 w-full bg-secondary rounded-full overflow-hidden">
            <div className="h-full bg-yellow-500 w-[45%]" />
          </div>
          <div className="flex justify-between mt-1">
            <span className="text-[10px] text-muted-foreground">Mastery</span>
            <span className="text-[10px] font-mono text-foreground">45%</span>
          </div>
        </div>
      )}
    </div>
  );
}
