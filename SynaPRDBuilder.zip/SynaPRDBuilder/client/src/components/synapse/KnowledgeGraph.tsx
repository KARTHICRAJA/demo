import React, { useEffect, useRef, useState, useMemo } from 'react';
import ForceGraph2D from 'react-force-graph-2d';
import { useTheme } from 'next-themes'; 

// Asset Imports
import iconCore from '@assets/generated_images/icon_core_endur.png';
import iconFo from '@assets/generated_images/icon_front_office.png';
import iconRisk from '@assets/generated_images/icon_risk_mgmt.png';
import iconBo from '@assets/generated_images/icon_back_office.png';
import iconTech from '@assets/generated_images/icon_technical.png';

// Mock Data for Endur ETRM Knowledge Graph
const MOCK_DATA = {
  nodes: [
    // Roots & Core
    { id: 'endur', name: 'Endur ETRM Core', val: 40, group: 'core', status: 'mastered', img: iconCore },
    
    // Front Office
    { id: 'fo', name: 'Front Office', val: 30, group: 'fo', status: 'mastered', img: iconFo },
    { id: 'deal_cap', name: 'Deal Capture', val: 15, group: 'fo', status: 'learning' },
    { id: 'instruments', name: 'Instruments', val: 12, group: 'fo', status: 'learning' },
    { id: 'deal_skins', name: 'Deal Skins', val: 10, group: 'fo', status: 'learning' },
    { id: 'trans_types', name: 'Tran Types', val: 8, group: 'fo', status: 'unseen' },
    
    // Middle Office / Risk
    { id: 'risk', name: 'Risk Mgmt', val: 30, group: 'risk', status: 'learning', img: iconRisk },
    { id: 'sim', name: 'Simulations', val: 15, group: 'risk', status: 'unseen' },
    { id: 'var', name: 'VaR', val: 12, group: 'risk', status: 'unseen' },
    { id: 'pfe', name: 'PFE', val: 10, group: 'risk', status: 'unseen' },
    { id: 'greeks', name: 'Greeks', val: 10, group: 'risk', status: 'unseen' },
    
    // Back Office / Ops
    { id: 'bo', name: 'Back Office', val: 30, group: 'bo', status: 'unseen', img: iconBo },
    { id: 'settle', name: 'Settlements', val: 15, group: 'bo', status: 'unseen' },
    { id: 'invoice', name: 'Invoicing', val: 12, group: 'bo', status: 'unseen' },
    { id: 'confirm', name: 'Confirmations', val: 10, group: 'bo', status: 'unseen' },

    // Technical / Dev
    { id: 'tech', name: 'Technical Arch', val: 30, group: 'tech', status: 'decayed', img: iconTech },
    { id: 'oc', name: 'OpenComponents', val: 15, group: 'tech', status: 'decayed' },
    { id: 'jvs', name: 'JVS', val: 12, group: 'tech', status: 'decayed' },
    { id: 'connex', name: 'Connex', val: 12, group: 'tech', status: 'unseen' },
    { id: 'abr', name: 'ABR', val: 10, group: 'tech', status: 'unseen' },
    { id: 'market_data', name: 'Market Data', val: 15, group: 'tech', status: 'mastered' },
  ],
  links: [
    // Core Links
    { source: 'endur', target: 'fo' },
    { source: 'endur', target: 'risk' },
    { source: 'endur', target: 'bo' },
    { source: 'endur', target: 'tech' },
    
    // Front Office Cluster
    { source: 'fo', target: 'deal_cap' },
    { source: 'deal_cap', target: 'instruments' },
    { source: 'deal_cap', target: 'deal_skins' },
    { source: 'deal_cap', target: 'trans_types' },
    
    // Risk Cluster
    { source: 'risk', target: 'sim' },
    { source: 'risk', target: 'var' },
    { source: 'risk', target: 'pfe' },
    { source: 'risk', target: 'greeks' },
    { source: 'sim', target: 'market_data' }, // Dependency

    // Back Office Cluster
    { source: 'bo', target: 'settle' },
    { source: 'settle', target: 'invoice' },
    { source: 'bo', target: 'confirm' },
    
    // Technical Cluster
    { source: 'tech', target: 'oc' },
    { source: 'tech', target: 'jvs' },
    { source: 'tech', target: 'connex' },
    { source: 'tech', target: 'abr' },
    { source: 'tech', target: 'market_data' },
    { source: 'oc', target: 'deal_skins' }, // Scripting extends UI
  ]
};

const COLORS = {
  unseen: '#64748b', // slate-500
  learning: '#fbbf24', // amber-400
  mastered: '#22c55e', // green-500
  decayed: '#ef4444', // red-500
  background: '#020617', // slate-950 (Darker background for contrast)
  link: '#1e293b', // slate-800
};

export function KnowledgeGraph({ onNodeClick }: { onNodeClick?: (node: any) => void }) {
  const graphRef = useRef<any>(null);
  const [dimensions, setDimensions] = useState({ w: 800, h: 600 });
  const containerRef = useRef<HTMLDivElement>(null);
  const [images, setImages] = useState<Record<string, HTMLImageElement>>({});

  // Preload images
  useEffect(() => {
    const imgs: Record<string, HTMLImageElement> = {};
    const sources = [iconCore, iconFo, iconRisk, iconBo, iconTech];
    
    sources.forEach(src => {
      const img = new Image();
      img.src = src;
      imgs[src] = img;
    });
    setImages(imgs);
  }, []);

  useEffect(() => {
    const updateDimensions = () => {
      if (containerRef.current) {
        setDimensions({
          w: containerRef.current.offsetWidth,
          h: containerRef.current.offsetHeight
        });
      }
    };

    window.addEventListener('resize', updateDimensions);
    updateDimensions();

    return () => window.removeEventListener('resize', updateDimensions);
  }, []);

  useEffect(() => {
    if (graphRef.current) {
      // Configure physics forces for better spacing
      graphRef.current.d3Force('charge').strength(-400); // Stronger repulsion
      graphRef.current.d3Force('link').distance(100); // Longer links
      graphRef.current.d3Force('center').strength(0.5);
      
      // Re-heat simulation to apply changes
      graphRef.current.d3ReheatSimulation();
    }
  }, []);

  const data = useMemo(() => MOCK_DATA, []);

  return (
    <div ref={containerRef} className="w-full h-full relative bg-background overflow-hidden">
      <ForceGraph2D
        ref={graphRef}
        width={dimensions.w}
        height={dimensions.h}
        graphData={data}
        backgroundColor={COLORS.background}
        nodeLabel="name"
        nodeColor={(node: any) => COLORS[node.status as keyof typeof COLORS]}
        // Link styling
        linkColor={() => COLORS.link}
        linkWidth={1}
        linkDirectionalParticles={2}
        linkDirectionalParticleWidth={2}
        linkDirectionalParticleSpeed={0.005}
        
        // Interaction
        onNodeClick={(node) => {
          graphRef.current?.centerAt(node.x, node.y, 1000);
          graphRef.current?.zoom(6, 2000);
          if (onNodeClick) onNodeClick(node);
        }}
        
        // Custom Node Rendering
        nodeCanvasObject={(node: any, ctx, globalScale) => {
          const isLargeNode = node.val > 20;
          const size = isLargeNode ? 24 : 6;
          const fontSize = isLargeNode ? 14/globalScale : 12/globalScale;
          
          // 1. Draw Image for Group Heads
          if (node.img && images[node.img]) {
            const img = images[node.img];
            const imgSize = size * 2; // Diameter
            
            // Circular clipping for image
            ctx.save();
            ctx.beginPath();
            ctx.arc(node.x, node.y, size, 0, 2 * Math.PI, false);
            ctx.clip();
            
            try {
              ctx.drawImage(img, node.x - size, node.y - size, imgSize, imgSize);
            } catch (e) {
              // Fallback
              ctx.fillStyle = COLORS[node.status as keyof typeof COLORS];
              ctx.fill();
            }
            ctx.restore();

            // Ring border based on status
            ctx.beginPath();
            ctx.arc(node.x, node.y, size, 0, 2 * Math.PI, false);
            ctx.lineWidth = 2 / globalScale;
            ctx.strokeStyle = COLORS[node.status as keyof typeof COLORS];
            ctx.stroke();
            
            // Glow for large nodes
            if (node.status === 'learning' || node.status === 'decayed') {
               ctx.shadowBlur = 30;
               ctx.shadowColor = COLORS[node.status as keyof typeof COLORS];
               ctx.stroke();
               ctx.shadowBlur = 0;
            }

          } else {
            // 2. Standard Nodes (Dots)
            ctx.beginPath();
            ctx.arc(node.x, node.y, size, 0, 2 * Math.PI, false);
            ctx.fillStyle = COLORS[node.status as keyof typeof COLORS];
            
            // Glow effect
            if (node.status === 'learning' || node.status === 'decayed') {
               ctx.shadowBlur = 10;
               ctx.shadowColor = COLORS[node.status as keyof typeof COLORS];
            } else {
               ctx.shadowBlur = 0;
            }
            
            ctx.fill();
          }
          
          // 3. Draw Label
          const label = node.name;
          ctx.font = `600 ${fontSize}px Inter, sans-serif`;
          const textWidth = ctx.measureText(label).width;
          const bckgDimensions = [textWidth, fontSize].map(n => n + fontSize * 0.5);

          // Background Pill for text
          if (globalScale > 1.2 || isLargeNode) {
            ctx.fillStyle = 'rgba(2, 6, 23, 0.8)'; // Slate-950 with opacity
            ctx.beginPath();
            // Rounded rect manually
            const padding = 4 / globalScale;
            const rx = node.x - textWidth / 2 - padding;
            const ry = node.y + size + (padding * 2);
            const rw = textWidth + (padding * 2);
            const rh = fontSize + (padding * 2);
            
            ctx.roundRect(rx, ry, rw, rh, 4);
            ctx.fill();
            
            // Text
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillStyle = isLargeNode ? '#fff' : 'rgba(255, 255, 255, 0.8)';
            ctx.fillText(label, node.x, node.y + size + (padding * 2) + (fontSize/2));
          }
        }}
      />
      
      {/* Overlay UI Elements */}
      <div className="absolute bottom-6 right-6 bg-card/90 backdrop-blur border border-border p-4 rounded-lg shadow-lg max-w-xs">
        <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3">Mastery Heatmap</h3>
        <div className="space-y-2">
          <div className="flex items-center gap-3 text-xs">
            <div className="w-3 h-3 rounded-full bg-[var(--color-mastery-unseen)] shadow-[0_0_5px_var(--color-mastery-unseen)]" />
            <span className="text-foreground">Unseen</span>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <div className="w-3 h-3 rounded-full bg-[var(--color-mastery-learning)] shadow-[0_0_5px_var(--color-mastery-learning)]" />
            <span className="text-foreground">Learning</span>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <div className="w-3 h-3 rounded-full bg-[var(--color-mastery-mastered)] shadow-[0_0_5px_var(--color-mastery-mastered)]" />
            <span className="text-foreground">Mastered</span>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <div className="w-3 h-3 rounded-full bg-[var(--color-mastery-decayed)] shadow-[0_0_5px_var(--color-mastery-decayed)]" />
            <span className="text-foreground">Decayed (Review Needed)</span>
          </div>
        </div>
      </div>

      <div className="absolute top-6 left-6 pointer-events-none">
         <h1 className="text-3xl font-bold text-foreground tracking-tight drop-shadow-lg">The Atlas</h1>
         <p className="text-muted-foreground text-sm mt-1">HyperIQ Network Topology</p>
      </div>
    </div>
  );
}
