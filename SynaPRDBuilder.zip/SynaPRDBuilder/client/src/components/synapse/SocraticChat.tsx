import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, CheckCircle2, XCircle, Lightbulb } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  type?: 'question' | 'feedback' | 'normal';
  score?: number; // 0-100
}

const MOCK_MESSAGES: Message[] = [
  {
    id: '1',
    role: 'assistant',
    content: "Let's verify your understanding of the Endur architecture. You've been reviewing the Deal Capture module. Based on the graph, 'Deal Skins' are a critical concept.",
    type: 'normal'
  },
  {
    id: '2',
    role: 'assistant',
    content: "In your own words, explain the relationship between a 'Deal Skin' and an 'Instrument'. Why can't you just use a generic form for all trades?",
    type: 'question'
  }
];

export function SocraticChat() {
  const [messages, setMessages] = useState<Message[]>(MOCK_MESSAGES);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const newUserMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue
    };

    setMessages(prev => [...prev, newUserMsg]);
    setInputValue('');
    setIsTyping(true);

    // Mock AI Response
    setTimeout(() => {
      setIsTyping(false);
      const response: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: "That's the core distinction. Instruments define the *behavior* and *valuation logic*, while Deal Skins are just the *interface*. If you used a generic form, you'd lose the ability to capture specific attributes required for pricing complex derivatives, like 'Swing' parameters on a gas contract. Now, how does OpenComponents (OC) fit into this validation process?",
        type: 'question'
      };
      setMessages(prev => [...prev, response]);
    }, 1500);
  };

  return (
    <div className="flex flex-col h-full bg-background border-l border-border">
      {/* Header */}
      <div className="h-14 border-b border-border flex items-center px-4 justify-between bg-secondary/10">
        <div className="flex items-center gap-2">
          <Avatar className="h-8 w-8 border border-primary/30">
            <AvatarImage src="/ai-avatar.png" />
            <AvatarFallback className="bg-primary/10 text-primary"><Bot size={16} /></AvatarFallback>
          </Avatar>
          <div>
            <h3 className="text-sm font-semibold">Socratic Tutor</h3>
            <p className="text-[10px] text-muted-foreground flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              Active Recall Mode
            </p>
          </div>
        </div>
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <Lightbulb className="w-4 h-4 text-yellow-500" />
        </Button>
      </div>

      {/* Chat Area */}
      <div className="flex-1 overflow-hidden relative">
        <div 
          ref={scrollRef}
          className="h-full overflow-y-auto p-4 space-y-6 scroll-smooth"
        >
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={cn(
                "flex gap-3 max-w-[90%]",
                msg.role === 'user' ? "ml-auto flex-row-reverse" : ""
              )}
            >
              <Avatar className={cn(
                "h-8 w-8 mt-1",
                msg.role === 'assistant' ? "border-primary/30" : "border-border"
              )}>
                <AvatarFallback className={cn(
                  msg.role === 'assistant' ? "bg-primary/10 text-primary" : "bg-secondary text-secondary-foreground"
                )}>
                  {msg.role === 'assistant' ? <Bot size={14} /> : <User size={14} />}
                </AvatarFallback>
              </Avatar>

              <div className={cn(
                "flex flex-col gap-1",
                msg.role === 'user' ? "items-end" : "items-start"
              )}>
                <div className={cn(
                  "p-3.5 rounded-2xl text-sm leading-relaxed shadow-sm",
                  msg.role === 'user' 
                    ? "bg-primary text-primary-foreground rounded-tr-none" 
                    : "bg-secondary/50 border border-border/50 text-foreground rounded-tl-none"
                )}>
                  {msg.content}
                </div>
                
                {/* Metadata/Tags for Socratic messages */}
                {msg.type === 'question' && (
                  <span className="text-[10px] font-mono text-primary flex items-center gap-1">
                    <Sparkles size={10} /> CHALLENGE
                  </span>
                )}
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-3 max-w-[90%] animate-in fade-in slide-in-from-bottom-2">
              <Avatar className="h-8 w-8 border border-primary/30">
                <AvatarFallback className="bg-primary/10 text-primary"><Bot size={14} /></AvatarFallback>
              </Avatar>
              <div className="bg-secondary/50 border border-border/50 p-4 rounded-2xl rounded-tl-none flex gap-1 items-center h-10">
                <div className="w-1.5 h-1.5 bg-primary/50 rounded-full animate-bounce [animation-delay:-0.3s]" />
                <div className="w-1.5 h-1.5 bg-primary/50 rounded-full animate-bounce [animation-delay:-0.15s]" />
                <div className="w-1.5 h-1.5 bg-primary/50 rounded-full animate-bounce" />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Input Area */}
      <div className="p-4 border-t border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="relative">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type your answer..."
            className="pr-12 bg-secondary/30 border-border focus-visible:ring-primary/50 min-h-[50px] py-3"
          />
          <Button 
            size="icon" 
            className="absolute right-1 top-1 h-10 w-10 rounded-md transition-all hover:bg-primary hover:text-primary-foreground"
            variant="ghost"
            onClick={handleSend}
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        <div className="mt-2 text-center">
           <p className="text-[10px] text-muted-foreground">
             Synapse evaluates your depth of understanding, not just keywords.
           </p>
        </div>
      </div>
    </div>
  );
}
