import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { Dashboard } from "@/pages/Dashboard";
import { LearningSession } from "@/pages/LearningSession";
import { Library } from "@/pages/Library";
import { DiscoveryChat } from "@/pages/DiscoveryChat";
import { RequirementAnalysis } from "@/pages/skills/RequirementAnalysis";
import { DesignAnalysis } from "@/pages/skills/DesignAnalysis";
import { ChangeImpactAnalysis } from "@/pages/skills/ChangeImpactAnalysis";
import { IncidentAnalysis } from "@/pages/skills/IncidentAnalysis";
import { SplashScreen } from "@/components/synapse/SplashScreen";
import { useState, useEffect } from "react";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/library" component={Library} />
      <Route path="/discovery" component={DiscoveryChat} />
      <Route path="/learn/:sessionId" component={LearningSession} />
      <Route path="/skills/requirement-analysis" component={RequirementAnalysis} />
      <Route path="/skills/design-analysis" component={DesignAnalysis} />
      <Route path="/skills/change-impact" component={ChangeImpactAnalysis} />
      <Route path="/skills/incident-analysis" component={IncidentAnalysis} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Splash screen state
  const [showSplash, setShowSplash] = useState(true);

  // Persist splash screen state per session or refresh
  useEffect(() => {
    const hasSeenSplash = sessionStorage.getItem('hasSeenSplash');
    if (hasSeenSplash) {
      setShowSplash(false);
    }
  }, []);

  const handleSplashComplete = () => {
    setShowSplash(false);
    sessionStorage.setItem('hasSeenSplash', 'true');
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        {showSplash ? (
          <SplashScreen onComplete={handleSplashComplete} />
        ) : (
          <Router />
        )}
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
